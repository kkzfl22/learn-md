package com.nullnull.observer;

/**
 * @author liujun
 * @since 2023/7/13
 */
public interface Observer {

    void observe(String event);

}
