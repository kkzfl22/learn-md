package com.nullnull.learn.boot.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * 标识当前为springboot的单元测试类，并加载项目的applicationContext上下文环境
 *
 * @author liujun
 * @since 2023/2/27
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {UserController.class})
public class UserControllerTest {

  @Autowired private UserController userController;

  @Test
  public void testHello() {
    String msg = userController.demo();
    System.out.println(msg);
  }


  
}
