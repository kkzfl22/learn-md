package com.nullnull.learn.boot.controller;

import com.nullnull.learn.config.SimpleBean;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * 测试自定义Starter
 *
 * @author liujun
 * @since 2023/3/19
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class TestMyselfStarter {

    /**
     * 加载bean
     */
    @Autowired
    private SimpleBean simpleBean;

    @Test
    public void testDataGet() {
        System.out.println(simpleBean);
    }
}
