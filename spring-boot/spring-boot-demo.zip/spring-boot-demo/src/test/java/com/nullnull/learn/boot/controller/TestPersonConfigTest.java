package com.nullnull.learn.boot.controller;

import com.nullnull.learn.boot.config.TestPerson;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author liujun
 * @since 2023/2/27
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class TestPersonConfigTest {

    @Autowired
    private TestPerson personConfig;

    @Test
    public void testConfig() {
        System.out.println(personConfig);
        Assert.assertNotNull(personConfig);
    }
}
