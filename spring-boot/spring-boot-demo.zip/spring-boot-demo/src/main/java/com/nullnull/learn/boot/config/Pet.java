package com.nullnull.learn.boot.config;

/**
 * 宠物信息
 *
 * @author liujun
 * @since 2023/3/1
 */
public class Pet {

  /** id */
  private String type;

  /** 宠物的名称 */
  private String name;

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("Pet{");
    sb.append("type='").append(type).append('\'');
    sb.append(", name='").append(name).append('\'');
    sb.append('}');
    return sb.toString();
  }
}
