package com.nullnull.learn.boot.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author liujun
 * @since 2023/3/4
 */
@Component
public class Student {

  @Value("33")
  private Integer id;

  @Value("${person.name}")
  private String name;

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("Student{");
    sb.append("id=").append(id);
    sb.append(", name='").append(name).append('\'');
    sb.append('}');
    return sb.toString();
  }
}
