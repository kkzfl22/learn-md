package com.nullnull.learn.boot.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * 配制文件关联 @ConfigurationProperties(prefix = "person")
 *
 * <p>将配制文件中以Person开头的属性注入到类中，而且可以在配制文件时，可以有关联的提示效果
 *
 * <p>PropertySource默认不支持加载yaml文件
 *
 * @author liujun
 * @since 2023/3/1
 */
@Component
// @PropertySource("classpath:randomApplication.properties")
@ConfigurationProperties(prefix = "test.random")
public class TestRandomValue {

    /**
     * 配制文件对应id
     */
    private int id;

    /**
     * 名称信息
     */
    private String name;

    /**
     * 长整形值
     */
    private Long longValue;

    /**
     * uuid的值信息
     */
    private String uuid;

    /**
     * 小于一个数的值
     */
    private int lessThen;

    private int scope;

    /**
     * 值引用
     */
    private String referenceValue;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getLongValue() {
        return longValue;
    }

    public void setLongValue(Long longValue) {
        this.longValue = longValue;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public int getLessThen() {
        return lessThen;
    }

    public void setLessThen(int lessThen) {
        this.lessThen = lessThen;
    }

    public int getScope() {
        return scope;
    }

    public void setScope(int scope) {
        this.scope = scope;
    }

    public String getReferenceValue() {
        return referenceValue;
    }

    public void setReferenceValue(String referenceValue) {
        this.referenceValue = referenceValue;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TestRandomValue{");
        sb.append("id=").append(id);
        sb.append(", name='").append(name).append('\'');
        sb.append(", longValue=").append(longValue);
        sb.append(", uuid='").append(uuid).append('\'');
        sb.append(", lessThen=").append(lessThen);
        sb.append(", scope=").append(scope);
        sb.append(", referenceValue=").append(referenceValue);
        sb.append('}');
        return sb.toString();
    }
}
