package com.nullnull.learn.boot.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author liujun
 * @since 2023/2/27
 */
@RestController
public class UserController {

  @RequestMapping("/demo")
  public String demo() {
    return "hello spring boot -- new 2";
  }
}
