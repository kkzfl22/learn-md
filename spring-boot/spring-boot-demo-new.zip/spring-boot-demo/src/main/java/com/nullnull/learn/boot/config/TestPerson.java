package com.nullnull.learn.boot.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * 配制文件关联 @ConfigurationProperties(prefix = "person")
 *
 * <p>将配制文件中以Person开头的属性注入到类中，而且可以在配制文件时，可以有关联的提示效果
 *
 * <p>PropertySource默认不支持加载yaml文件
 *
 * @author liujun
 * @since 2023/3/1
 */
@Component
// @PropertySource("classpath:testapplication.properties")
// @ConfigurationProperties(prefix = "test.person")
public class TestPerson {

    /**
     * 配制文件对应id
     */
    private int id;

    /**
     * 名称信息
     */
    private String name;

    /**
     * 集合的爱好信息
     */
    private List<Object> hobby;

    /**
     * 家庭成员
     */
    private String[] family;

    /**
     * 使用Map的类型
     */
    private Map<String, Object> map;

    /**
     * 宠物信息
     */
    private Pet pet;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Object> getHobby() {
        return hobby;
    }

    public void setHobby(List<Object> hobby) {
        this.hobby = hobby;
    }

    public String[] getFamily() {
        return family;
    }

    public void setFamily(String[] family) {
        this.family = family;
    }

    public Map<String, Object> getMap() {
        return map;
    }

    public void setMap(Map<String, Object> map) {
        this.map = map;
    }

    public Pet getPet() {
        return pet;
    }

    public void setPet(Pet pet) {
        this.pet = pet;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("SpringBootConfigBean{");
        sb.append("id=").append(id);
        sb.append(", name='").append(name).append('\'');
        sb.append(", hobby=").append(hobby);
        sb.append(", family=").append(Arrays.toString(family));
        sb.append(", map=").append(map);
        sb.append(", pet=").append(pet);
        sb.append('}');
        return sb.toString();
    }
}
