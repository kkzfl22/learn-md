package com.nullnull.learn.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 用户信息 在类中要使用注解建立实体类与数据表之间的映射关系以及属性和映射的关系
 *
 * <p>1. 实体类和映射表的关系 @Entity @Table
 *
 * <p>2. 实体类属性和表字段的映射关系 @Id 标识主键 @GeneratedValue 标识主键的生成策略 @Column 建立属性和字段映射
 *
 * @author liujun
 * @since 2023/2/24
 */
@Entity
@Table(name = "user_data_info")
public class UserDataInfo {

  /**
   * 用户Id
   *
   * <p>在id的生成策略中经常使用两种：
   *
   * <p>1. GenerationType.IDENTITY 依赖数据库中主键自增功能。 MYSQL
   *
   * <p>2. GenerationType.SEQUENCE 依赖序列来产生主键 ORACLE
   */
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id")
  private Long id;

  /** 地址信息 */
  @Column(name = "address")
  private String address;

  /** 名称 */
  @Column(name = "name")
  private String name;

  /** 手机号 */
  @Column(name = "phone")
  private String phone;

  /** 年龄 */
  @Column(name = "age")
  private Integer age;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }

  public Integer getAge() {
    return age;
  }

  public void setAge(Integer age) {
    this.age = age;
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("UserDataInfo{");
    sb.append("id=").append(id);
    sb.append(", address='").append(address).append('\'');
    sb.append(", name='").append(name).append('\'');
    sb.append(", phone='").append(phone).append('\'');
    sb.append(", age=").append(age);
    sb.append('}');
    return sb.toString();
  }
}
