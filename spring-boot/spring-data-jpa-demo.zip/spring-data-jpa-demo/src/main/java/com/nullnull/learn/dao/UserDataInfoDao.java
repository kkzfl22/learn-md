package com.nullnull.learn.dao;

import com.nullnull.learn.pojo.UserDataInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

/**
 * 一个符合SpringDataJpa要求的DAO层接口是需要继承JpaRepository和JpaSpecificationExecutor
 *
 * <p>JpaRepository<操作的实体类型,主键类型> 封装了基本的CRUD操作
 *
 * <p>JpaSpecificationExecutor<操作的实体类型> 封装了复杂的查询（分页、排序等）
 *
 * @author liujun
 * @since 2023/2/24
 */
public interface UserDataInfoDao
    extends JpaRepository<UserDataInfo, Long>, JpaSpecificationExecutor<UserDataInfo> {

  /**
   * 使用Jqpl过时行查询
   *
   * @param name
   * @return
   */
  @Query("from UserDataInfo where  name like %?1%")
  List<UserDataInfo> queryJqpl(String name);

  /**
   * 使用原生的SQL
   *
   * @param name
   * @return
   */
  @Query(value = "select * from user_data_info where name like %?1%", nativeQuery = true)
  List<UserDataInfo> querySql(String name);

  /**
   * 方法命名规则查询
   *
   * <p>按照名称做like查询
   *
   * <p>方法以findBy开头
   *
   * <p>-属性名，首字母大写
   *
   * <p>- 查询方式（模糊查询，等价查询），如果不写查询方式，默认等价查询
   *
   * @param name
   * @return
   */
  List<UserDataInfo> findByNameLikeAndId(String name, Long id);
}
