package com.nullnull.learn.dao;

import com.nullnull.learn.pojo.UserDataInfo;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.List;
import java.util.Optional;

/**
 * 接口的单元测试
 *
 * @author liujun
 * @since 2023/2/24
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class UserDataInfoDaoTest {

  /** 注入需要测试的对象 */
  @Autowired private UserDataInfoDao userDataInfoDao;

  /** 基础的增删改查 */
  @Test
  public void crud() {

    UserDataInfo userAdd = new UserDataInfo();
    userAdd.setName("nullnull");
    userAdd.setAddress("上海");
    userAdd.setAge(28);
    userAdd.setPhone("13487654321");

    // 添加
    UserDataInfo saveRsp = userDataInfoDao.save(userAdd);
    Assert.assertNotNull(saveRsp.getId());

    // 修改
    saveRsp.setName("nullnull-new");
    saveRsp.setAge(29);
    UserDataInfo updateRsp = userDataInfoDao.save(saveRsp);
    Assert.assertNotNull(updateRsp.getId());

    // 查询
    Optional<UserDataInfo> optId = userDataInfoDao.findById(updateRsp.getId());
    Assert.assertNotNull(optId.get().getAddress());

    // 删除
    userDataInfoDao.delete(optId.get());
  }

  @Test
  public void query1() {
    // 查询
    Optional<UserDataInfo> optId = userDataInfoDao.findById(1L);
    System.out.println(optId.get());
    Assert.assertNotNull(optId.get().getAddress());
  }

  /** 使用jqpl进行查询 */
  @Test
  public void queryJqpl() {
    List<UserDataInfo> name = userDataInfoDao.queryJqpl("张");
    System.out.println(name);
    Assert.assertNotNull(name.get(0).getAddress());
  }

  /** 使用原生的SQL进行查询 */
  @Test
  public void querySql() {
    List<UserDataInfo> name = userDataInfoDao.querySql("张");
    System.out.println(name);
    Assert.assertNotNull(name.get(0).getAddress());
  }

  @Test
  public void findByNameLikeAndId() {
    List<UserDataInfo> name = userDataInfoDao.findByNameLikeAndId("张%", 1L);
    System.out.println(name);
    Assert.assertNotNull(name.get(0).getAddress());
  }

  /** 测试动态查询 */
  @Test
  public void testSpecfication() {
    /*
     * 匿名内部类进行封装查询
     * 借助于两个参数，完成条件的封装
     */
    Specification<UserDataInfo> specification =
        new Specification<UserDataInfo>() {
          @Override
          public Predicate toPredicate(
              Root<UserDataInfo> root,
              CriteriaQuery<?> criteriaQuery,
              CriteriaBuilder criteriaBuilder) {

            // 使用CriteriaBuilder构造查询条件
            Predicate query = criteriaBuilder.equal(root.get("name"), "张三");

            Predicate query2 = criteriaBuilder.equal(root.get("id"), 1L);

            return criteriaBuilder.and(query, query2);
          }
        };

    Optional<UserDataInfo> resultData = userDataInfoDao.findOne(specification);
    System.out.println(resultData.get());
    Assert.assertNotNull(resultData.get().getAddress());
  }

  /** 测试动态查询 */
  @Test
  public void testSpecficationLike() {

    Specification<UserDataInfo> specification =
        new Specification<UserDataInfo>() {
          @Override
          public Predicate toPredicate(
              Root<UserDataInfo> root,
              CriteriaQuery<?> criteriaQuery,
              CriteriaBuilder criteriaBuilder) {

            Path<Object> dataName = root.get("name");

            // 使用CriteriaBuilder构造查询条件
            Predicate query = criteriaBuilder.like(dataName.as(String.class), "张%");

            return criteriaBuilder.and(query);
          }
        };

    List<UserDataInfo> resultData = userDataInfoDao.findAll(specification);
    System.out.println(resultData);
    Assert.assertNotNull(resultData.get(0).getAddress());
  }

  /** 带条件的排序查询 */
  @Test
  public void findAndSort() {
    Sort sort = new Sort(Sort.Direction.DESC, "id");

    UserDataInfo optionUser = new UserDataInfo();
    optionUser.setAge(180);

    Example<UserDataInfo> example = Example.of(optionUser);

    List<UserDataInfo> dataList = userDataInfoDao.findAll(example, sort);

    for (int i = 0; i < dataList.size(); i++) {
      UserDataInfo o = dataList.get(i);
      System.out.println(o);
    }

    Assert.assertNotEquals(dataList.size(), 0);
  }

  /** 分页查询*/
  @Test
  public void page() {
    // 第一个参数，当前开始的页，从0开始
    // 第二个参数，每页显示的数量
    Pageable page = PageRequest.of(1, 2);

    Page<UserDataInfo> dataList = userDataInfoDao.findAll(page);

    for (int i = 0; i < dataList.getContent().size(); i++) {
      UserDataInfo o = dataList.getContent().get(i);
      System.out.println(o);
    }

    Assert.assertNotEquals(dataList.getTotalElements(), 0);
  }
}
