package com.nullnull.learn.thymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/**
 * @author liujun
 * @since 2023/3/25
 */
@SpringBootApplication
public class SpringBootThemeleaf {

  public static void main(String[] args) {
    SpringApplication.run(SpringBootThemeleaf.class, args);
  }
}
