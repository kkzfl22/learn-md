package com.nullnull.learn.thymeleaf.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import java.time.LocalDate;
/**
 * @author liujun
 * @since 2023/3/25
 */
@Controller
public class LoginController {

  /**
   * 获取并封装当前年份跳转至登录页login.html
   *
   * @param model
   * @return
   */
  @RequestMapping("/toLoginPage")
  public String toLoginPage(Model model) {
    model.addAttribute("currentYear", LocalDate.now().getYear());
    return "login";
  }
}
