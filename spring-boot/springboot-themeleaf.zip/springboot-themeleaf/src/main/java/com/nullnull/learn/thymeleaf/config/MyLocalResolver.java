package com.nullnull.learn.thymeleaf.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.LocaleResolver;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Locale;
/**
 * 国际化语言切换
 *
 * @author liujun
 * @since 2023/3/26
 */
@Configuration
public class MyLocalResolver implements LocaleResolver {

  @Override
  public Locale resolveLocale(HttpServletRequest httpServletRequest) {

    // 1,按页面传递的参数进行国际化语言切换
      String languageParam = httpServletRequest.getParameter("l");

    // 未传递参数，按默认请求头的类型
    if (StringUtils.isEmpty(languageParam)) {
      // 读取Header头中的参数,信息，例如Accept-Language: en-US,en;q=0.9
      String headerLanguage = httpServletRequest.getHeader("Accept-Language");

      String[] headerCfg = headerLanguage.split(",");
      String[] localParam = headerCfg[0].split("-");
      return new Locale(localParam[0], localParam[1]);
    }
    String[] localParam = languageParam.split("_");
    return new Locale(localParam[0], localParam[1]);
  }

  @Override
  public void setLocale(
      HttpServletRequest httpServletRequest,
      HttpServletResponse httpServletResponse,
      Locale locale) {}

  @Bean
  public LocaleResolver localeResolver() {
    return new MyLocalResolver();
  }
}
