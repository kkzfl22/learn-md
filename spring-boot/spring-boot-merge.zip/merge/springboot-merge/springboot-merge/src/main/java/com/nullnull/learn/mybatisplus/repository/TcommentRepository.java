package com.nullnull.learn.mybatisplus.repository;
/**
 *
 * @author liujun
 * @since 2023/3/25
 */
public class TcommentRepository {
}
