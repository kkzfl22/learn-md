package com.nullnull.learn.redis.po;
/**
 *
 * @author liujun
 * @since 2023/3/24
 */
public class Address {
}
