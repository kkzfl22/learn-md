package com.nullnull.learn.thymeleaf.controller;
/**
 *
 * @author liujun
 * @since 2023/3/25
 */
public class LoginController {
}
