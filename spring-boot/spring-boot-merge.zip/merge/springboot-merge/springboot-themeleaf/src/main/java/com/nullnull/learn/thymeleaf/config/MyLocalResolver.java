package com.nullnull.learn.thymeleaf.config;
/**
 *
 *
 * @author liujun
 * @since 2023/3/26
 */
public class MyLocalResolver {
}
