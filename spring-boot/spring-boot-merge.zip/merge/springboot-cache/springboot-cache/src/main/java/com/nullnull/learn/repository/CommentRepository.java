package com.nullnull.learn.repository;

import com.nullnull.learn.po.Comment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import javax.transaction.Transactional;
/**
 * 评论的存储表
 *
 * @author liujun
 * @since 2023/3/26
 */
public interface CommentRepository extends JpaRepository<Comment, Integer> {

  /**
   * 按评论的id进行更新作者
   *
   * @param author 作者
   * @param id id
   * @return 修改的结果
   */
  @Transactional
  @Modifying
  @Query(value = "update t_comment set author = ?1 where id = ?2", nativeQuery = true)
  public int updateComment(String author, Integer id);
}
