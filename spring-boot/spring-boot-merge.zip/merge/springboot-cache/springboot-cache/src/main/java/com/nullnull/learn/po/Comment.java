package com.nullnull.learn.po;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import java.io.Serializable;

/**
 * 评论信息对应的java实体
 *
 * @author liujun
 * @since 2023/3/26
 */
@Getter
@Setter
@ToString
@Entity(name = "t_comment")
public class Comment implements Serializable {

  /** 主键的ID */
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;
  /** 内容信息 */
  private String content;

  /** 作都 信息 */
  private String author;

  /** 映射字段对应不上，添加注解 */
  @Column(name = "a_id")
  private Integer aId;
}
