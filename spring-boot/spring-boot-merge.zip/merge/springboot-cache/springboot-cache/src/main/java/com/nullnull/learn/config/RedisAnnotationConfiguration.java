package com.nullnull.learn.config;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import java.time.Duration;

/**
 * @author liujun
 * @since 2023/3/27
 */
@Configuration
public class RedisAnnotationConfiguration {

  @Bean
  public RedisCacheManager cacheManager(RedisConnectionFactory redisConnectionFactory) {

    // 分别创建JSON和String序列化对象
    RedisSerializer<String> stringRedisSerializer = new StringRedisSerializer();
    Jackson2JsonRedisSerializer jsonRedisSerializer = new Jackson2JsonRedisSerializer(Object.class);

    // 查询查询异常缓存转换问题
    ObjectMapper om = new ObjectMapper();
    om.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
    om.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
    // om.activateDefaultTyping(PolymorphicTypeValidator.Validity.)
    jsonRedisSerializer.setObjectMapper(om);

    // 定制缓存序列化方式及时效
    RedisCacheConfiguration cacheManagerConfig =
        RedisCacheConfiguration.defaultCacheConfig()
            // 过期时间为1天
            .entryTtl(Duration.ofDays(1))
            // 序列化key
            .serializeKeysWith(
                RedisSerializationContext.SerializationPair.fromSerializer(stringRedisSerializer))
            // 序列化值
            .serializeValuesWith(
                RedisSerializationContext.SerializationPair.fromSerializer(jsonRedisSerializer))
            .disableCachingNullValues();
    RedisCacheManager cacheManager =
        RedisCacheManager.builder(redisConnectionFactory).cacheDefaults(cacheManagerConfig).build();

    return cacheManager;
  }
}
