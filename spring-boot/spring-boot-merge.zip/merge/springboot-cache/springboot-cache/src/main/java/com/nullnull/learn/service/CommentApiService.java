package com.nullnull.learn.service;

import com.nullnull.learn.po.Comment;
import com.nullnull.learn.repository.CommentRepository;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

/**
 * 评论的服务
 *
 * @author liujun
 * @since 2023/3/26
 */
@Service
public class CommentApiService {

  @Autowired private CommentRepository commentRepository;

  @Autowired private RedisTemplate redisTemplate;

  /**
   * 按id进行查询
   *
   * @param id
   * @return
   */
  public Comment findCommentById(Integer id) {
    Object commentObj = redisTemplate.opsForValue().get(key(id));
    // 如果当前为空，则加载缓存，存储到redis中
    if (null == commentObj) {
      Optional<Comment> comment = commentRepository.findById(id);
      if (comment.isPresent()) {
        Comment result = comment.get();
        redisTemplate.opsForValue().set(key(id), result, 1, TimeUnit.DAYS);
        return result;
      }
    }
    // 如果当前缓存中数据存在
    else {
      return (Comment) commentObj;
    }

    return null;
  }

  private String key(Integer id) {
    return "comment_" + id;
  }

  /**
   * 进行数据修改操作,修改完成后，进行缓存的更新
   *
   * @param auth 作者
   * @param id id
   * @return
   */
  public Comment updateComment(String auth, Integer id) {

    Optional<Comment> dataComment = commentRepository.findById(id);

    Comment authComment = dataComment.get();
    authComment.setAuthor(auth);
    commentRepository.updateComment(authComment.getAuthor(), authComment.getId());

    // 更新缓存中的值
    redisTemplate.opsForValue().set(key(id), authComment);

    return authComment;
  }

  /**
   * 按id进行数据删除
   *
   * @param deleteId
   */
  public void deleteComment(Integer deleteId) {
    commentRepository.deleteById(deleteId);

    // 将缓存中的数据做删除操作
    redisTemplate.delete(key(deleteId));
  }
}
