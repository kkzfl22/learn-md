# mybatis源码分析，缓存的配制加载。
首先还是准备下测试用例
## 1. 单元测试用例.
数据库操作的java的映射文件
```java
package org.apache.use.use.mapper;
import org.apache.use.use.po.UserMsgPO;
public interface UserMapper {
  UserMsgPO query(UserMsgPO user);
}
```
数据库操作实体
```java
package org.apache.use.use.po;
import java.io.Serializable;
public class UserMsgPO implements Serializable {
  /**
   * 用户的id
   */
  private Integer id;

  /**
   * 名称的信息
   */
  private String name;
  public Integer getId() {
    return id;
  }  public void setId(Integer id) {
    this.id = id;
  }
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }
  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("UserMsgPO{");
    sb.append("id=").append(id);
    sb.append(", name='").append(name).append('\'');
    sb.append('}');
    return sb.toString();
  }
}
```
mybatis的配制文件
```xml
<!DOCTYPE configuration PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-config.dtd">
<configuration>
    <properties resource="jdbc.properties"/>
    <settings>
      <setting name="cacheEnabled" value="true"/>
    </settings>
    <environments default="default">
        <environment id="default">
            <!--JDBC表示把数据库的事务交给JDBC进行管理。 MANAGER让容器进行管理，很少使用，它从来不提交回滚一个连接。-->
            <transactionManager type="JDBC"></transactionManager>
            <!--POOLED使用mybatis的连接池，UNPOOLED表示不使用连接池,每次使用数据库时才打开和关闭连接，JNDI,使用容器配制的数据源。-->
            <dataSource type="POOLED">
                <property name="driver" value="${jdbc.driver}"/>
                <property name="url" value="${jdbc.url}"/>
                <property name="username" value="${jdbc.username}"/>
                <property name="password" value="${jdbc.password}"/>
            </dataSource>
        </environment>
    </environments>
    <mappers>
        <mapper resource="UserCacheMsgMapper.xml"/>
    </mappers>
</configuration>
```
数据库数据库映射的SQl文件
```xml
<!DOCTYPE mapper
  PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
  "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.liujun.learn.mybatis.mapper.UserMsgMapper">
  <cache></cache>
  <select id="selectOne" parameterType="org.apache.use.use.po.UserMsgPO"
          resultType="org.apache.use.use.po.UserMsgPO" useCache="true">
    select * from user_msg
    <where>
      <if test="id != null">
        and id = #{id}
      </if>
    </where>
  </select>
</mapper>
```
数据库查询的单元测试
```java
public class QuickCacheMapperStart {
   @Test
  public void mapperQueryCache() throws IOException {
    //将mybatis的配制文件转换为流,供助类加载
    InputStream streamConfig = Resources.getResourceAsStream("sqlCacheMapConfig.xml");
    //将流转换为配制文件配制对象
    SqlSessionFactory build = new SqlSessionFactoryBuilder().build(streamConfig);

    SqlSession sqlSession1 = build.openSession();
    SqlSession sqlSession2 = build.openSession();

    UserMsgPO user = new UserMsgPO();
    user.setId(1);

    UserMsgPO userRsp = sqlSession1.selectOne("com.liujun.learn.mybatis.mapper.UserMsgMapper.selectOne", user);
    System.out.println(userRsp);
    Assertions.assertNotNull(userRsp.getName());

    //cache只有在commit和close时才生效
    sqlSession1.commit();


    UserMsgPO userRsp2 = sqlSession2.selectOne("com.liujun.learn.mybatis.mapper.UserMsgMapper.selectOne", user);
    System.out.println(userRsp2);
    Assertions.assertNotNull(userRsp2.getName());
  }
}
```

## 2. 源码分析
带着问题来分析，这样会有更更深的理解
1. cache标签是如何被解析的，怎样去生产的cache对象。
2. cache的一个流程。
3. 为什么执行一个commit和close缓存才会生效。


### 2.1 缓存的标签解析
在之前，已经分析过期加载过程，这里重点就分析下与缓存相关的源码
就从配制文件加载开始吧
#### 2.1.1 输入入转换为SqlSessionFactory对象
```java
package org.apache.ibatis.session;

public class SqlSessionFactoryBuilder {
  /**
   * 调用初始化构造器对象，传递了一个文件输入流
   * @param inputStream 输入流
   * @return 加载成为配制信息
   */
  public SqlSessionFactory build(InputStream inputStream) {
    //调用了重载方法，环境和属性信息为空
    return build(inputStream, null, null);
  }

  /**
   * 构建方法，解析配制文件，封装Configuration对象
   * @param inputStream 配制文件的输入流
   * @param environment 环境信息
   * @param properties 属性信息。
   * @return
   */
  public SqlSessionFactory build(InputStream inputStream, String environment, Properties properties) {
    try {
      //创建XMLConfigBuilder，XMLConfigBuilder是专门用于解析mybatis配制文件的类。
      XMLConfigBuilder parser = new XMLConfigBuilder(inputStream, environment, properties);
      //parser.parse()将配制文件转换成配制类。
      return build(parser.parse());
    } catch (Exception e) {
      throw ExceptionFactory.wrapException("Error building SqlSession.", e);
    } finally {
      ErrorContext.instance().reset();
      try {
        inputStream.close();
      } catch (IOException e) {
        // Intentionally ignore. Prefer previous error.
      }
    }
  }
  public SqlSessionFactory build(Configuration config) {
    return new DefaultSqlSessionFactory(config);
  }
}
```

#### 2.1.2 mybatis的配制文件加载
这里是将整个mybatis的配制文件进行加载，重点查看Mapper.xml文件的加载，cache标签就配制这个对象中,还是以样例中的配制，resource的方式进行加载操作。
```java
package org.apache.ibatis.builder.xml;

public class XMLConfigBuilder extends BaseBuilder {
  /**
   * 将mybatis配制对象转换为Configuration对象
   *
   * @return
   */
  public Configuration parse() {
    //若已经解析，则抛出异常。
    if (parsed) {
      throw new BuilderException("Each XMLConfigBuilder can only be used once.");
    }
    //标记当前已经解析
    parsed = true;
    //读取mybatis配制文件的元素configuration，交给parseConfiguration方法处理
    parseConfiguration(parser.evalNode("/configuration"));
    return configuration;
  }
  
    private void parseConfiguration(XNode root) {
    try {
      //issue #117 read properties first
      //首先读取<properties/>标签，一般用于指定jdbc的配制文件
      propertiesElement(root.evalNode("properties"));
      //再读取<settings />标签，做一些参数的配制
      Properties settings = settingsAsProperties(root.evalNode("settings"));
      //加载自定义的实现类VFS
      loadCustomVfs(settings);
      //加载片定义的log
      loadCustomLogImpl(settings);
      //加载<typeAliases/> 做一些全局的自定义类的名称
      typeAliasesElement(root.evalNode("typeAliases"));
      //加载<plugins />加载插件类
      pluginElement(root.evalNode("plugins"));
      //解析<objectFactory />标签
      objectFactoryElement(root.evalNode("objectFactory"));
      //解析<objectWrapperFactory />标签
      objectWrapperFactoryElement(root.evalNode("objectWrapperFactory"));
      //解析reflectorFactory />标签
      reflectorFactoryElement(root.evalNode("reflectorFactory"));
      //设置<settings/>到Configuration属性中
      settingsElement(settings);
      //解析<environments /> 标签
      // read it after objectFactory and objectWrapperFactory issue #631
      environmentsElement(root.evalNode("environments"));
      // 解析<databaseIdProvider />标签
      databaseIdProviderElement(root.evalNode("databaseIdProvider"));
      //解析<typeHandlers />标签
      typeHandlerElement(root.evalNode("typeHandlers"));
      //加载<mappers />映射的配制文件
      //解析其中的<insert,<update,<delete,<select等，将其转换为MappedStatement对象
      mapperElement(root.evalNode("mappers"));
    } catch (Exception e) {
      throw new BuilderException("Error parsing SQL Mapper Configuration. Cause: " + e, e);
    }
  }
  /**
   * 进行mapper标签的处理，
   *
   * @param parent xml文件的标签对象
   * @throws Exception 异常
   */
  private void mapperElement(XNode parent) throws Exception {
    if (parent != null) {
      for (XNode child : parent.getChildren()) {
        //优先处理mappers标签中的package标签
        if ("package".equals(child.getName())) {
          //读取那么属性，配制信息为一个包的路径
          String mapperPackage = child.getStringAttribute("name");
          configuration.addMappers(mapperPackage);
        } else {
          String resource = child.getStringAttribute("resource");
          String url = child.getStringAttribute("url");
          String mapperClass = child.getStringAttribute("class");
          //当前仅配制了resource标签
          if (resource != null && url == null && mapperClass == null) {
            ErrorContext.instance().resource(resource);
            InputStream inputStream = Resources.getResourceAsStream(resource);
            //创建XMLMapperBuilder构建器过时行对象的创建
            XMLMapperBuilder mapperParser = new XMLMapperBuilder(inputStream, configuration, resource, configuration.getSqlFragments());
            //执行配制mapper映射的xml文件解析操作
            mapperParser.parse();
          }
          //当前仅配制了url标签
          else if (resource == null && url != null && mapperClass == null) {
            ErrorContext.instance().resource(url);
            InputStream inputStream = Resources.getUrlAsStream(url);
            XMLMapperBuilder mapperParser = new XMLMapperBuilder(inputStream, configuration, url, configuration.getSqlFragments());
            mapperParser.parse();
          }
          //当前仅配制了class标签
          else if (resource == null && url == null && mapperClass != null) {
            Class<?> mapperInterface = Resources.classForName(mapperClass);
            configuration.addMapper(mapperInterface);
          } else {
            throw new BuilderException("A mapper element may only specify a url, resource or class, but not more than one.");
          }
        }
      }
    }
  }
}
```

#### 2.1.3 XMLMapperBuilder解析器进行mapper.xml文件的解析
在配制文件中<cache>属性，可以配制
![](./resource/images\mybatis-cache属性.png)
还继续源码分析。
```java
package org.apache.ibatis.builder.xml;

public class XMLMapperBuilder extends BaseBuilder {
  public void parse() {
    //判断mapper是否已经加载过。
    if (!configuration.isResourceLoaded(resource)) {
      //解析<mapper>标签,此在SQL的xml文件的配制为根节点。
      configurationElement(parser.evalNode("/mapper"));
      //标记该mapper已经加载过
      configuration.addLoadedResource(resource);
      //绑定mapper操作
      bindMapperForNamespace();
    }

    //解析特定的<resultMap>节点
    parsePendingResultMaps();
    //解析特定的<cache-ref>节点
    parsePendingCacheRefs();
    //解析特定的SQL语句的节点.
    parsePendingStatements();
  }
  private void configurationElement(XNode context) {
    try {
      //获取nameSpace属性
      String namespace = context.getStringAttribute("namespace");
      if (namespace == null || namespace.equals("")) {
        throw new BuilderException("Mapper's namespace cannot be empty");
      }
      //设置namespace属性
      builderAssistant.setCurrentNamespace(namespace);
      //解析<cache-ref>标签
      cacheRefElement(context.evalNode("cache-ref"));
      //解析<cache>标签
      cacheElement(context.evalNode("cache"));
      //已经废弃，老式风格的参数映射，内联参数是首选 ，这个元素可能在将来被移除
      parameterMapElement(context.evalNodes("/mapper/parameterMap"));
      //解析<resultMap>节点
      resultMapElements(context.evalNodes("/mapper/resultMap"));
      //解析<sql>节点
      sqlElement(context.evalNodes("/mapper/sql"));
      //解析<select>、<insert>、<update>、<delete>标签。
      //将生成cache包装到对应的MappedStatement对象中
      buildStatementFromContext(context.evalNodes("select|insert|update|delete"));
    } catch (Exception e) {
      throw new BuilderException("Error parsing Mapper XML. The XML location is '" + resource + "'. Cause: " + e, e);
    }
  }
  /**
   * 解析<cache>标签
   * @param context
   */
  private void cacheElement(XNode context) {
    if (context != null) {
      //读取cache标签的type属性，这里可以自定义cache的实现类，如RedisCache，如果没有，使用默认的PERPETUAL
      String type = context.getStringAttribute("type", "PERPETUAL");
      Class<? extends Cache> typeClass = typeAliasRegistry.resolveAlias(type);
      //读取cache标签的eviction属性，这属性是负责缓存的过期策略，默认LRU
      String eviction = context.getStringAttribute("eviction", "LRU");
      Class<? extends Cache> evictionClass = typeAliasRegistry.resolveAlias(eviction);
      //清空缓存的频率，0，代表不清空
      Long flushInterval = context.getLongAttribute("flushInterval");
      //缓存容器的大小
      Integer size = context.getIntAttribute("size");
      //是否序列化
      boolean readWrite = !context.getBooleanAttribute("readOnly", false);
      //是否阻塞
      boolean blocking = context.getBooleanAttribute("blocking", false);
      Properties props = context.getChildrenAsProperties();
      //通过配制的属性值来构建Cache对象
      builderAssistant.useNewCache(typeClass, evictionClass, flushInterval, size, readWrite, blocking, props);
    }
  }
}
```
#### 2.1.4 进行缓存对象Cache的创建
```java
package org.apache.ibatis.builder;

public class MapperBuilderAssistant extends BaseBuilder {
  private Cache currentCache;
  public Cache useNewCache(Class<? extends Cache> typeClass,
      Class<? extends Cache> evictionClass,
      Long flushInterval,
      Integer size,
      boolean readWrite,
      boolean blocking,
      Properties props) {
    //通过构建器进行cache对象的创建操作
    Cache cache = new CacheBuilder(currentNamespace)
        .implementation(valueOrDefault(typeClass, PerpetualCache.class))
        .addDecorator(valueOrDefault(evictionClass, LruCache.class))
        .clearInterval(flushInterval)
        .size(size)
        .readWrite(readWrite)
        .blocking(blocking)
        .properties(props)
        .build();
    //将对象添加至Configuration对象中,configuration是一个全局配制对象。
	//此对象位于BaseBuilder中，
    configuration.addCache(cache);
    //将创建出来的cache对象赋值给MapperBuilderAssistant对象中的currentCache
    //此入设置此属性，在后续的加载中还会使用。
    currentCache = cache;
    return cache;
  }
}
```
至此，整个cache标签的读取与加载就已经完成了。
一个mapper中有一个cache，一个xml文件就会做一次cache的标签的解析。只会创建一次cache对象。


#### 2.1.5 构建Statement对象。
继续执行代码，来到XMLMapperBuilder的configurationElement方法。跟踪buildStatementFromContext方法
```java
package org.apache.ibatis.builder.xml;

public class XMLMapperBuilder extends BaseBuilder {
   /**
   * 构建Statement对象
   * @param list
   */
  private void buildStatementFromContext(List<XNode> list) {
    if (configuration.getDatabaseId() != null) {
      buildStatementFromContext(list, configuration.getDatabaseId());
    }
    buildStatementFromContext(list, null);
  }

  /**
   * 进行解析
   * @param list
   * @param requiredDatabaseId
   */
  private void buildStatementFromContext(List<XNode> list, String requiredDatabaseId) {
    for (XNode context : list) {
      //创建一个XMLStatementBuilder解析器对象。
      final XMLStatementBuilder statementParser = new XMLStatementBuilder(configuration, builderAssistant, context, requiredDatabaseId);
      try {
        //每一个语句都被转换为一个MapperStatement对象。
        statementParser.parseStatementNode();
      } catch (IncompleteElementException e) {
        configuration.addIncompleteStatement(statementParser);
      }
    }
  } 
}
```
在源码中可以看到此处创建了一个XMLStatementBuilder对象。继续跟踪，便调用了XMLStatementBuilder对象的parseStatementNode方法。

#### 2.1.6 构建器对象XMLStatementBuilder解析
对于配制的mapper文件进行解析，创建出MappedStatement。
```java
package org.apache.ibatis.builder.xml;

public class XMLStatementBuilder extends BaseBuilder {

  public void parseStatementNode() {
    //获取id属性
    String id = context.getStringAttribute("id");
    String databaseId = context.getStringAttribute("databaseId");

    //检查id属性是否与databaseId匹配
    if (!databaseIdMatchesCurrent(id, databaseId, this.requiredDatabaseId)) {
      return;
    }

    //其他属性的获取。
    String nodeName = context.getNode().getNodeName();
    SqlCommandType sqlCommandType = SqlCommandType.valueOf(nodeName.toUpperCase(Locale.ENGLISH));
    boolean isSelect = sqlCommandType == SqlCommandType.SELECT;

    //关于cache的两个标签的解析。如果flushCache为true，每次都将清空二组缓存。
    boolean flushCache = context.getBooleanAttribute("flushCache", !isSelect);
    //useCache表示当前使用二级缓存。
    boolean useCache = context.getBooleanAttribute("useCache", isSelect);
    boolean resultOrdered = context.getBooleanAttribute("resultOrdered", false);

    // Include Fragments before parsing
    XMLIncludeTransformer includeParser = new XMLIncludeTransformer(configuration, builderAssistant);
    includeParser.applyIncludes(context.getNode());

    String parameterType = context.getStringAttribute("parameterType");
    Class<?> parameterTypeClass = resolveClass(parameterType);

    String lang = context.getStringAttribute("lang");
    LanguageDriver langDriver = getLanguageDriver(lang);

    // Parse selectKey after includes and remove them.
    processSelectKeyNodes(id, parameterTypeClass, langDriver);

    // Parse the SQL (pre: <selectKey> and <include> were parsed and removed)
    KeyGenerator keyGenerator;
    String keyStatementId = id + SelectKeyGenerator.SELECT_KEY_SUFFIX;
    keyStatementId = builderAssistant.applyCurrentNamespace(keyStatementId, true);
    if (configuration.hasKeyGenerator(keyStatementId)) {
      keyGenerator = configuration.getKeyGenerator(keyStatementId);
    } else {
      keyGenerator = context.getBooleanAttribute("useGeneratedKeys",
          configuration.isUseGeneratedKeys() && SqlCommandType.INSERT.equals(sqlCommandType))
          ? Jdbc3KeyGenerator.INSTANCE : NoKeyGenerator.INSTANCE;
    }

    SqlSource sqlSource = langDriver.createSqlSource(configuration, context, parameterTypeClass);
    StatementType statementType = StatementType.valueOf(context.getStringAttribute("statementType", StatementType.PREPARED.toString()));
    Integer fetchSize = context.getIntAttribute("fetchSize");
    Integer timeout = context.getIntAttribute("timeout");
    String parameterMap = context.getStringAttribute("parameterMap");
    String resultType = context.getStringAttribute("resultType");
    Class<?> resultTypeClass = resolveClass(resultType);
    String resultMap = context.getStringAttribute("resultMap");
    String resultSetType = context.getStringAttribute("resultSetType");
    ResultSetType resultSetTypeEnum = resolveResultSetType(resultSetType);
    if (resultSetTypeEnum == null) {
      resultSetTypeEnum = configuration.getDefaultResultSetType();
    }
    String keyProperty = context.getStringAttribute("keyProperty");
    String keyColumn = context.getStringAttribute("keyColumn");
    String resultSets = context.getStringAttribute("resultSets");

    //最后又来到了MapperBuilderAssistant，将通过此创建一个MappedStatement对象。
    builderAssistant.addMappedStatement(id, sqlSource, statementType, sqlCommandType,
        fetchSize, timeout, parameterMap, parameterTypeClass, resultMap, resultTypeClass,
        resultSetTypeEnum, flushCache, useCache, resultOrdered,
        keyGenerator, keyProperty, keyColumn, databaseId, langDriver, resultSets);
  }
}
```
#### 2.1.7 通过MapperBuilderAssistant的创建MappedStatement对象
在之前创建cache时，也是使用了MapperBuilderAssistant,
```java
package org.apache.ibatis.builder;

public class MapperBuilderAssistant extends BaseBuilder {
  /**
   * 构建MappedStatement对象。
   */
  public MappedStatement addMappedStatement(
      String id,
      SqlSource sqlSource,
      StatementType statementType,
      SqlCommandType sqlCommandType,
      Integer fetchSize,
      Integer timeout,
      String parameterMap,
      Class<?> parameterType,
      String resultMap,
      Class<?> resultType,
      ResultSetType resultSetType,
      boolean flushCache,
      boolean useCache,
      boolean resultOrdered,
      KeyGenerator keyGenerator,
      String keyProperty,
      String keyColumn,
      String databaseId,
      LanguageDriver lang,
      String resultSets) {

    //如果当前的cache未解析，则报错。
    if (unresolvedCacheRef) {
      throw new IncompleteElementException("Cache-ref not yet resolved");
    }

    //获取id的编号，格式为${namespaceid}.${id}
    id = applyCurrentNamespace(id, false);
    boolean isSelect = sqlCommandType == SqlCommandType.SELECT;

    //创建MappedStatement.Builder构建器。
    MappedStatement.Builder statementBuilder = new MappedStatement.Builder(configuration, id, sqlSource, sqlCommandType)
        .resource(resource)
        .fetchSize(fetchSize)
        .timeout(timeout)
        .statementType(statementType)
        .keyGenerator(keyGenerator)
        .keyProperty(keyProperty)
        .keyColumn(keyColumn)
        .databaseId(databaseId)
        .lang(lang)
        .resultOrdered(resultOrdered)
        .resultSets(resultSets)
        .resultMaps(getStatementResultMaps(resultMap, resultType, id))
        .resultSetType(resultSetType)
        .flushCacheRequired(valueOrDefault(flushCache, !isSelect))
        .useCache(valueOrDefault(useCache, isSelect))
        //在创建缓存对象时，将新的cache对象赋值给了currentCache，现在设置给MappedStatement对象
        .cache(currentCache);

    //获取ParameterMap对象，并设置至构建器中
    ParameterMap statementParameterMap = getStatementParameterMap(parameterMap, parameterType, id);
    if (statementParameterMap != null) {
      statementBuilder.parameterMap(statementParameterMap);
    }

    //创建MappedStatement对象
    MappedStatement statement = statementBuilder.build();
    //将创建MappedStatement放入至configuration,也就是放入全局配制类。
    configuration.addMappedStatement(statement);
    return statement;
  }

}
```

每个select标签都对应着一个MappedStatement对象，而每个MappedStatement对象在创建时，把解析的cache对象设置到MappedStatement中，这也就是
所说的相同的mapper中的MappedStatement共用一个cache，或者说同一个mapper中所有的MappedStatement中的cache属性引用的都是同一个。


