## mybatis源码分析 -1

### 1. 源码分析的准备工作
单元测试类
```java
package org.apache.use.test;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.use.use.po.UserMsgPO;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.io.InputStream;
/**
 * mybatis源码分析的单元测试
 *
 * @author liujun
 * @since 2022/7/7
 */
public class QuickStart {
  @Test
  public void baseQuery() throws IOException {
    //将mybatis的配制文件转换为流,供助类加载
    InputStream streamConfig = Resources.getResourceAsStream("sqlMapConfig.xml");
    //将流转换为配制文件配制对象
    SqlSessionFactory build = new SqlSessionFactoryBuilder().build(streamConfig);
    SqlSession sqlSession = build.openSession();
    UserMsgPO user = new UserMsgPO();
    user.setId(1);
    UserMsgPO userRsp = sqlSession.selectOne("com.liujun.learn.mybatis.mapper.UserMsgMapper.selectOne", user);
    System.out.println(userRsp);
    Assertions.assertNotNull(userRsp.getName());
  }
}
```
实体类
```java
package org.apache.use.use.po;

import java.io.Serializable;

/**
 * 用户对象
 *
 * @author liujun
 * @since 2022/6/29
 */
public class UserMsgPO implements Serializable {

  /**
   * 用户的id
   */
  private Integer id;

  /**
   * 名称的信息
   */
  private String name;

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }
  
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("UserMsgPO{");
    sb.append("id=").append(id);
    sb.append(", name='").append(name).append('\'');
    sb.append('}');
    return sb.toString();
  }
}
```
数据库配制文件
jdbc.properties
```properties
jdbc.driver=org.sqlite.JDBC
jdbc.url=jdbc:sqlite:D:/java/workspace/selfwork/github/learn/mybatis/db/mybatis.db
jdbc.username=
jdbc.password=
```
sqlMapConfig.xml
```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE configuration PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-config.dtd">
<configuration>

    <properties resource="jdbc.properties"/>

    <environments default="default">
        <environment id="default">
            <!--JDBC表示把数据库的事务交给JDBC进行管理。 MANAGER让容器进行管理，很少使用，它从来不提交回滚一个连接。-->
            <transactionManager type="JDBC"></transactionManager>
            <!--POOLED使用mybatis的连接池，UNPOOLED表示不使用连接池,每次使用数据库时才打开和关闭连接，JNDI,使用容器配制的数据源。-->
            <dataSource type="POOLED">
                <property name="driver" value="${jdbc.driver}"/>
                <property name="url" value="${jdbc.url}"/>
                <property name="username" value="${jdbc.username}"/>
                <property name="password" value="${jdbc.password}"/>
            </dataSource>
        </environment>
    </environments>

    <mappers>
        <mapper resource="UserMsgMapper.xml"/>
    </mappers>
</configuration>
```
数据库查询的配制类文件
UserMsgMapper.xml
```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE mapper
        PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.liujun.learn.mybatis.mapper.UserMsgMapper">
    <select id="selectOne" parameterType="org.apache.use.use.po.UserMsgPO"
            resultType="org.apache.use.use.po.UserMsgPO">
        select * from user_msg
        <where>
            <if test="id != null">
                and id = #{id}
            </if>
        </where>
    </select>
</mapper>
```

运行单元测试，可昨到如下结果:
```text
UserMsgPO{id=1, name='name'}
```

### 2 开始源码分析，还是从加载资源文件开始吧
```java
public class QuickStart {
  @Test
  public void baseQuery() throws IOException {
    //将mybatis的配制文件转换为流,供助类加载
    InputStream streamConfig = Resources.getResourceAsStream("sqlMapConfig.xml");
    //将流转换为配制文件配制对象
    SqlSessionFactory build = new SqlSessionFactoryBuilder().build(streamConfig);

    SqlSession sqlSession = build.openSession();

    UserMsgPO user = new UserMsgPO();
    user.setId(1);

    UserMsgPO userRsp = sqlSession.selectOne("com.liujun.learn.mybatis.mapper.UserMsgMapper.selectOne", user);
    System.out.println(userRsp);
    Assertions.assertNotNull(userRsp.getName());
  }
}
```
#### 2.1 资源加载
```java
package org.apache.ibatis.io;

/**
 * A class to simplify access to resources through the classloader.
 *
 * @author Clinton Begin
 */
public class Resources {

  /**
   * Returns a resource on the classpath as a Stream object
   * 传一个一个文件，将类加载为输入流
   *
   * @param resource The resource to find
   * @return The resource
   * @throws java.io.IOException If the resource cannot be found or read
   */
  public static InputStream getResourceAsStream(String resource) throws IOException {
    return getResourceAsStream(null, resource);
  }
  
  /**
   * Returns a resource on the classpath as a Stream object
   *
   * @param loader   The classloader used to fetch the resource
   * @param resource The resource to find
   * @return The resource
   * @throws java.io.IOException If the resource cannot be found or read
   */
  public static InputStream getResourceAsStream(ClassLoader loader, String resource) throws IOException {
    InputStream in = classLoaderWrapper.getResourceAsStream(resource, loader);
    if (in == null) {
      throw new IOException("Could not find resource " + resource);
    }
    return in;
  }
}
```
### 2.2 类加载器进行加载操作
通过当前源码中的类发加载发现，此类的加载器,是按照这样一个顺序加载:
1.当前的类加载器，如果能够加载到，则返回。如果不行，则继续
2.使用是当前ClassPath的绝对URI路径，如果能够加载到，则返回，如果加载不到则继续
3.使用当前class的类加载器，如果能够加载到，则返回，如果加载不到，则继续
4.使用当前系统的类加载器，如果加载加载到，则返回，如果加载不到，则结束
至此，InputStream streamConfig = Resources.getResourceAsStream("sqlMapConfig.xml");此源码就已经分析完成，
对类如何拿到资源文件流也有了一个清楚的了解。
```java
package org.apache.ibatis.io;

import java.io.InputStream;
import java.net.URL;

public class ClassLoaderWrapper {

  ClassLoader defaultClassLoader;
  ClassLoader systemClassLoader;

  ClassLoaderWrapper() {
    try {
      systemClassLoader = ClassLoader.getSystemClassLoader();
    } catch (SecurityException ignored) {
      // AccessControlException on Google App Engine
    }
  }

  /**
   * Get a resource from the classpath, starting with a specific class loader
   *
   * @param resource    - the resource to find
   * @param classLoader - the first class loader to try
   * @return the stream or null
   */
  public InputStream getResourceAsStream(String resource, ClassLoader classLoader) {
    return getResourceAsStream(resource, getClassLoaders(classLoader));
  }
  
  /**
   * Try to get a resource from a group of classloaders
   *
   * @param resource    - the resource to get
   * @param classLoader - the classloaders to examine
   * @return the resource or null
   */
  InputStream getResourceAsStream(String resource, ClassLoader[] classLoader) {
    for (ClassLoader cl : classLoader) {
      if (null != cl) {

        // try to find the resource as passed
        InputStream returnValue = cl.getResourceAsStream(resource);

        // now, some class loaders want this leading "/", so we'll add it and try again if we didn't find the resource
        if (null == returnValue) {
          returnValue = cl.getResourceAsStream("/" + resource);
        }

        if (null != returnValue) {
          return returnValue;
        }
      }
    }
    return null;
  }
  
  ClassLoader[] getClassLoaders(ClassLoader classLoader) {
    return new ClassLoader[]{
        //用户类加载的器
        classLoader,
        defaultClassLoader,
        //得到的也是当前ClassPath的绝对URI路径。
        Thread.currentThread().getContextClassLoader(),
        //取得当前对象所属的Class对象的类装载器
        getClass().getClassLoader(),
        //系统类加载器
        systemClassLoader};
  }

}
```

### 3.进行配制文件载加载

#### 3.1 SqlSessionFactory的build构建
现在开始SqlSessionFactory build = new SqlSessionFactoryBuilder().build(streamConfig);此源码的分析。
从字面来看，此为构建一个SqlSessionFactoryBuilder对象，然后使用build方法将文件流转换为配制对象
从源码来分析build方法，SqlSessionFactory会需要inputStream,environment,properties这三个对象分别代表了文件输入流、默认环境信息和
默认的配制。紧接着将使用XMLConfigBuilder来解析XML文件输入流.
```java
package org.apache.ibatis.session;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.util.Properties;

import org.apache.ibatis.builder.xml.XMLConfigBuilder;
import org.apache.ibatis.exceptions.ExceptionFactory;
import org.apache.ibatis.executor.ErrorContext;
import org.apache.ibatis.session.defaults.DefaultSqlSessionFactory;

public class SqlSessionFactoryBuilder {
    
  /**
   * 调用初始化构造器对象，传递了一个文件输入流
   * @param inputStream 输入流
   * @return 加载成为配制信息
   */
  public SqlSessionFactory build(InputStream inputStream) {
    //调用了重载方法，环境和属性信息为空
    return build(inputStream, null, null);
  }

  /**
   * 构建方法，解析配制文件，封装Configuration对象
   * @param inputStream 配制文件的输入流
   * @param environment 环境信息
   * @param properties 属性信息。
   * @return
   */
  public SqlSessionFactory build(InputStream inputStream, String environment, Properties properties) {
    try {
      //创建XMLConfigBuilder，XMLConfigBuilder是专门用于解析mybatis配制文件的类。
      XMLConfigBuilder parser = new XMLConfigBuilder(inputStream, environment, properties);
      //parser.parse()将配制文件转换成配制类。
      return build(parser.parse());
    } catch (Exception e) {
      throw ExceptionFactory.wrapException("Error building SqlSession.", e);
    } finally {
      ErrorContext.instance().reset();
      try {
        inputStream.close();
      } catch (IOException e) {
        // Intentionally ignore. Prefer previous error.
      }
    }
  }

  public SqlSessionFactory build(Configuration config) {
    return new DefaultSqlSessionFactory(config);
  }
}
```

#### 3.2 XMLConfigBuilder对象构建
此处在构建XMLConfigBuilder对inputStream进行了包装，转换为XPathParser对象。
其他对象会原样传递。
```java
package org.apache.ibatis.builder.xml;

public class XMLConfigBuilder extends BaseBuilder {

  private boolean parsed;
  private final XPathParser parser;
  private String environment;
  private final ReflectorFactory localReflectorFactory = new DefaultReflectorFactory();
  
  public XMLConfigBuilder(InputStream inputStream, String environment, Properties props) {
    this(new XPathParser(inputStream, true, props, new XMLMapperEntityResolver()), environment, props);
  }
  
  private XMLConfigBuilder(XPathParser parser, String environment, Properties props) {
    //创建一个新的mybatis的配制类对象.
    super(new Configuration());
    ErrorContext.instance().resource("SQL Mapper Configuration");
    this.configuration.setVariables(props);
    this.parsed = false;
    this.environment = environment;
    this.parser = parser;
  }
}
```
在构建过程中会传递一个Configuration，这个就是配制类的java实体对象。
```java
package org.apache.ibatis.builder;
public abstract class BaseBuilder {
  protected final Configuration configuration;
  protected final TypeAliasRegistry typeAliasRegistry;
  protected final TypeHandlerRegistry typeHandlerRegistry;

  public BaseBuilder(Configuration configuration) {
    this.configuration = configuration;
    this.typeAliasRegistry = this.configuration.getTypeAliasRegistry();
    this.typeHandlerRegistry = this.configuration.getTypeHandlerRegistry();
  }
}
```

#### 3.3 执行配制文件转换
通用调用XMLConfigBuilder的parse方法执行xml文件对象的转换，再交给parseConfiguration将xml文件内容解析成Configuration对象。
通过这一个个标签的加载，就将xml文件中的对象转换成了java的Configuration对象。
```java
package org.apache.ibatis.builder.xml;

public class XMLConfigBuilder extends BaseBuilder {
  private boolean parsed;
  private final XPathParser parser;
  private String environment;
  private final ReflectorFactory localReflectorFactory = new DefaultReflectorFactory();

  /**
   * 将mybatis配制对象转换为Configuration对象
   * @return
   */
  public Configuration parse() {
    //若已经解析，则抛出异常。
    if (parsed) {
      throw new BuilderException("Each XMLConfigBuilder can only be used once.");
    }
    //标记当前已经解析
    parsed = true;
    //读取mybatis配制文件的元素configuration，交给parseConfiguration方法处理
    parseConfiguration(parser.evalNode("/configuration"));
    return configuration;
  }
  
  
  private void parseConfiguration(XNode root) {
    try {
      //issue #117 read properties first
      //首先读取<properties/>标签，一般用于指定jdbc的配制文件
      propertiesElement(root.evalNode("properties"));
      //再读取<settings />标签，做一些参数的配制
      Properties settings = settingsAsProperties(root.evalNode("settings"));
      //加载自定义的实现类VFS
      loadCustomVfs(settings);
      //加载片定义的log
      loadCustomLogImpl(settings);
      //加载<typeAliases/> 做一些全局的自定义类的名称
      typeAliasesElement(root.evalNode("typeAliases"));
      //加载<plugins />加载插件类
      pluginElement(root.evalNode("plugins"));
      //解析<objectFactory />标签
      objectFactoryElement(root.evalNode("objectFactory"));
      //解析<objectWrapperFactory />标签
      objectWrapperFactoryElement(root.evalNode("objectWrapperFactory"));
      //解析reflectorFactory />标签
      reflectorFactoryElement(root.evalNode("reflectorFactory"));
      //设置<settings/>到Configuration属性中
      settingsElement(settings);
      //解析<environments /> 标签
      // read it after objectFactory and objectWrapperFactory issue #631
      environmentsElement(root.evalNode("environments"));
      // 解析<databaseIdProvider />标签
      databaseIdProviderElement(root.evalNode("databaseIdProvider"));
      //解析<typeHandlers />标签
      typeHandlerElement(root.evalNode("typeHandlers"));
      //加载<mappers />映射的配制文件
      //解析其中的<insert,<update,<delete,<select等，将其转换为MappedStatement对象
      mapperElement(root.evalNode("mappers"));
    } catch (Exception e) {
      throw new BuilderException("Error parsing SQL Mapper Configuration. Cause: " + e, e);
    }
  }  
}
```

#### 3.4 调用build方法传递Configuration对象将构建DefaultSqlSessionFactory对象
当xml文件完全转换为Configuration对象后将调用
```java
package org.apache.ibatis.session;
public class SqlSessionFactoryBuilder {
 
  public SqlSessionFactory build(Configuration config) {
    return new DefaultSqlSessionFactory(config);
  }
}
```

### 4.SQL执行的流程
先以一张图以宏观的视角来看看整个交互的流程吧。
![](resource\images\mybatis的整体结构.png)

在源码之前，先说明下SqlSession和Executor
SqlSession：
>SqlSession是一个接口，它有两个实现类:DefaultSqlSession（默认）和SqlSessionManager(弃用)
>SqlSession是Mybatis中用于和数据库交互的顶层类，通常它与ThreadLocal绑定，一个会话使用一个SqlSession，并且使用完毕后需要关闭
>
>两个最重要的参数:Configuration与初始化时的相同，Executor为执行器对象
>
Executor:
>也是一个接口，它有三个常用的实现类:
>BatchExecutor:(重用语句并执行批量更新)
>ReuseExecutor:(重用预处理语句prepare statement)
>SimpleExecutor:(普通的执行器，默认)
>

#### 4.1 openSession()
点开openSession这个方法，就来到了一个SqlSessionFactory接口类
```java
package org.apache.ibatis.session;

public interface SqlSessionFactory {

  SqlSession openSession();

  SqlSession openSession(boolean autoCommit);

  SqlSession openSession(Connection connection);

  SqlSession openSession(TransactionIsolationLevel level);

  SqlSession openSession(ExecutorType execType);

  SqlSession openSession(ExecutorType execType, boolean autoCommit);

  SqlSession openSession(ExecutorType execType, TransactionIsolationLevel level);

  SqlSession openSession(ExecutorType execType, Connection connection);

  Configuration getConfiguration();
}
```
找到此类的一个实现:DefaultSqlSessionFactory
查看openSession方法，就能发现在执行openSession时，会创建一个事务管理对象,再创建一个默认的SQL执行器，最后返回默认的SqlSession对象.
```java
package org.apache.ibatis.session.defaults;

public class DefaultSqlSessionFactory implements SqlSessionFactory {

  private final Configuration configuration;

  public DefaultSqlSessionFactory(Configuration configuration) {
    this.configuration = configuration;
  }

  @Override
  public SqlSession openSession() {
    //configuration.getDefaultExecutorType()此处将拿到一个ExecutorType.SIMPLE，默认的SQL执行器对象
    //level参数表示当前数据库的事务隔离级别。
    //autoCommit，false不自动提交事务。
    return openSessionFromDataSource(configuration.getDefaultExecutorType(), null, false);
  }

  private SqlSession openSessionFromDataSource(ExecutorType execType, TransactionIsolationLevel level, boolean autoCommit) {
    Transaction tx = null;
    try {
      //获得一个Environment对象,运行环境对象
      final Environment environment = configuration.getEnvironment();
      //获得Transaction对象，事务对象
      final TransactionFactory transactionFactory = getTransactionFactoryFromEnvironment(environment);
      tx = transactionFactory.newTransaction(environment.getDataSource(), level, autoCommit);
      //创建Executor对象，执行器对象的创建。
      final Executor executor = configuration.newExecutor(tx, execType);
      //创建DefaultSqlSession对象
      return new DefaultSqlSession(configuration, executor, autoCommit);
    } catch (Exception e) {
      closeTransaction(tx); // may have fetched a connection so lets call close()
      throw ExceptionFactory.wrapException("Error opening session.  Cause: " + e, e);
    } finally {
      ErrorContext.instance().reset();
    }
  }

  private TransactionFactory getTransactionFactoryFromEnvironment(Environment environment) {
    if (environment == null || environment.getTransactionFactory() == null) {
      return new ManagedTransactionFactory();
    }
    return environment.getTransactionFactory();
  }

  private void closeTransaction(Transaction tx) {
    if (tx != null) {
      try {
        tx.close();
      } catch (SQLException ignore) {
        // Intentionally ignore. Prefer previous error.
      }
    }
  }

}
```

```java
package org.apache.ibatis.session;
public class Configuration {
  protected ExecutorType defaultExecutorType = ExecutorType.SIMPLE;    
  public ExecutorType getDefaultExecutorType() {
    return defaultExecutorType;
  }
}
```

#### 4.2 执行SQL
执行SQL是就测试代码中的：
```
UserMsgPO userRsp = sqlSession.selectOne("com.liujun.learn.mybatis.mapper.UserMsgMapper.selectOne", user);
```
跟踪源来则来到了DefaultSqlSession的selectOne方法，通过分析可知，
selectOne调用了selectList，
在selectList中通过获得MappedStatement对象，以及执行executor的query方法。
```java
package org.apache.ibatis.session.defaults;

public class DefaultSqlSession implements SqlSession {

  private final Configuration configuration;
  private final Executor executor;

  private final boolean autoCommit;
  private boolean dirty;
  private List<Cursor<?>> cursorList;

  public DefaultSqlSession(Configuration configuration, Executor executor, boolean autoCommit) {
    this.configuration = configuration;
    this.executor = executor;
    this.dirty = false;
    this.autoCommit = autoCommit;
  }

  public DefaultSqlSession(Configuration configuration, Executor executor) {
    this(configuration, executor, false);
  }

  @Override
  public <T> T selectOne(String statement, Object parameter) {
    // Popular vote was to return null on 0 results and throw exception on too many.
    //首先调用查询查询结果的方法。使用namespace.id及参数调用
    List<T> list = this.selectList(statement, parameter);
    if (list.size() == 1) {
      return list.get(0);
    } else if (list.size() > 1) {
      throw new TooManyResultsException("Expected one result (or null) to be returned by selectOne(), but found: " + list.size());
    } else {
      return null;
    }
  }


  @Override
  public <E> List<E> selectList(String statement, Object parameter) {
    //传递namespaceId加查询参数，再传递一个默认的分页对象
    return this.selectList(statement, parameter, RowBounds.DEFAULT);
  }

  @Override
  public <E> List<E> selectList(String statement, Object parameter, RowBounds rowBounds) {
    try {
      //Map<String, MappedStatement>这个对象中获得MappedStatement对象。
      MappedStatement ms = configuration.getMappedStatement(statement);
      //执行查询，次级Executor对象来执行查询。
      return executor.query(ms, wrapCollection(parameter), rowBounds, Executor.NO_RESULT_HANDLER);
    } catch (Exception e) {
      throw ExceptionFactory.wrapException("Error querying database.  Cause: " + e, e);
    } finally {
      ErrorContext.instance().reset();
    }
  }
}

```

继续跟踪Executor的源查，查看query方法的执行
```java
package org.apache.ibatis.executor;

public interface Executor {

  ResultHandler NO_RESULT_HANDLER = null;

  int update(MappedStatement ms, Object parameter) throws SQLException;

  <E> List<E> query(MappedStatement ms, Object parameter, RowBounds rowBounds, ResultHandler resultHandler, CacheKey cacheKey, BoundSql boundSql) throws SQLException;

  <E> List<E> query(MappedStatement ms, Object parameter, RowBounds rowBounds, ResultHandler resultHandler) throws SQLException;

  <E> Cursor<E> queryCursor(MappedStatement ms, Object parameter, RowBounds rowBounds) throws SQLException;

  List<BatchResult> flushStatements() throws SQLException;

  void commit(boolean required) throws SQLException;

  void rollback(boolean required) throws SQLException;

  CacheKey createCacheKey(MappedStatement ms, Object parameterObject, RowBounds rowBounds, BoundSql boundSql);

  boolean isCached(MappedStatement ms, CacheKey key);

  void clearLocalCache();

  void deferLoad(MappedStatement ms, MetaObject resultObject, String property, CacheKey key, Class<?> targetType);

  Transaction getTransaction();

  void close(boolean forceRollback);

  boolean isClosed();

  void setExecutorWrapper(Executor executor);

}
```
此时便用来了BaseExecutor，我们经过之前的分析可知Executor的默认实现是SimpleExecutor，此时却来得到BaseExecutor,那这是为什么呢？
这个就是因为BaseExecutor是SimpleExecutor的父类，query方法在BaseExecutor中实现的。
```java
package org.apache.ibatis.executor;

public abstract class BaseExecutor implements Executor {

  @Override
  public <E> List<E> query(MappedStatement ms, Object parameter, RowBounds rowBounds, ResultHandler resultHandler) throws SQLException {
    //根据传入的参数动态获得SQL，最后返回用BoundSql封装的SQL对象
    BoundSql boundSql = ms.getBoundSql(parameter);
    //创建本次查询缓存的key
    CacheKey key = createCacheKey(ms, parameter, rowBounds, boundSql);
    //执行查询
    return query(ms, parameter, rowBounds, resultHandler, key, boundSql);
  }

  @SuppressWarnings("unchecked")
  @Override
  public <E> List<E> query(MappedStatement ms, Object parameter, RowBounds rowBounds, ResultHandler resultHandler, CacheKey key, BoundSql boundSql) throws SQLException {
    ErrorContext.instance().resource(ms.getResource()).activity("executing a query").object(ms.getId());
    //首先检查执行器有没有被关闭，如果关闭，则报出异常。
    if (closed) {
      throw new ExecutorException("Executor was closed.");
    }
    //清空本地缓存，如果queryStack为0，并且要求清空缓存，则执行本地清空缓存。
    if (queryStack == 0 && ms.isFlushCacheRequired()) {
      clearLocalCache();
    }
    List<E> list;
    try {
      queryStack++;
      //从一级缓存中获取结果。
      list = resultHandler == null ? (List<E>) localCache.getObject(key) : null;
      //如果一级缓存能够获得，则从一级缓存中构建结果返回。
      if (list != null) {
        handleLocallyCachedOutputParameters(ms, key, parameter, boundSql);
      }
      //一级缓存中未获得，则执行数据库的查询操作。
      else {
        list = queryFromDatabase(ms, parameter, rowBounds, resultHandler, key, boundSql);
      }
    } finally {
      queryStack--;
    }
    if (queryStack == 0) {
      for (DeferredLoad deferredLoad : deferredLoads) {
        deferredLoad.load();
      }
      // issue #601
      deferredLoads.clear();
      if (configuration.getLocalCacheScope() == LocalCacheScope.STATEMENT) {
        // issue #482
        clearLocalCache();
      }
    }
    return list;
  }

  private <E> List<E> queryFromDatabase(MappedStatement ms, Object parameter, RowBounds rowBounds, ResultHandler resultHandler, CacheKey key, BoundSql boundSql) throws SQLException {
    List<E> list;
    //在缓存中添加占位对象，此处占位符，和延迟加载有关。
    localCache.putObject(key, EXECUTION_PLACEHOLDER);
    try {
      //执行数据库查询操作
      list = doQuery(ms, parameter, rowBounds, resultHandler, boundSql);
    } finally {
      //从缓存中移除占位对象，
      localCache.removeObject(key);
    }
    //将查询的数据保存到缓存中
    localCache.putObject(key, list);
    //存储过程相关的执行，可暂时忽略。
    if (ms.getStatementType() == StatementType.CALLABLE) {
      localOutputParameterCache.putObject(key, parameter);
    }
    return list;
  }
}
```
继续跟踪源查看doQuery方法则是在SimpleExecutor实现
```java
package org.apache.ibatis.executor;

public class SimpleExecutor extends BaseExecutor {

  @Override
  public <E> List<E> doQuery(MappedStatement ms, Object parameter, RowBounds rowBounds, ResultHandler resultHandler, BoundSql boundSql) throws SQLException {
    Statement stmt = null;
    try {
      Configuration configuration = ms.getConfiguration();
      //根据传入的对象创建一个StatementHandler对象来执行查询。
      StatementHandler handler = configuration.newStatementHandler(wrapper, ms, parameter, rowBounds, resultHandler, boundSql);
      //初始化StatementHandler对象。
      stmt = prepareStatement(handler, ms.getStatementLog());
      //执行StatementHandler对象上的查询操作。
      return handler.query(stmt, resultHandler);
    } finally {
      //关闭StatementHandler对象
      closeStatement(stmt);
    }
  }

  private Statement prepareStatement(StatementHandler handler, Log statementLog) throws SQLException {
    Statement stmt;
    //获取数据库连接对象
    Connection connection = getConnection(statementLog);
    //创建Statement或者PrepareStatement对象。
    stmt = handler.prepare(connection, transaction.getTimeout());
    //设置SQL参数，例如PrepareStatement对象上的占位符对象。
    handler.parameterize(stmt);
    return stmt;
  }
}
```

#### 4.3 StatementHandler的参数设置
首先还是来看看参数是如何处理的？也就是在prepareStatement方法中调用的parameterize方法.DefaultSqlSession
首先看到StatementHandler的接口，这个接口中，定义了相关的查询参数设置等方法接口
```java
package org.apache.ibatis.executor.statement;

public interface StatementHandler {

  Statement prepare(Connection connection, Integer transactionTimeout)
      throws SQLException;

  void parameterize(Statement statement)
      throws SQLException;

  void batch(Statement statement)
      throws SQLException;

  int update(Statement statement)
      throws SQLException;

  <E> List<E> query(Statement statement, ResultHandler resultHandler)
      throws SQLException;

  <E> Cursor<E> queryCursor(Statement statement)
      throws SQLException;

  BoundSql getBoundSql();

  ParameterHandler getParameterHandler();

}
```
接下来看看参数设置的实现。
在mybatis源码中默认的实现是PreparedStatementHandler,跟踪参数设置方法parameterize
```java
package org.apache.ibatis.executor.statement;

public class PreparedStatementHandler extends BaseStatementHandler {

  @Override
  public void parameterize(Statement statement) throws SQLException {
    parameterHandler.setParameters((PreparedStatement) statement);
  }
}
```
此时便来到了ParameterHandler接口
```java
package org.apache.ibatis.executor.parameter;
public interface ParameterHandler {
  Object getParameterObject();

  void setParameters(PreparedStatement ps)
      throws SQLException;
}

```
继续跟到实现类DefaultParameterHandler类，可以看到此设置参数的实现。
```java
package org.apache.ibatis.scripting.defaults;

public class DefaultParameterHandler implements ParameterHandler {

  private final TypeHandlerRegistry typeHandlerRegistry;

  private final MappedStatement mappedStatement;
  private final Object parameterObject;
  private final BoundSql boundSql;
  private final Configuration configuration;

  public DefaultParameterHandler(MappedStatement mappedStatement, Object parameterObject, BoundSql boundSql) {
    this.mappedStatement = mappedStatement;
    this.configuration = mappedStatement.getConfiguration();
    this.typeHandlerRegistry = mappedStatement.getConfiguration().getTypeHandlerRegistry();
    this.parameterObject = parameterObject;
    this.boundSql = boundSql;
  }

  @Override
  public Object getParameterObject() {
    return parameterObject;
  }

  @Override
  public void setParameters(PreparedStatement ps) {
    ErrorContext.instance().activity("setting parameters").object(mappedStatement.getParameterMap().getId());
    //得到ParameterMapping集合对象，也就是解析SQL中的参数中的占位符
    List<ParameterMapping> parameterMappings = boundSql.getParameterMappings();
    if (parameterMappings != null) {
      for (int i = 0; i < parameterMappings.size(); i++) {
        ParameterMapping parameterMapping = parameterMappings.get(i);
        if (parameterMapping.getMode() != ParameterMode.OUT) {
          Object value;
          //获得参数的名称
          String propertyName = parameterMapping.getProperty();
          //再获得参数的值
          if (boundSql.hasAdditionalParameter(propertyName)) { // issue #448 ask first for additional params
            value = boundSql.getAdditionalParameter(propertyName);
          } else if (parameterObject == null) {
            value = null;
          } else if (typeHandlerRegistry.hasTypeHandler(parameterObject.getClass())) {
            value = parameterObject;
          } else {
            //通过反射技术动态的获取参数值
            MetaObject metaObject = configuration.newMetaObject(parameterObject);
            value = metaObject.getValue(propertyName);
          }
          //使用TypeHandler在jdbcType与javaType之间想到转换
          TypeHandler typeHandler = parameterMapping.getTypeHandler();
          JdbcType jdbcType = parameterMapping.getJdbcType();
          if (value == null && jdbcType == null) {
            jdbcType = configuration.getJdbcTypeForNull();
          }
          try {
            //将参数设置到Statement对象上 此参数设置的也就是？占位符的参数
            typeHandler.setParameter(ps, i + 1, value, jdbcType);
          } catch (TypeException | SQLException e) {
            throw new TypeException("Could not set parameters for mapping: " + parameterMapping + ". Cause: " + e, e);
          }
        }
      }
    }
  }
}
```
#### 4.4 StatementHandler的查询处理
现在来具体年看看StatementHandler是怎么处理查询的?同样的，还是PreparedStatementHandler，这次调用就是query方法。
此处调用仅两句话，执行SQL将结果交给resultSetHandler进行处理。
##### 4.4.1 获得结果集对象
```java
package org.apache.ibatis.executor.statement;

public class PreparedStatementHandler extends BaseStatementHandler {
  @Override
  public <E> List<E> query(Statement statement, ResultHandler resultHandler) throws SQLException {
    //将传递的参数转换为编译的Statement对象
    PreparedStatement ps = (PreparedStatement) statement;
    //执行SQL的查询操作
    ps.execute();
    //结果集的处理
    return resultSetHandler.handleResultSets(ps);
  }
}
```
接下来将看到对于结果集封装的代码
```java
package org.apache.ibatis.executor.resultset;

public class DefaultResultSetHandler implements ResultSetHandler {

  private final MappedStatement mappedStatement;

  @Override
  public List<Object> handleResultSets(Statement stmt) throws SQLException {
    ErrorContext.instance().activity("handling results").object(mappedStatement.getId());

    //多结构集对象，这个一般在存储过程才会有多个结果集返回，一般查询仅一个
    final List<Object> multipleResults = new ArrayList<>();

    int resultSetCount = 0;
    //读取首个结果集对象，并封装成为ResultSetWrapper对象
    ResultSetWrapper rsw = getFirstResultSet(stmt);

    List<ResultMap> resultMaps = mappedStatement.getResultMaps();
    int resultMapCount = resultMaps.size();
    //执行校验
    validateResultMapsCount(rsw, resultMapCount);
    while (rsw != null && resultMapCount > resultSetCount) {
      //获取到resultMap对象
      ResultMap resultMap = resultMaps.get(resultSetCount);
      //处理结果对象，将结果添加到multipleResults对象中
      handleResultSet(rsw, resultMap, multipleResults, null);
      //检查是否还存在一个结果集
      rsw = getNextResultSet(stmt);
      cleanUpAfterHandlingResultSet();
      resultSetCount++;
    }

    //可忽略
    String[] resultSets = mappedStatement.getResultSets();
    if (resultSets != null) {
      while (rsw != null && resultSetCount < resultSets.length) {
        ResultMapping parentMapping = nextResultMaps.get(resultSets[resultSetCount]);
        if (parentMapping != null) {
          String nestedResultMapId = parentMapping.getNestedResultMapId();
          ResultMap resultMap = configuration.getResultMap(nestedResultMapId);
          handleResultSet(rsw, resultMap, null, parentMapping);
        }
        rsw = getNextResultSet(stmt);
        cleanUpAfterHandlingResultSet();
        resultSetCount++;
      }
    }

    return collapseSingleResultList(multipleResults);
  }
  
  /**
   * 获取结果集，并包装成ResultSetWrapper对象，拿不到结果集，返回为null
   * @param stmt
   * @return
   * @throws SQLException
   */
  private ResultSetWrapper getFirstResultSet(Statement stmt) throws SQLException {
    ResultSet rs = stmt.getResultSet();
    while (rs == null) {
      // move forward to get the first resultset in case the driver
      // doesn't return the resultset as the first result (HSQLDB 2.1)
      if (stmt.getMoreResults()) {
        rs = stmt.getResultSet();
      } else {
        if (stmt.getUpdateCount() == -1) {
          // no more results. Must be no resultset
          break;
        }
      }
    }
    //当结果集拿到之后，进行封装操作
    return rs != null ? new ResultSetWrapper(rs, configuration) : null;
  }
  
  private void validateResultMapsCount(ResultSetWrapper rsw, int resultMapCount) {
    if (rsw != null && resultMapCount < 1) {
      throw new ExecutorException("A query was run and no Result Maps were found for the Mapped Statement '" + mappedStatement.getId()
        + "'.  It's likely that neither a Result Type nor a Result Map was specified.");
    }
  }
  
  private void handleResultSet(ResultSetWrapper rsw, ResultMap resultMap, List<Object> multipleResults, ResultMapping parentMapping) throws SQLException {
    try {
      //此可暂时忽略，此在存储过程时才会调用。
      if (parentMapping != null) {
        handleRowValues(rsw, resultMap, null, RowBounds.DEFAULT, parentMapping);
      } else {
        //如果没有默认的resultHandler，则创建一个DefaultResultHandler对象。
        if (resultHandler == null) {
          //创建DefaultResultHandler对象
          DefaultResultHandler defaultResultHandler = new DefaultResultHandler(objectFactory);
          //处理ResultSet,返回每一行记录.
          handleRowValues(rsw, resultMap, defaultResultHandler, rowBounds, null);
          //添加DefaultResultHandler的处理结果到multipleResults对象中
          multipleResults.add(defaultResultHandler.getResultList());
        } else {
          handleRowValues(rsw, resultMap, resultHandler, rowBounds, null);
        }
      }
    } finally {
      // issue #228 (close resultsets)
      closeResultSet(rsw.getResultSet());
    }
  } 

  public void handleRowValues(ResultSetWrapper rsw, ResultMap resultMap, ResultHandler<?> resultHandler, RowBounds rowBounds, ResultMapping parentMapping) throws SQLException {
    if (resultMap.hasNestedResultMaps()) {
      ensureNoRowBounds();
      checkResultHandler();
      handleRowValuesForNestedResultMap(rsw, resultMap, resultHandler, rowBounds, parentMapping);
    }
    //普通的查询一般都执行这个结果集封装
    else {
      handleRowValuesForSimpleResultMap(rsw, resultMap, resultHandler, rowBounds, parentMapping);
    }
  }

  private void handleRowValuesForSimpleResultMap(ResultSetWrapper rsw, ResultMap resultMap, ResultHandler<?> resultHandler, RowBounds rowBounds, ResultMapping parentMapping)
    throws SQLException {
    DefaultResultContext<Object> resultContext = new DefaultResultContext<>();
    //拿到结果对象ResultSet
    ResultSet resultSet = rsw.getResultSet();
    //检查跳过行
    skipRows(resultSet, rowBounds);
    //遍历数据行完成数据的封装操作
    while (shouldProcessMoreRows(resultContext, rowBounds) && !resultSet.isClosed() && resultSet.next()) {
	  //对resultMap中的discriminator标签做特殊处理	
      ResultMap discriminatedResultMap = resolveDiscriminatedResultMap(resultSet, resultMap, null);
      //结果行的封装
      Object rowValue = getRowValue(rsw, discriminatedResultMap, null);
      storeObject(resultHandler, resultContext, rowValue, parentMapping, resultSet);
    }
  } 

  /**
   * 对每行数据做封装操作
   * @param rsw 结果集对象
   * @param resultMap 返回的对象描述信息
   * @param columnPrefix
   * @return
   * @throws SQLException
   */
  private Object getRowValue(ResultSetWrapper rsw, ResultMap resultMap, String columnPrefix) throws SQLException {
    final ResultLoaderMap lazyLoader = new ResultLoaderMap();
    //创建返回的结果对象
    Object rowValue = createResultObject(rsw, resultMap, lazyLoader, columnPrefix);
    if (rowValue != null && !hasTypeHandlerForResultObject(rsw, resultMap.getType())) {
      final MetaObject metaObject = configuration.newMetaObject(rowValue);
      boolean foundValues = this.useConstructorMappings;
      //按照配制默认的字段映射关系进行属性的值设置操作
      if (shouldApplyAutomaticMappings(resultMap, false)) {
        foundValues = applyAutomaticMappings(rsw, resultMap, metaObject, columnPrefix) || foundValues;
      }
      foundValues = applyPropertyMappings(rsw, resultMap, metaObject, lazyLoader, columnPrefix) || foundValues;
      foundValues = lazyLoader.size() > 0 || foundValues;
      rowValue = foundValues || configuration.isReturnInstanceForEmptyRow() ? rowValue : null;
    }
    return rowValue;
  }  
  
  private Object createResultObject(ResultSetWrapper rsw, ResultMap resultMap, ResultLoaderMap lazyLoader, String columnPrefix) throws SQLException {
    this.useConstructorMappings = false; // reset previous mapping result
    final List<Class<?>> constructorArgTypes = new ArrayList<>();
    final List<Object> constructorArgs = new ArrayList<>();
    //执行结果对象的创建
    Object resultObject = createResultObject(rsw, resultMap, constructorArgTypes, constructorArgs, columnPrefix);
    if (resultObject != null && !hasTypeHandlerForResultObject(rsw, resultMap.getType())) {
      final List<ResultMapping> propertyMappings = resultMap.getPropertyResultMappings();
      for (ResultMapping propertyMapping : propertyMappings) {
        // issue gcode #109 && issue #149
        if (propertyMapping.getNestedQueryId() != null && propertyMapping.isLazy()) {
          resultObject = configuration.getProxyFactory().createProxy(resultObject, lazyLoader, configuration, objectFactory, constructorArgTypes, constructorArgs);
          break;
        }
      }
    }
    this.useConstructorMappings = resultObject != null && !constructorArgTypes.isEmpty(); // set current mapping result
    return resultObject;
  }
  
  private Object createResultObject(ResultSetWrapper rsw, ResultMap resultMap, List<Class<?>> constructorArgTypes, List<Object> constructorArgs, String columnPrefix)
    throws SQLException {
    final Class<?> resultType = resultMap.getType();
    final MetaClass metaType = MetaClass.forClass(resultType, reflectorFactory);
    final List<ResultMapping> constructorMappings = resultMap.getConstructorResultMappings();
    if (hasTypeHandlerForResultObject(rsw, resultType)) {
      return createPrimitiveResultObject(rsw, resultMap, columnPrefix);
    }
    else if (!constructorMappings.isEmpty()) {
      return createParameterizedResultObject(rsw, resultType, constructorMappings, constructorArgTypes, constructorArgs, columnPrefix);
    }
    //当返回结果是一个接口或者存在默认构建方法时，执行此创建
    else if (resultType.isInterface() || metaType.hasDefaultConstructor()) {
      return objectFactory.create(resultType);
    } else if (shouldApplyAutomaticMappings(resultMap, false)) {
      return createByConstructorSignature(rsw, resultType, constructorArgTypes, constructorArgs);
    }
    throw new ExecutorException("Do not know how to create an instance of " + resultType);
  }  
}
```

##### 4.4.2 创建映射的java对象
针对以上代码的调用将执行DefaultObjectFactory的创建方法
经过对象的判断以及对象的实例构建，便可拿到对象的实例。
```java
package org.apache.ibatis.reflection.factory;

public class DefaultObjectFactory implements ObjectFactory, Serializable {
  @Override
  public <T> T create(Class<T> type) {
    //创建对象的创建操作
    return create(type, null, null);
  }

  @SuppressWarnings("unchecked")
  @Override
  public <T> T create(Class<T> type, List<Class<?>> constructorArgTypes, List<Object> constructorArgs) {
    //首先拿到创建的类型对象
    Class<?> classToCreate = resolveInterface(type);
    // we know types are assignable
    return (T) instantiateClass(classToCreate, constructorArgTypes, constructorArgs);
  }

  private  <T> T instantiateClass(Class<T> type, List<Class<?>> constructorArgTypes, List<Object> constructorArgs) {
    try {
      Constructor<T> constructor;
      //调用构建方法执行对象的创建操作
      if (constructorArgTypes == null || constructorArgs == null) {
        constructor = type.getDeclaredConstructor();
        try {
          return constructor.newInstance();
        } catch (IllegalAccessException e) {
          if (Reflector.canControlMemberAccessible()) {
            constructor.setAccessible(true);
            return constructor.newInstance();
          } else {
            throw e;
          }
        }
      }
	  //构建函数存在参数的构建方法
      constructor = type.getDeclaredConstructor(constructorArgTypes.toArray(new Class[constructorArgTypes.size()]));
      try {
        return constructor.newInstance(constructorArgs.toArray(new Object[constructorArgs.size()]));
      } catch (IllegalAccessException e) {
        if (Reflector.canControlMemberAccessible()) {
          constructor.setAccessible(true);
          return constructor.newInstance(constructorArgs.toArray(new Object[constructorArgs.size()]));
        } else {
          throw e;
        }
      }
    } catch (Exception e) {
      String argTypes = Optional.ofNullable(constructorArgTypes).orElseGet(Collections::emptyList)
          .stream().map(Class::getSimpleName).collect(Collectors.joining(","));
      String argValues = Optional.ofNullable(constructorArgs).orElseGet(Collections::emptyList)
          .stream().map(String::valueOf).collect(Collectors.joining(","));
      throw new ReflectionException("Error instantiating " + type + " with invalid types (" + argTypes + ") or values (" + argValues + "). Cause: " + e, e);
    }
  }

  protected Class<?> resolveInterface(Class<?> type) {
    Class<?> classToCreate;
    if (type == List.class || type == Collection.class || type == Iterable.class) {
      classToCreate = ArrayList.class;
    } else if (type == Map.class) {
      classToCreate = HashMap.class;
    } else if (type == SortedSet.class) { // issue #510 Collections Support
      classToCreate = TreeSet.class;
    } else if (type == Set.class) {
      classToCreate = HashSet.class;
    } else {
      classToCreate = type;
    }
    return classToCreate;
  }

  @Override
  public <T> boolean isCollection(Class<T> type) {
    return Collection.class.isAssignableFrom(type);
  }
}
```
对象已经创建了，接下来回到DefaultResultSetHandler，看是如何做对象的设置属性的。要设置属性需要先读取数据库对应字段的值
```java
package org.apache.ibatis.executor.resultset;

public class DefaultResultSetHandler implements ResultSetHandler {

  private final MappedStatement mappedStatement;

  /**
   * 对每行数据做封装操作
   * @param rsw 结果集对象
   * @param resultMap 返回的对象描述信息
   * @param columnPrefix
   * @return
   * @throws SQLException
   */
  private Object getRowValue(ResultSetWrapper rsw, ResultMap resultMap, String columnPrefix) throws SQLException {
    final ResultLoaderMap lazyLoader = new ResultLoaderMap();
    //创建返回的结果对象
    Object rowValue = createResultObject(rsw, resultMap, lazyLoader, columnPrefix);
    if (rowValue != null && !hasTypeHandlerForResultObject(rsw, resultMap.getType())) {
      final MetaObject metaObject = configuration.newMetaObject(rowValue);
      boolean foundValues = this.useConstructorMappings;
      //按照配制的字段映射关系进行属性的值设置操作
      if (shouldApplyAutomaticMappings(resultMap, false)) {
        foundValues = applyAutomaticMappings(rsw, resultMap, metaObject, columnPrefix) || foundValues;
      }
      foundValues = applyPropertyMappings(rsw, resultMap, metaObject, lazyLoader, columnPrefix) || foundValues;
      foundValues = lazyLoader.size() > 0 || foundValues;
      rowValue = foundValues || configuration.isReturnInstanceForEmptyRow() ? rowValue : null;
    }
    return rowValue;
  }  
  
  /**
   * 判断当前自动映射的模式，是否为自动映射，
   * @param resultMap
   * @param isNested
   * @return
   */
  private boolean shouldApplyAutomaticMappings(ResultMap resultMap, boolean isNested) {
    if (resultMap.getAutoMapping() != null) {
      return resultMap.getAutoMapping();
    } else {
      if (isNested) {
        return AutoMappingBehavior.FULL == configuration.getAutoMappingBehavior();
      } else {
        return AutoMappingBehavior.NONE != configuration.getAutoMappingBehavior();
      }
    }
  } 
  
  private boolean applyAutomaticMappings(ResultSetWrapper rsw, ResultMap resultMap, MetaObject metaObject, String columnPrefix) throws SQLException {
   //创建一个映射关系的集合,即column与java属性的field字段之间的映射关系,以及jdbcType与javaType之间的映射关系
    List<UnMappedColumnAutoMapping> autoMapping = createAutomaticMappings(rsw, resultMap, metaObject, columnPrefix);
    boolean foundValues = false;
    if (!autoMapping.isEmpty()) {
      for (UnMappedColumnAutoMapping mapping : autoMapping) {
        //从结果集中拿到当前属性的值
        //mapping.typeHandler中为类型转换器。
        final Object value = mapping.typeHandler.getResult(rsw.getResultSet(), mapping.column);
        if (value != null) {
          foundValues = true;
        }
        if (value != null || (configuration.isCallSettersOnNulls() && !mapping.primitive)) {
          // gcode issue #377, call setter on nulls (value is not 'found')
          metaObject.setValue(mapping.property, value);
        }
      }
    }
    return foundValues;
  }
     
}
```

##### 4.4.3 数据库字段值的获取
经过以上的代码属性已经拿到，接下来就是调用转换器拿到对应的值。首先这里的mapping.typeHandler根据字段的影射关系会得到对应的Handler处理类。
以id为例，id是Integer类型，对应的转换类就是IntegerTypeHandler
那是如何转换的呢？
首先调用的是BaseTypeHandler，这基础的转换器的父类,IntegerTypeHandler是其子类的一个实现。
```java
package org.apache.ibatis.type;

public abstract class BaseTypeHandler<T> extends TypeReference<T> implements TypeHandler<T> {

  @Override
  public T getResult(ResultSet rs, String columnName) throws SQLException {
    try {
      return getNullableResult(rs, columnName);
    } catch (Exception e) {
      throw new ResultMapException("Error attempting to get column '" + columnName + "' from result set.  Cause: " + e, e);
    }
  }
}

```
当调用完父类的模板方法时，便会调用子类的getNullableResult方法，做具体值的转换。
```java
package org.apache.ibatis.type;

public class IntegerTypeHandler extends BaseTypeHandler<Integer> {

  @Override
  public Integer getNullableResult(ResultSet rs, String columnName)
      throws SQLException {
    int result = rs.getInt(columnName);
    return result == 0 && rs.wasNull() ? null : result;
  } 
}

```
至此就拿到的属性的值

##### 4.4.4 将属性值设置至java的属性中
对象已经创建了，接下来回到DefaultResultSetHandler，看是如何做对象的设置属性的。要设置属性需要先读取数据库对应字段的值
即调用了 metaObject.setValue(mapping.property, value);操作
```java
package org.apache.ibatis.executor.resultset;

public class DefaultResultSetHandler implements ResultSetHandler {  
  private boolean applyAutomaticMappings(ResultSetWrapper rsw, ResultMap resultMap, MetaObject metaObject, String columnPrefix) throws SQLException {
   //创建一个映射关系的集合,即column与java属性的field字段之间的映射关系,以及jdbcType与javaType之间的映射关系
    List<UnMappedColumnAutoMapping> autoMapping = createAutomaticMappings(rsw, resultMap, metaObject, columnPrefix);
    boolean foundValues = false;
    if (!autoMapping.isEmpty()) {
      for (UnMappedColumnAutoMapping mapping : autoMapping) {
        //从结果集中拿到当前属性的值
        //mapping.typeHandler中为类型转换器。
        final Object value = mapping.typeHandler.getResult(rsw.getResultSet(), mapping.column);
        if (value != null) {
          foundValues = true;
        }
        if (value != null || (configuration.isCallSettersOnNulls() && !mapping.primitive)) {
          // gcode issue #377, call setter on nulls (value is not 'found')
          metaObject.setValue(mapping.property, value);
        }
      }
    }
    return foundValues;
  }
}
```

BeanWrapper值设置操作
```java
package org.apache.ibatis.reflection.wrapper;

public class BeanWrapper extends BaseWrapper {

  @Override
  public void set(PropertyTokenizer prop, Object value) {
    //集合中的一个值的处理
    if (prop.getIndex() != null) {
      Object collection = resolveCollection(prop, object);
      setCollectionValue(prop, collection, value);
    }
    //普通属性的处理
    else {
      setBeanProperty(prop, object, value);
    }
  }
  
  /**
   * 设置java属性的值
   * @param prop 属性信息
   * @param object 对象信息
   * @param value 值
   */
  private void setBeanProperty(PropertyTokenizer prop, Object object, Object value) {
    try {
      //获取属性的Set方法
      Invoker method = metaClass.getSetInvoker(prop.getName());
      Object[] params = {value};
      try {
        //调用Set方法进行值的设置操作
        method.invoke(object, params);
      } catch (Throwable t) {
        throw ExceptionUtil.unwrapThrowable(t);
      }
    } catch (Throwable t) {
      throw new ReflectionException("Could not set property '" + prop.getName() + "' of '" + object.getClass() + "' with value '" + value + "' Cause: " + t.toString(), t);
    }
  }  

}

```
至此，查询的结果就封装到java对象中去了。

### 5.结果返回
当之前的封装返回结果集都完毕之后,结果集都封装到了multipleResults中，这时候将结果集首个返回就对结果集处理结束。
```java
package org.apache.ibatis.executor.resultset;

public class DefaultResultSetHandler implements ResultSetHandler {

  private final MappedStatement mappedStatement;

  @Override
  public List<Object> handleResultSets(Statement stmt) throws SQLException {
    ErrorContext.instance().activity("handling results").object(mappedStatement.getId());

    //多结构集对象，这个一般在存储过程才会有多个结果集返回，一般查询仅一个
    final List<Object> multipleResults = new ArrayList<>();

    int resultSetCount = 0;
    //读取首个结果集对象，并封装成为ResultSetWrapper对象
    ResultSetWrapper rsw = getFirstResultSet(stmt);

    List<ResultMap> resultMaps = mappedStatement.getResultMaps();
    int resultMapCount = resultMaps.size();
    //执行校验
    validateResultMapsCount(rsw, resultMapCount);
    while (rsw != null && resultMapCount > resultSetCount) {
      //获取到resultMap对象
      ResultMap resultMap = resultMaps.get(resultSetCount);
      //处理结果对象，将结果添加到multipleResults对象中
      handleResultSet(rsw, resultMap, multipleResults, null);
      //检查是否还存在一个结果集
      rsw = getNextResultSet(stmt);
      cleanUpAfterHandlingResultSet();
      resultSetCount++;
    }

    //可忽略
    String[] resultSets = mappedStatement.getResultSets();
    if (resultSets != null) {
      while (rsw != null && resultSetCount < resultSets.length) {
        ResultMapping parentMapping = nextResultMaps.get(resultSets[resultSetCount]);
        if (parentMapping != null) {
          String nestedResultMapId = parentMapping.getNestedResultMapId();
          ResultMap resultMap = configuration.getResultMap(nestedResultMapId);
          handleResultSet(rsw, resultMap, null, parentMapping);
        }
        rsw = getNextResultSet(stmt);
        cleanUpAfterHandlingResultSet();
        resultSetCount++;
      }
    }
    //返回的结果处理
    return collapseSingleResultList(multipleResults);
  }

  @SuppressWarnings("unchecked")
  private List<Object> collapseSingleResultList(List<Object> multipleResults) {
    return multipleResults.size() == 1 ? (List<Object>) multipleResults.get(0) : multipleResults;
  }
```

