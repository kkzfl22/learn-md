package com.liujun.learn.auth.mapper;

import com.liujun.learn.auth.po.AuthUser;

import java.util.List;

/**
 * 用户的查询 多对多的关联查询
 *
 * @author liujun
 * @since 2022/7/3
 */
public interface AuthUserMapper {

  /**
   * 查询所有用户的所有角色
   *
   * @return
   */
  List<AuthUser> queryAll();
}
