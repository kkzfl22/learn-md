# mybatis源码分析--缓存的执行流程
首先还是准备下测试用例
## 1. 单元测试用例.
数据库操作的java的映射文件
```java
package org.apache.use.use.mapper;
import org.apache.use.use.po.UserMsgPO;
public interface UserMapper {
  UserMsgPO query(UserMsgPO user);
}
```
数据库操作实体
```java
package org.apache.use.use.po;
import java.io.Serializable;
public class UserMsgPO implements Serializable {
  /**
   * 用户的id
   */
  private Integer id;

  /**
   * 名称的信息
   */
  private String name;
  public Integer getId() {
    return id;
  }  public void setId(Integer id) {
    this.id = id;
  }
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }
  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("UserMsgPO{");
    sb.append("id=").append(id);
    sb.append(", name='").append(name).append('\'');
    sb.append('}');
    return sb.toString();
  }
}
```
mybatis的配制文件
```xml
<!DOCTYPE configuration PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-config.dtd">
<configuration>
    <properties resource="jdbc.properties"/>
    <settings>
      <setting name="cacheEnabled" value="true"/>
    </settings>
    <environments default="default">
        <environment id="default">
            <!--JDBC表示把数据库的事务交给JDBC进行管理。 MANAGER让容器进行管理，很少使用，它从来不提交回滚一个连接。-->
            <transactionManager type="JDBC"></transactionManager>
            <!--POOLED使用mybatis的连接池，UNPOOLED表示不使用连接池,每次使用数据库时才打开和关闭连接，JNDI,使用容器配制的数据源。-->
            <dataSource type="POOLED">
                <property name="driver" value="${jdbc.driver}"/>
                <property name="url" value="${jdbc.url}"/>
                <property name="username" value="${jdbc.username}"/>
                <property name="password" value="${jdbc.password}"/>
            </dataSource>
        </environment>
    </environments>
    <mappers>
        <mapper resource="UserCacheMsgMapper.xml"/>
    </mappers>
</configuration>
```
数据库数据库映射的SQl文件
```xml
<!DOCTYPE mapper
  PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
  "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.liujun.learn.mybatis.mapper.UserMsgMapper">
  <cache></cache>
  <select id="selectOne" parameterType="org.apache.use.use.po.UserMsgPO"
          resultType="org.apache.use.use.po.UserMsgPO" useCache="true">
    select * from user_msg
    <where>
      <if test="id != null">
        and id = #{id}
      </if>
    </where>
  </select>
</mapper>
```
数据库查询的单元测试
```java
public class QuickCacheMapperStart {
   @Test
  public void mapperQueryCache() throws IOException {
    //将mybatis的配制文件转换为流,供助类加载
    InputStream streamConfig = Resources.getResourceAsStream("sqlCacheMapConfig.xml");
    //将流转换为配制文件配制对象
    SqlSessionFactory build = new SqlSessionFactoryBuilder().build(streamConfig);

    SqlSession sqlSession1 = build.openSession();
    SqlSession sqlSession2 = build.openSession();

    UserMsgPO user = new UserMsgPO();
    user.setId(1);

    UserMsgPO userRsp = sqlSession1.selectOne("com.liujun.learn.mybatis.mapper.UserMsgMapper.selectOne", user);
    System.out.println(userRsp);
    Assertions.assertNotNull(userRsp.getName());

    //cache只有在commit和close时才生效
    sqlSession1.commit();


    UserMsgPO userRsp2 = sqlSession2.selectOne("com.liujun.learn.mybatis.mapper.UserMsgMapper.selectOne", user);
    System.out.println(userRsp2);
    Assertions.assertNotNull(userRsp2.getName());
  }
}
```

## 2. 执行过程源码分析
mybatis在一级缓存和二级缓存同时开启的情况下，是先走的二级缓存，再走一级缓存，最后走数据库查询。接下来通过源码的分析证实。
那接下来还是来分析
```java
UserMsgPO userRsp = sqlSession1.selectOne("com.liujun.learn.mybatis.mapper.UserMsgMapper.selectOne", user);
```

### 2.1 DefaultSqlSession的查询
这句代码的一个执行吧。
```java
package org.apache.ibatis.session.defaults;

public class DefaultSqlSession implements SqlSession {
  private final Executor executor;
 @Override
  public <T> T selectOne(String statement, Object parameter) {
    // Popular vote was to return null on 0 results and throw exception on too many.
    //首先调用查询查询结果的方法。使用namespace.id及参数调用
    List<T> list = this.selectList(statement, parameter);
    if (list.size() == 1) {
      return list.get(0);
    } else if (list.size() > 1) {
      throw new TooManyResultsException("Expected one result (or null) to be returned by selectOne(), but found: " + list.size());
    } else {
      return null;
    }
  }

  @Override
  public <E> List<E> selectList(String statement, Object parameter) {
    //传递namespaceId加查询参数，再传递一个默认的分页对象
    return this.selectList(statement, parameter, RowBounds.DEFAULT);
  }

  @Override
  public <E> List<E> selectList(String statement, Object parameter, RowBounds rowBounds) {
    try {
      //Map<String, MappedStatement>这个对象中获得MappedStatement对象。
      MappedStatement ms = configuration.getMappedStatement(statement);
      //执行查询，次级Executor对象来执行查询。
      return executor.query(ms, wrapCollection(parameter), rowBounds, Executor.NO_RESULT_HANDLER);
    } catch (Exception e) {
      throw ExceptionFactory.wrapException("Error querying database.  Cause: " + e, e);
    } finally {
      ErrorContext.instance().reset();
    }
  }
}
```
首先还是默认的DefaultSqlSession作为入口，进行调用，然后将通过SQL执行器(Executor)执行调用，而Executor存在两个接口实现：
BaseExecutor:最基础的一个SQL执行器。
CachingExecutor: 带有缓存的一个SQL执行器。它是做为BaseExecutor的一个装饰类，当数据需要执行查询时，将调用BaseExecutor，而缓存如果存在，
则直接走本地缓存获取数据。

接下来将先分析CachingExecutor的一个具体实现：
### 2.2 CachingExecutor的实现分析
```java
package org.apache.ibatis.executor;

public class CachingExecutor implements Executor {

  private final Executor delegate;
  private final TransactionalCacheManager tcm = new TransactionalCacheManager();

  @Override
  public <E> List<E> query(MappedStatement ms, Object parameterObject, RowBounds rowBounds, ResultHandler resultHandler) throws SQLException {
    //获取BoundSql对象
    BoundSql boundSql = ms.getBoundSql(parameterObject);
    //创建缓存CacheKey对象
    CacheKey key = createCacheKey(ms, parameterObject, rowBounds, boundSql);
    //查询逻辑执行
    return query(ms, parameterObject, rowBounds, resultHandler, key, boundSql);
  }
  @Override
  public <E> List<E> query(MappedStatement ms, Object parameterObject, RowBounds rowBounds, ResultHandler resultHandler, CacheKey key, BoundSql boundSql)
    throws SQLException {
    //从MappedStatement获取一个Cache对象。此即为解析mapper中的Cache所得到。
    Cache cache = ms.getCache();
    //如果未配制cache，则跳过从缓存中获取
    if (cache != null) {
      //进行缓存刷新的检查，即FlashCache的检查，如果为true,则需要执行清空或者说刷新操作
      flushCacheIfRequired(ms);
      //判断属性useCache是否启用。默认为true
      if (ms.isUseCache() && resultHandler == null) {
        //暂时忽略，与存储过程相关
        ensureNoOutParams(ms, boundSql);
        @SuppressWarnings("unchecked")
        //从二级缓存中获取结果。TransactionalCacheManager对象中获取数据。
        List<E> list = (List<E>) tcm.getObject(cache, key);
        if (list == null) {
          //当缓存结果不存在时，执行缓存的查询操作。
          //SimpleExecutor的实现，这个查询过程是先走的一级缓存，再走数怕有库查询
          list = delegate.query(ms, parameterObject, rowBounds, resultHandler, key, boundSql);
          tcm.putObject(cache, key, list); // issue #578 and #116
        }
        return list;
      }
    }
    //执行本地数据库的查询
    return delegate.query(ms, parameterObject, rowBounds, resultHandler, key, boundSql);
  }
}
```
通过源码可以发现，CachingExecutor优先从二级缓存中TransactionalCacheManager中去获取数据，
从这里可以证实，如果开启了二级缓存是优先走二级缓存中拿取数据的。

### 2.3 TransactionalCacheManager的分析
```java
package org.apache.ibatis.cache;

public class TransactionalCacheManager {
  /**
   * cache与TransactionalCache的映射关系
   */
  private final Map<Cache, TransactionalCache> transactionalCaches = new HashMap<>();
  /**
   * 清空缓存
   * @param cache
   */
  public void clear(Cache cache) {
    getTransactionalCache(cache).clear();
  }

  /**
   * 获取缓存的值，通过cache+key
   * @param cache
   * @param key
   * @return
   */
  public Object getObject(Cache cache, CacheKey key) {
    return getTransactionalCache(cache).getObject(key);
  }
  /**
   * 向缓存中存储值,cache + KV
   * @param cache
   * @param key
   * @param value
   */
  public void putObject(Cache cache, CacheKey key, Object value) {
    getTransactionalCache(cache).putObject(key, value);
  }
  /**
   * 提交所有的TransactionalCache
   */
  public void commit() {
    for (TransactionalCache txCache : transactionalCaches.values()) {
      txCache.commit();
    }
  }
  /**
   * 回滚所有的TransactionalCache
   */
  public void rollback() {
    for (TransactionalCache txCache : transactionalCaches.values()) {
      txCache.rollback();
    }
  }
  /**
   * 通过指定的key获取缓存中的对象，如果缓存中不存在，则创建一个
   * @param cache 缓存的key
   * @return 缓存管理对象
   */
  private TransactionalCache getTransactionalCache(Cache cache) {
    //此方法首先判断缓存map中是否存在指定的key值，如果不存在，会自动调用mappingFunction(key)计算key的value，然后将key = value放入到缓存map
    //如果mappingFunction(key)返回的值为null或抛出异常，则不会有记录存入map
    return transactionalCaches.computeIfAbsent(cache, TransactionalCache::new);
  }
}
```
通过查看TransactionalCacheManager的源码，可以看到，此类维护了Cache与TransactionalCache的一个关系，那此时就有个问题了。
为什么不直接使用缓存对象，而是做一个Cache与TransactionalCache的影射关系？
1:二级缓存存在的数据Cache是从MapperStatement对象中获取的，由于MapperStatement存在于全局配制中，可以多个CachingExecutor获取，就会出现线程安全的问题，
2:多个事务如果共用一个缓存实例，不加以控制就会出现脏读的问题，而脏读取需要借助其他类来进行处理，
这也就是TransactionalCacheManager的主要工作。


### 2.4 TransactionalCache源码的分析
```java
package org.apache.ibatis.cache.decorators;

public class TransactionalCache implements Cache {
  private static final Log log = LogFactory.getLog(TransactionalCache.class);
  /**
   * cache对象
   *
   * 就是二级缓存cache对象
   */
  private final Cache delegate;

  /**
   * 提交时清空，初始值为false,
   */
  private boolean clearOnCommit;

  /**
   * 在事务被提交前，所有从数据库中查询的结果，将缓存在此集合中
   */
  private final Map<Object, Object> entriesToAddOnCommit;
  /**
   * 在事务被提交前，当缓存未命中时，CacheKey会存储在此集合中。
   */
  private final Set<Object> entriesMissedInCache;

  public TransactionalCache(Cache delegate) {
    this.delegate = delegate;
    this.clearOnCommit = false;
    this.entriesToAddOnCommit = new HashMap<>();
    this.entriesMissedInCache = new HashSet<>();
  }

  @Override
  public String getId() {
    return delegate.getId();
  }

  @Override
  public int getSize() {
    return delegate.getSize();
  }

  @Override
  public Object getObject(Object key) {
    // issue #116
    //查询时，直接从delegate中去查询，也就是真正的缓存对象查询
    Object object = delegate.getObject(key);
    //如果不存在，则添加到entriesMissedInCache中
    if (object == null) {
      //缓存未命中，则将key存储到entriesMissedInCache中
      entriesMissedInCache.add(key);
    }
    // issue #146
    //如果clearOnCommit为true,表示处于持续清空状态，则返回为null
    if (clearOnCommit) {
      return null;
    } else {
      return object;
    }
  }

  @Override
  public void putObject(Object key, Object object) {
    //将查询的结果放入到map，这个map并非真正的缓存对象delegate,仅是一个临时的数据。
    entriesToAddOnCommit.put(key, object);
  }

  @Override
  public Object removeObject(Object key) {
    return null;
  }

  @Override
  public void clear() {
    clearOnCommit = true;
    entriesToAddOnCommit.clear();
  }

  public void commit() {
    if (clearOnCommit) {
      delegate.clear();
    }
    //将事务未提交前entriesToAddOnCommit，entriesMissedInCache中的数据刷入真正的缓存中。
    flushPendingEntries();
    //执行重置操作
    reset();
  }

  public void rollback() {
    //将事务未提交的数据做清空操作
    unlockMissedEntries();
    //执行重置操作
    reset();
  }

  private void reset() {
    clearOnCommit = false;
    entriesToAddOnCommit.clear();
    entriesMissedInCache.clear();
  }

  /**
   * 将数据刷入到真正的缓存中
   */
  private void flushPendingEntries() {
    for (Map.Entry<Object, Object> entry : entriesToAddOnCommit.entrySet()) {
      delegate.putObject(entry.getKey(), entry.getValue());
    }
    for (Object entry : entriesMissedInCache) {
      if (!entriesToAddOnCommit.containsKey(entry)) {
        delegate.putObject(entry, null);
      }
    }
  }

  private void unlockMissedEntries() {
    //将事务未提交的数据进行回滚操作
    for (Object entry : entriesMissedInCache) {
      try {
        //此实现中，未做任何的操作，所以，不会有数据变化。
        delegate.removeObject(entry);
      } catch (Exception e) {
        log.warn("Unexpected exception while notifiying a rollback to the cache adapter."
          + "Consider upgrading your cache adapter to the latest version.  Cause: " + e);
      }
    }
  }
}
```
通过阅读TransactionalCache可以发现，向缓存中添加数据只是向entriesToAddOnCommit这个map对象中加入数据，并未加入到delegate中。
当调用了commit方法后，数据才从entriesToAddOnCommit这个对接加入到delegate中。
这就是为什么在未调用提交前，二级缓存没有生效的原因。

## 3 提交源码分析
### 3.1  DefaultSqlSession的commit方法
为什么在只有在执行SqlSession的关闭或者提交后二级缓存才会生效？带着这个问题，来接下来分析。
接下来分析下sqlSession的commit方法。
```java
package org.apache.ibatis.session.defaults;

public class DefaultSqlSession implements SqlSession {
  private final Executor executor;
  @Override
  public void commit() {
    //执行提交
    commit(false);
  }
  
  @Override
  public void commit(boolean force) {
    try {
      //调用SQL执行器的提交方法
      executor.commit(isCommitOrRollbackRequired(force));
      dirty = false;
    } catch (Exception e) {
      throw ExceptionFactory.wrapException("Error committing transaction.  Cause: " + e, e);
    } finally {
      ErrorContext.instance().reset();
    }
  }
  
  private boolean isCommitOrRollbackRequired(boolean force) {
    return (!autoCommit && dirty) || force;
  }  
}
```
在提交方法中，会再调用Executor的commit方法，那就继续跟踪此Executor有两个实现CachingExecutor和BaseExecutor，而此处使用的是带有二级缓存的
那也就继续跟踪CachingExecutor这个实现

### 3.2 CachingExecutor的commit实现
```java
package org.apache.ibatis.executor;

public class CachingExecutor implements Executor {
  private final Executor delegate;
  private final TransactionalCacheManager tcm = new TransactionalCacheManager();
  @Override
  public void commit(boolean required) throws SQLException {
    //SQL执行器的提交操作
    delegate.commit(required);
    //TransactionalCacheManager对象的提交操作,也就是缓存对象管理器的提交
    tcm.commit();
  }
}
```

### 3.3 TransactionalCacheManager的commit方法
```java
package org.apache.ibatis.cache;

public class TransactionalCacheManager {
  /**
   * cache与TransactionalCache的映射关系
   */
  private final Map<Cache, TransactionalCache> transactionalCaches = new HashMap<>();
  /**
   * 提交所有的TransactionalCache
   */
  public void commit() {
    //找到所有的缓存对象，执行缓存的提交操作
    for (TransactionalCache txCache : transactionalCaches.values()) {
      txCache.commit();
    }
  }
}
```

### 3.4 TransactionalCache的commit方法
```java
package org.apache.ibatis.cache.decorators;

public class TransactionalCache implements Cache {
  /**
   * cache对象
   *
   * 就是二级缓存cache对象
   */
  private final Cache delegate;

  /**
   * 提交时清空，初始值为false,
   */
  private boolean clearOnCommit;

  /**
   * 在事务被提交前，所有从数据库中查询的结果，将缓存在此集合中
   */
  private final Map<Object, Object> entriesToAddOnCommit;
  /**
   * 在事务被提交前，当缓存未命中时，CacheKey会存储在此集合中。
   */
  private final Set<Object> entriesMissedInCache;
  
  public void commit() {
    if (clearOnCommit) {
      delegate.clear();
    }
    //将事务未提交前entriesToAddOnCommit，entriesMissedInCache中的数据刷入真正的缓存中。
    flushPendingEntries();
    //执行重置操作
    reset();
  }

  /**
   * 将数据刷入到真正的缓存中
   */
  private void flushPendingEntries() {
    for (Map.Entry<Object, Object> entry : entriesToAddOnCommit.entrySet()) {
      delegate.putObject(entry.getKey(), entry.getValue());
    }
    for (Object entry : entriesMissedInCache) {
      if (!entriesToAddOnCommit.containsKey(entry)) {
        delegate.putObject(entry, null);
      }
    }
  }
}
```

通过这一系列的调用，发现最后还是调用了TransactionalCache的commit方法。在这里才将临时的数据对象entriesToAddOnCommit中的数据插入到
二级缓存delegate中。

## 4 close源码分析。
上面查看了commit方法，接下来看看close为何也是同样的效果
### 4.1  DefaultSqlSession的close方法
```java
package org.apache.ibatis.session.defaults;

public class DefaultSqlSession implements SqlSession {
  private final Executor executor;
  
  @Override
  public void close() {
    try {
      executor.close(isCommitOrRollbackRequired(false));
      closeCursors();
      dirty = false;
    } finally {
      ErrorContext.instance().reset();
    }
  }
  private boolean isCommitOrRollbackRequired(boolean force) {
    return (!autoCommit && dirty) || force;
  } 
}
```
### 4.2 CachingExecutor的close实现
```java
package org.apache.ibatis.executor;

public class CachingExecutor implements Executor {
  private final Executor delegate;
  private final TransactionalCacheManager tcm = new TransactionalCacheManager();
  @Override
  public void close(boolean forceRollback) {
    try {
      //issues #499, #524 and #573
      if (forceRollback) {
        tcm.rollback();
      } else {
        tcm.commit();
      }
    } finally {
      delegate.close(forceRollback);
    }
  }
}
```
在CachingExecutor此同如果是正常的提交事务也是会调用TransactionalCacheManager的commit方法。

## 5 二级缓存的刷新
### 5.1 二级缓存的单元测试修改
```java
public class QuickCacheMapperStart {
      @Test
      public void mapperQueryCacheUpdate() throws IOException {
        //将mybatis的配制文件转换为流,供助类加载
        InputStream streamConfig = Resources.getResourceAsStream("sqlCacheMapConfig.xml");
        //将流转换为配制文件配制对象
        SqlSessionFactory build = new SqlSessionFactoryBuilder().build(streamConfig);
    
        SqlSession sqlSession1 = build.openSession();
        SqlSession sqlSession2 = build.openSession();
    
        UserMsgPO user = new UserMsgPO();
        user.setId(1);
        UserMsgPO userRsp = sqlSession1.selectOne("com.liujun.learn.mybatis.mapper.UserMsgMapper.selectOne", user);
        System.out.println(userRsp);
        Assertions.assertNotNull(userRsp.getName());
    
        sqlSession1.commit();
    
        UserMsgPO updateUser = new UserMsgPO();
        updateUser.setId(1);
        updateUser.setName("updateName");
        int update = sqlSession1.update("com.liujun.learn.mybatis.mapper.UserMsgMapper.updateUser", updateUser);
        Assertions.assertEquals(1, update);
    
        UserMsgPO userRsp2 = sqlSession2.selectOne("com.liujun.learn.mybatis.mapper.UserMsgMapper.selectOne", user);
        System.out.println(userRsp2);
        Assertions.assertNotNull(userRsp2.getName());
      }
}
```
在mapper.xml文件中增加修改方法
```xml
<!DOCTYPE mapper
  PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
  "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.liujun.learn.mybatis.mapper.UserMsgMapper">
  <cache ></cache>
  <select id="selectOne" parameterType="org.apache.use.use.po.UserMsgPO"
          resultType="org.apache.use.use.po.UserMsgPO" useCache="true">
    select * from user_msg
    <where>
      <if test="id != null">
        and id = #{id}
      </if>
    </where>
  </select>
  <update id="updateUser" parameterType="org.apache.use.use.po.UserMsgPO">
    update user_msg set name = #{name} where id=#{id}
  </update>
</mapper>
```
其他与之前不变
当我们在运行单元测试后，发现还是命中了缓存，这是为什么呢？还是以源码的方式来找下原因吧。


### 5.2 DefaultSqlSession的update方法
```java
package org.apache.ibatis.session.defaults;

public class DefaultSqlSession implements SqlSession {
  private final Executor executor;
  @Override
  public int update(String statement, Object parameter) {
    try {
      dirty = true;
      MappedStatement ms = configuration.getMappedStatement(statement);
      return executor.update(ms, wrapCollection(parameter));
    } catch (Exception e) {
      throw ExceptionFactory.wrapException("Error updating database.  Cause: " + e, e);
    } finally {
      ErrorContext.instance().reset();
    }
  }
}
```
### 5.3 CachingExecutor的update方法
这还是老样子，需要调用SQL执行器的更新方法，那就继续跟踪
```java
package org.apache.ibatis.executor;

public class CachingExecutor implements Executor {

  private final Executor delegate;
  private final TransactionalCacheManager tcm = new TransactionalCacheManager();

  @Override
  public int update(MappedStatement ms, Object parameterObject) throws SQLException {
	//检查缓存清空配制，在修改时默认flushCache为true
    flushCacheIfRequired(ms);
	//执行更新操作
    return delegate.update(ms, parameterObject);
  }
  
  /**
   * 刷新操作，当flushCache配制为true,则先进行清空操作。
   * @param ms
   */
  private void flushCacheIfRequired(MappedStatement ms) {
    Cache cache = ms.getCache();
    if (cache != null && ms.isFlushCacheRequired()) {
      //执行缓存管理器的清空操作
      tcm.clear(cache);
    }
  }
}
```
在这里分发现是否刷新缓缓存取决于flushCache的配制，此参数在修改时默认为true,当参数修改为false时，不会进行缓存的刷新操作

### 5.4 TransactionalCacheManager的clean方法
```java
package org.apache.ibatis.cache;

public class TransactionalCacheManager {
  /**
   * cache与TransactionalCache的映射关系
   */
  private final Map<Cache, TransactionalCache> transactionalCaches = new HashMap<>();
  /**
   * 清空缓存
   * @param cache
   */
  public void clear(Cache cache) {
    getTransactionalCache(cache).clear();
  }
  /**
   * 通过指定的key获取缓存中的对象，如果缓存中不存在，则创建一个
   * @param cache 缓存的key
   * @return 缓存管理对象
   */
  private TransactionalCache getTransactionalCache(Cache cache) { //此方法首先判断缓存map中是否存在指定的key值，如果不存在，会自动调用mappingFunction(key)计算key的value，然后将key = value放入到缓存map
    //如果mappingFunction(key)返回的值为null或抛出异常，则不会有记录存入map
    return transactionalCaches.computeIfAbsent(cache, TransactionalCache::new);
  } 
}
```

### 5.5 TransactionalCache的clear方法
```java
package org.apache.ibatis.cache.decorators;

public class TransactionalCache implements Cache {
  /**
   * cache对象
   *
   * 就是二级缓存cache对象
   */
  private final Cache delegate;
  /**
   * 提交时清空，初始值为false,
   */
  private boolean clearOnCommit;
  /**
   * 在事务被提交前，所有从数据库中查询的结果，将缓存在此集合中
   */
  private final Map<Object, Object> entriesToAddOnCommit;
  /**
   * 在事务被提交前，当缓存未命中时，CacheKey会存储在此集合中。
   */
  private final Set<Object> entriesMissedInCache;
  
  @Override
  public void clear() {
	//标识需要做二级缓存的清理
    clearOnCommit = true;
	//在做clear时仅执行了事务未提交前缓存的刷新，当然不会影响二级缓存
    entriesToAddOnCommit.clear();
  }
  
  public void commit() {
    if (clearOnCommit) {
      //此处对二级缓存对象做了清空处理，就会影响到二级缓存
      delegate.clear();
    }
    //将事务未提交前entriesToAddOnCommit，entriesMissedInCache中的数据刷入真正的缓存中。
    flushPendingEntries();
    //执行重置操作
    reset();
  } 
}
```
从这里的代码分析就可以的看出调用了update方法，将对未提交前的数据做刷新操作，而对于已经提交的刷新，必须执行commit能会将二级缓存进行刷新。


## 总结
> 1. 二级缓存实现了sqlSession之间的缓存数据共享，属于namespace级别。
> 2. 二级缓存具有丰富的缓存策略。
> 3. 二级缓存可由多个缓存装饰器，与基础缓存组合而成。
> 4. 二级缓存工作由一个缓存装饰执行器和一个事务型预缓存TransactionalCacheManager组合完成。

此二级缓存仅适用于不常更新的数据，由于此操作会将整个缓存进行清空，所以此缓存并不常用。

