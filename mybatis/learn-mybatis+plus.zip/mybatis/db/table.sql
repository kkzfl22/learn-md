
-- 用户信息
drop table if exists  user_msg;

create table user_msg
(
    id                            	int(8)          not null ,
	name                            varchar(100)        not null,
    primary key (id)
) ;


insert into user_msg(id,name)
values(1,'name');

insert into user_msg(id,name)
values(2,'name2');



-- 订单信息
drop table if exists  order_info;

create table order_info(
    id                            	int(8)          not null ,
	money                           int(8)          not null,
	orderTime                       bigint(15)          not null,
	user_id                          int(8)          not null ,
    primary key (id)
) ;


insert into order_info(id,money,orderTime,user_id)
values(10,100,100000000,1);

insert into order_info(id,money,orderTime,user_id)
values(20,200,200000000,2);


insert into order_info(id,money,orderTime,user_id)
values(30,300,200000001,2);



-- 用户信息
drop table if exists  auth_user;

create table auth_user(
    id                            	int(8)          not null ,
	name                           varchar(20)      not null,
    primary key (id)
) ;


-- 用户信息
drop table if exists  auth_role;

create table auth_role(
    id                            	int(8)          not null ,
	name                           varchar(20)      not null,
    primary key (id)
) ;


--  用户角色关联关系
drop table if exists  auth_user_role;

create table auth_user_role(
    user_id                         int(8)          not null ,
	role_id                         int(8)          not null ,
    primary key (user_id,role_id)
) ;


insert into auth_user(id,name)
values(1,'kk');

insert into auth_user(id,name)
values(2,'feifei');


insert into auth_role(id,name)
values(100,'sysadmin');

insert into auth_role(id,name)
values(200,'base_user');

insert into auth_user_role(user_id,role_id)
values(1,100);
insert into auth_user_role(user_id,role_id)
values(1,200);


insert into auth_user_role(user_id,role_id)
values(2,100);
insert into auth_user_role(user_id,role_id)
values(2,200);





-- 用户表
drop table if exists  user_data;

create table user_data
(
    user_id                            	int(8)          not null ,
	user_name                            varchar(100)        not null,
	create_time                     bigint(12)       not null,
	update_time                     bitint(12) ,
    primary key (user_id)
) ;







