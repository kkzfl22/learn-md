# mybatis 延迟加载源码分析
## 1 单元测试准备
```java
package org.apache.use.test;

public class QuickLazyMapperStart {
  @Test
  public void mapperQuery() throws IOException {
    //将mybatis的配制文件转换为流,供助类加载
    InputStream streamConfig = Resources.getResourceAsStream("sqlLazyMapConfig.xml");
    //将流转换为配制文件配制对象
    SqlSessionFactory build = new SqlSessionFactoryBuilder().build(streamConfig);

    SqlSession sqlSession2 = build.openSession();

    UserMsgPO user = new UserMsgPO();
    user.setId(2);

    UserMsgPO userRsp = sqlSession2.selectOne("org.apache.use.use.mapper.UserOrderMapper.queryByUid", user);
    System.out.println(userRsp.getName());
    System.out.println("还未使用关联加载");
    System.out.println(userRsp.getOrderList());
    System.out.println(userRsp);
    Assertions.assertNotNull(userRsp.getName());
  }
}
```
mybatis的配制文件
sqlLazyMapConfig.xml
```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE configuration PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
  "http://mybatis.org/dtd/mybatis-3-config.dtd">
<configuration>
  <properties resource="jdbc.properties"/>
  <settings>
    <setting name="lazyLoadingEnabled" value="true"/>
  </settings>
  <environments default="default">
    <environment id="default">
      <!--JDBC表示把数据库的事务交给JDBC进行管理。 MANAGER让容器进行管理，很少使用，它从来不提交回滚一个连接。-->
      <transactionManager type="JDBC"></transactionManager>
      <!--POOLED使用mybatis的连接池，UNPOOLED表示不使用连接池,每次使用数据库时才打开和关闭连接，JNDI,使用容器配制的数据源。-->
      <dataSource type="POOLED">
        <property name="driver" value="${jdbc.driver}"/>
        <property name="url" value="${jdbc.url}"/>
        <property name="username" value="${jdbc.username}"/>
        <property name="password" value="${jdbc.password}"/>
      </dataSource>
    </environment>
  </environments>
  <mappers>
    <mapper resource="UserMsgLazyMapper.xml"/>
  </mappers>
</configuration>
```
关联的表操作UserMsgLazyMapper.xml
```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE mapper
  PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
  "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="org.apache.use.use.mapper.UserOrderMapper">

  <resultMap id="userOrderResultMap" type="org.apache.use.use.po.UserMsgPO">
    <result property="id" column="id"/>
    <result property="name" column="name"/>
    <collection property="orderList" ofType="org.apache.use.use.po.OrderInfoPO"
                select="org.apache.use.use.mapper.UserOrderMapper.queryOrderByOid" column="id" fetchType="eager">
      <id property="id" column="id"/>
      <result property="memory" column="memory"/>
      <result property="orderTime" column="orderTime"/>
      <result property="userId" column="userId"/>
    </collection>
  </resultMap>
  <select id="queryByUid" parameterType="org.apache.use.use.po.UserMsgPO"
          resultMap="userOrderResultMap">
    select * from user_msg
    <where>
      <if test="id != null">
        and id = #{id}
      </if>
    </where>
  </select>
  <select id="queryOrderByOid" resultType="org.apache.use.use.po.OrderInfoPO">
    select * from order_info where userId = #{uid}
  </select>
</mapper>
```
jdbc.properties
```properties
jdbc.driver=org.sqlite.JDBC
jdbc.url=jdbc:sqlite:/db/mybatis.db
jdbc.username=
jdbc.password=
```

```java
package org.apache.use.use.po;

public class UserMsgPO implements Serializable {
  /**
   * 用户的id
   */
  private Integer id;
  /**
   * 名称的信息
   */
  private String name;
  /**
   * 用户关联的订单信息
   */
  private List<OrderInfoPO> orderList;
  public Integer getId() {
    return id;
  }
  public void setId(Integer id) {
    this.id = id;
  }
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }
  public List<OrderInfoPO> getOrderList() {
    return orderList;
  }
  public void setOrderList(List<OrderInfoPO> orderList) {
    this.orderList = orderList;
  }
  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("UserMsgPO{");
    sb.append("id=").append(id);
    sb.append(", name='").append(name).append('\'');
    sb.append(", orderList='").append(orderList).append('\'');
    sb.append('}');
    return sb.toString();
  }
}
```
关联的订单实体
```java
package org.apache.use.use.po;
public class OrderInfoPO implements Serializable {
  private Integer id;
  private Integer money;
  private Long orderTime;
  private Integer userId;
  public Integer getId() {
    return id;
  }
  public void setId(Integer id) {
    this.id = id;
  }
  public Integer getMoney() {
    return money;
  }
  public void setMoney(Integer money) {
    this.money = money;
  }
  public Long getOrderTime() {
    return orderTime;
  }
  public void setOrderTime(Long orderTime) {
    this.orderTime = orderTime;
  }
  public Integer getUserId() {
    return userId;
  }
  public void setUserId(Integer userId) {
    this.userId = userId;
  }
  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("OrderInfoPO{");
    sb.append("id=").append(id);
    sb.append(", money=").append(money);
    sb.append(", orderTime=").append(orderTime);
    sb.append(", userId=").append(userId);
    sb.append('}');
    return sb.toString();
  }
}
```
在sqlLazyMapConfig.xml中配制了全局延迟加载，
但在UserMsgLazyMapper.xml中，但在关联查询中配制了fetchType="eager"，这就导致数据是立即加载的，
运行结果
```text
[main] [org.apache.ibatis.datasource.pooled.PooledDataSource]-[DEBUG] Created connection 1164440413.
[main] [org.apache.ibatis.transaction.jdbc.JdbcTransaction]-[DEBUG] Setting autocommit to false on JDBC Connection [org.sqlite.jdbc4.JDBC4Connection@4567f35d]
[main] [org.apache.use.use.mapper.UserOrderMapper.queryByUid]-[DEBUG] ==>  Preparing: select * from user_msg WHERE id = ? 
[main] [org.apache.use.use.mapper.UserOrderMapper.queryByUid]-[DEBUG] ==> Parameters: 2(Integer)
[main] [org.apache.use.use.mapper.UserOrderMapper.queryByUid]-[TRACE] <==    Columns: id, name
[main] [org.apache.use.use.mapper.UserOrderMapper.queryByUid]-[TRACE] <==        Row: 2, name2
[main] [org.apache.use.use.mapper.UserOrderMapper.queryOrderByOid]-[DEBUG] ====>  Preparing: select * from order_info where userId = ? 
[main] [org.apache.use.use.mapper.UserOrderMapper.queryOrderByOid]-[DEBUG] ====> Parameters: 2(Integer)
[main] [org.apache.use.use.mapper.UserOrderMapper.queryOrderByOid]-[TRACE] <====    Columns: id, money, orderTime, userId
[main] [org.apache.use.use.mapper.UserOrderMapper.queryOrderByOid]-[TRACE] <====        Row: 20, 200, 200000000, 2
[main] [org.apache.use.use.mapper.UserOrderMapper.queryOrderByOid]-[TRACE] <====        Row: 30, 300, 200000001, 2
[main] [org.apache.use.use.mapper.UserOrderMapper.queryOrderByOid]-[DEBUG] <====      Total: 2
[main] [org.apache.use.use.mapper.UserOrderMapper.queryByUid]-[DEBUG] <==      Total: 1
name2
还未使用关联加载
UserMsgPO{id=2, name='name2', orderList='[OrderInfoPO{id=20, money=200, orderTime=200000000, userId=2}, OrderInfoPO{id=30, money=300, orderTime=200000001, userId=2}]'}
```
再来一次,将数据关联加载修改为延迟加载
修改UserMsgLazyMapper.xml文件中fetchType="lazy"或者，直接去掉，将使用全局的配制属性
```text
[main] [org.apache.ibatis.transaction.jdbc.JdbcTransaction]-[DEBUG] Setting autocommit to false on JDBC Connection [org.sqlite.jdbc4.JDBC4Connection@4567f35d]
[main] [org.apache.use.use.mapper.UserOrderMapper.queryByUid]-[DEBUG] ==>  Preparing: select * from user_msg WHERE id = ? 
[main] [org.apache.use.use.mapper.UserOrderMapper.queryByUid]-[DEBUG] ==> Parameters: 2(Integer)
[main] [org.apache.use.use.mapper.UserOrderMapper.queryByUid]-[TRACE] <==    Columns: id, name
[main] [org.apache.use.use.mapper.UserOrderMapper.queryByUid]-[TRACE] <==        Row: 2, name2
[main] [org.apache.use.use.mapper.UserOrderMapper.queryByUid]-[DEBUG] <==      Total: 1
name2
还未使用关联加载
[main] [org.apache.use.use.mapper.UserOrderMapper.queryOrderByOid]-[DEBUG] ==>  Preparing: select * from order_info where userId = ? 
[main] [org.apache.use.use.mapper.UserOrderMapper.queryOrderByOid]-[DEBUG] ==> Parameters: 2(Integer)
[main] [org.apache.use.use.mapper.UserOrderMapper.queryOrderByOid]-[TRACE] <==    Columns: id, money, orderTime, userId
[main] [org.apache.use.use.mapper.UserOrderMapper.queryOrderByOid]-[TRACE] <==        Row: 20, 200, 200000000, 2
[main] [org.apache.use.use.mapper.UserOrderMapper.queryOrderByOid]-[TRACE] <==        Row: 30, 300, 200000001, 2
[main] [org.apache.use.use.mapper.UserOrderMapper.queryOrderByOid]-[DEBUG] <==      Total: 2
[OrderInfoPO{id=20, money=200, orderTime=200000000, userId=2}, OrderInfoPO{id=30, money=300, orderTime=200000001, userId=2}]
UserMsgPO{id=2, name='name2', orderList='[OrderInfoPO{id=20, money=200, orderTime=200000000, userId=2},
 OrderInfoPO{id=30, money=300, orderTime=200000001, userId=2}]'}
```

## 2 延迟加载的原理
>
>延迟加载的原理: 使用CGLIB或者javassit(默认)创建目标的代理对象。当调用对象的延迟加载属性的getter方法，将进入拦截器方法，
>当发现属性需要延迟加载时，就会单独发送事先保存好的查询关联的对象的SQL，获得到执行结果，这样延迟加载的对象就有值了，接着完成方法的调用。
>
当现对应到源码中，即ProxyFactory这个代理对象创建工厂，有两个实现。
JavassistProxyFactory: 默认的代理对象创建的工厂
CglibProxyFactory： 使用Cglib实现的代理对象的创建工厂。

## 3 延迟加载的源码分析
### 3.1 配制说明
在开始分析之前，有必要对延迟加载的配制进行说明。包括以下可以配制的属性
```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE configuration PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
  "http://mybatis.org/dtd/mybatis-3-config.dtd">
<configuration>
  <properties resource="jdbc.properties"/>
  <settings>
    <!--全局开启延迟加载开关，默认为false,特定的关联关系可通过设置fetchType来覆盖属性的开关状态。  -->
    <!--还可以配制aggressiveLazyLoading,开启时，任一方法调用时都会加载该对象的所有延迟加载属性。
    否则每个延迟加载属性会按需加载,默认为false-->
    <!--延迟加载还可以配制lazyLoadTriggerMethods，指定对象的哪些方法触发一次延迟加载。用逗号分隔方法名。-->
    <setting name="lazyLoadingEnabled" value="true"/>
    <setting name="aggressiveLazyLoading" value="false"/>
    <setting name="lazyLoadTriggerMethods" value="toString,equals"/>

  </settings>
</configuration>
```
在全局性的配制中，可以配制以上三个属性
再来看看这个全局配制的对象的封装。
```java
package org.apache.ibatis.session;

public class Configuration {

  /**
   * 当开启时，任何方法的调用都会加载该对象的所有属性，否则每个属性都会按需加载，
   */
  protected boolean aggressiveLazyLoading;

  /**
   * 指定哪个对象的方法触发一些延迟加载。
   */
  protected Set<String> lazyLoadTriggerMethods = new HashSet<>(Arrays.asList("equals", "clone", "hashCode", "toString"));
  
  /**
   * 延迟加载的全局开关，开启时，所有关联的对象都会延迟加载，特定的关联关系可通过设置fetchType来覆盖属性的开关状态。
   */
  protected boolean lazyLoadingEnabled = false;
  
  /**
   * 可以发现ProxyFactory的默认实现为JavassistProxyFactory
   */
  protected ProxyFactory proxyFactory = new JavassistProxyFactory(); // #224 Using internal Javassist instead of OGNL  
  
  public void setProxyFactory(ProxyFactory proxyFactory) {
    if (proxyFactory == null) {
      proxyFactory = new JavassistProxyFactory();
    }
    this.proxyFactory = proxyFactory;
  }
}
```

### 3.2 ResultSetHandler的handlerResultSet方法处理。
mybatis的查询结果是由ResultSetHandler的handlerResultSet方法处理的，而ResultSetHandler接口只有一个实现DefaultResultSetHandler.
那就直接分析延迟加载的核心方法。
```java
package org.apache.ibatis.executor.resultset;

public class DefaultResultSetHandler implements ResultSetHandler {
  //
  // HANDLE RESULT SETS
  //
  @Override
  public List<Object> handleResultSets(Statement stmt) throws SQLException {
    ErrorContext.instance().activity("handling results").object(mappedStatement.getId());

    //多结构集对象，这个一般在存储过程才会有多个结果集返回，一般查询仅一个
    final List<Object> multipleResults = new ArrayList<>();

    int resultSetCount = 0;
    //读取首个结果集对象，并封装成为ResultSetWrapper对象
    ResultSetWrapper rsw = getFirstResultSet(stmt);

    List<ResultMap> resultMaps = mappedStatement.getResultMaps();
    int resultMapCount = resultMaps.size();
    //执行校验
    validateResultMapsCount(rsw, resultMapCount);
    while (rsw != null && resultMapCount > resultSetCount) {
      //获取到resultMap对象
      ResultMap resultMap = resultMaps.get(resultSetCount);
      //处理结果对象，将结果添加到multipleResults对象中
      handleResultSet(rsw, resultMap, multipleResults, null);
      //检查是否还存在一个结果集
      rsw = getNextResultSet(stmt);
      cleanUpAfterHandlingResultSet();
      resultSetCount++;
    }

    //可忽略
    String[] resultSets = mappedStatement.getResultSets();
    if (resultSets != null) {
      while (rsw != null && resultSetCount < resultSets.length) {
        ResultMapping parentMapping = nextResultMaps.get(resultSets[resultSetCount]);
        if (parentMapping != null) {
          String nestedResultMapId = parentMapping.getNestedResultMapId();
          ResultMap resultMap = configuration.getResultMap(nestedResultMapId);
          handleResultSet(rsw, resultMap, null, parentMapping);
        }
        rsw = getNextResultSet(stmt);
        cleanUpAfterHandlingResultSet();
        resultSetCount++;
      }
    }

    return collapseSingleResultList(multipleResults);
  }
  
  /**
   * 结果集的处理方法
   * @param rsw
   * @param resultMap
   * @param multipleResults
   * @param parentMapping
   * @throws SQLException
   */
  private void handleResultSet(ResultSetWrapper rsw, ResultMap resultMap, List<Object> multipleResults, ResultMapping parentMapping) throws SQLException {
    try {
      //此可暂时忽略，此在存储过程时才会调用。
      if (parentMapping != null) {
        handleRowValues(rsw, resultMap, null, RowBounds.DEFAULT, parentMapping);
      } else {
        //如果没有默认的resultHandler，则创建一个DefaultResultHandler对象。
        if (resultHandler == null) {
          //创建DefaultResultHandler对象
          DefaultResultHandler defaultResultHandler = new DefaultResultHandler(objectFactory);
          //处理ResultSet,返回每一行记录.
          handleRowValues(rsw, resultMap, defaultResultHandler, rowBounds, null);
          //添加DefaultResultHandler的处理结果到multipleResults对象中
          multipleResults.add(defaultResultHandler.getResultList());
        } else {
          handleRowValues(rsw, resultMap, resultHandler, rowBounds, null);
        }
      }
    } finally {
      // issue #228 (close resultsets)
      closeResultSet(rsw.getResultSet());
    }
  }

  /**
   * 行数据的处理
   * @param rsw
   * @param resultMap
   * @param resultHandler
   * @param rowBounds
   * @param parentMapping
   * @throws SQLException
   */
  public void handleRowValues(ResultSetWrapper rsw, ResultMap resultMap, ResultHandler<?> resultHandler, RowBounds rowBounds, ResultMapping parentMapping) throws SQLException {
    if (resultMap.hasNestedResultMaps()) {
      ensureNoRowBounds();
      checkResultHandler();
      handleRowValuesForNestedResultMap(rsw, resultMap, resultHandler, rowBounds, parentMapping);
    }
    //普通的查询一般都执行这个结果集封装
    else {
      handleRowValuesForSimpleResultMap(rsw, resultMap, resultHandler, rowBounds, parentMapping);
    }
  }

  private void handleRowValuesForSimpleResultMap(ResultSetWrapper rsw, ResultMap resultMap, ResultHandler<?> resultHandler, RowBounds rowBounds, ResultMapping parentMapping)
    throws SQLException {
    DefaultResultContext<Object> resultContext = new DefaultResultContext<>();
    //拿到结果对象ResultSet
    ResultSet resultSet = rsw.getResultSet();
    //检查跳过行
    skipRows(resultSet, rowBounds);
    //遍历数据行完成数据的封装操作
    while (shouldProcessMoreRows(resultContext, rowBounds) && !resultSet.isClosed() && resultSet.next()) {
      //对resultMap中的discriminator标签做特殊处理
      ResultMap discriminatedResultMap = resolveDiscriminatedResultMap(resultSet, resultMap, null);
      //结果行的封装
      Object rowValue = getRowValue(rsw, discriminatedResultMap, null);
      storeObject(resultHandler, resultContext, rowValue, parentMapping, resultSet);
    }
  }

  /**
   * 对每行数据做封装操作
   * @param rsw 结果集对象
   * @param resultMap 返回的对象描述信息
   * @param columnPrefix
   * @return
   * @throws SQLException
   */
  private Object getRowValue(ResultSetWrapper rsw, ResultMap resultMap, String columnPrefix) throws SQLException {
    final ResultLoaderMap lazyLoader = new ResultLoaderMap();
    //创建返回的结果对象
    Object rowValue = createResultObject(rsw, resultMap, lazyLoader, columnPrefix);
    if (rowValue != null && !hasTypeHandlerForResultObject(rsw, resultMap.getType())) {
      final MetaObject metaObject = configuration.newMetaObject(rowValue);
      boolean foundValues = this.useConstructorMappings;
      //检查当前是否需要做字段影射填充操作
      if (shouldApplyAutomaticMappings(resultMap, false)) {
        //按照字段映射关系进行属性的值设置操作
        foundValues = applyAutomaticMappings(rsw, resultMap, metaObject, columnPrefix) || foundValues;
      }
      foundValues = applyPropertyMappings(rsw, resultMap, metaObject, lazyLoader, columnPrefix) || foundValues;
      foundValues = lazyLoader.size() > 0 || foundValues;
      rowValue = foundValues || configuration.isReturnInstanceForEmptyRow() ? rowValue : null;
    }
    return rowValue;
  }

  private Object createResultObject(ResultSetWrapper rsw, ResultMap resultMap, ResultLoaderMap lazyLoader, String columnPrefix) throws SQLException {
    this.useConstructorMappings = false; // reset previous mapping result
    final List<Class<?>> constructorArgTypes = new ArrayList<>();
    final List<Object> constructorArgs = new ArrayList<>();
    //执行结果对象的创建
    Object resultObject = createResultObject(rsw, resultMap, constructorArgTypes, constructorArgs, columnPrefix);

    if (resultObject != null && !hasTypeHandlerForResultObject(rsw, resultMap.getType())) {
      //与mapper.xml文件中的ResultMap对应。配制了表与属性之间的映射关系。
      final List<ResultMapping> propertyMappings = resultMap.getPropertyResultMappings();
      for (ResultMapping propertyMapping : propertyMappings) {
        // issue gcode #109 && issue #149
        //当迟延加载启用时，则进行代理对象的创建。
        if (propertyMapping.getNestedQueryId() != null && propertyMapping.isLazy()) {
          resultObject = configuration.getProxyFactory().createProxy(resultObject, lazyLoader, configuration, objectFactory, constructorArgTypes, constructorArgs);
          break;
        }
      }
    }
    this.useConstructorMappings = resultObject != null && !constructorArgTypes.isEmpty(); // set current mapping result
    return resultObject;
  } 
}
```

### 3.3 ProxyFactory接口
```java
package org.apache.ibatis.executor.loader;

public interface ProxyFactory {

  /**
   * 设置属性
   * @param properties
   */
  default void setProperties(Properties properties) {
    // NOP
  }

  /**
   * 创建代理对象
   * @param target
   * @param lazyLoader
   * @param configuration
   * @param objectFactory
   * @param constructorArgTypes
   * @param constructorArgs
   * @return
   */
  Object createProxy(Object target, ResultLoaderMap lazyLoader, Configuration configuration, ObjectFactory objectFactory, List<Class<?>> constructorArgTypes, List<Object> constructorArgs);
}
```

### 3.4 ProxyFactory接口的实现JavassistProxyFactory
```java
package org.apache.ibatis.executor.loader.javassist;

public class JavassistProxyFactory implements org.apache.ibatis.executor.loader.ProxyFactory {
  @Override
  public Object createProxy(Object target, ResultLoaderMap lazyLoader, Configuration configuration, ObjectFactory objectFactory, List<Class<?>> constructorArgTypes, List<Object> constructorArgs) {
    //代理对象的创建
    return EnhancedResultObjectProxyImpl.createProxy(target, lazyLoader, configuration, objectFactory, constructorArgTypes, constructorArgs);
  }

  private static class EnhancedResultObjectProxyImpl implements MethodHandler {
    public static Object createProxy(Object target, ResultLoaderMap lazyLoader, Configuration configuration, ObjectFactory objectFactory, List<Class<?>> constructorArgTypes, List<Object> constructorArgs) {
      final Class<?> type = target.getClass();
      //创建EnhancedResultObjectProxyImpl代理对象,类比jdk动态代理中的InvocationHandler的作用。代理方法的操作。
      EnhancedResultObjectProxyImpl callback = new EnhancedResultObjectProxyImpl(type, lazyLoader, configuration, objectFactory, constructorArgTypes, constructorArgs);
      //创建代理对象
      Object enhanced = crateProxy(type, callback, constructorArgTypes, constructorArgs);
      //将属性复制到enhanced中
      PropertyCopier.copyBeanProperties(type, target, enhanced);
      return enhanced;
    }
  }
  
  static Object crateProxy(Class<?> type, MethodHandler callback, List<Class<?>> constructorArgTypes, List<Object> constructorArgs) {
    //创建javassis Proxy Factory对象
    ProxyFactory enhancer = new ProxyFactory();
    //设置父类
    enhancer.setSuperclass(type);

    try {
      //设置接口为writeReplace，与序列化相关，可忽略
      type.getDeclaredMethod(WRITE_REPLACE_METHOD);
      // ObjectOutputStream will call writeReplace of objects returned by writeReplace
      if (LogHolder.log.isDebugEnabled()) {
        LogHolder.log.debug(WRITE_REPLACE_METHOD + " method was found on bean " + type + ", make sure it returns this");
      }
    } catch (NoSuchMethodException e) {
      enhancer.setInterfaces(new Class[]{WriteReplaceInterface.class});
    } catch (SecurityException e) {
      // nothing to do here
    }

    //创建代理对象
    Object enhanced;
    Class<?>[] typesArray = constructorArgTypes.toArray(new Class[constructorArgTypes.size()]);
    Object[] valuesArray = constructorArgs.toArray(new Object[constructorArgs.size()]);
    try {
      enhanced = enhancer.create(typesArray, valuesArray);
    } catch (Exception e) {
      throw new ExecutorException("Error creating lazy proxy.  Cause: " + e, e);
    }
    //设置代理对象的执行器,当代理对象被调用，就会执行到此callback的方法中
    ((Proxy) enhanced).setHandler(callback);
    return enhanced;
  }  
}
```
至此，代理对象就已经创建完成。延迟加载的代码接下来继续分析。


### 3.5 EnhancedResultObjectProxyImpl的invoke方法调用
```java
package org.apache.ibatis.executor.loader.javassist;

public class JavassistProxyFactory implements org.apache.ibatis.executor.loader.ProxyFactory {
  private static class EnhancedResultObjectProxyImpl implements MethodHandler {

    @Override
    public Object invoke(Object enhanced, Method method, Method methodProxy, Object[] args) throws Throwable {
      final String methodName = method.getName();
      try {
        synchronized (lazyLoader) {
          //序列化相关，可忽略
          if (WRITE_REPLACE_METHOD.equals(methodName)) {
            Object original;
            if (constructorArgTypes.isEmpty()) {
              original = objectFactory.create(type);
            } else {
              original = objectFactory.create(type, constructorArgTypes, constructorArgs);
            }
            PropertyCopier.copyBeanProperties(type, enhanced, original);
            if (lazyLoader.size() > 0) {
              return new JavassistSerialStateHolder(original, lazyLoader.getProperties(), objectFactory, constructorArgTypes, constructorArgs);
            } else {
              return original;
            }
          }
          //普通的方法执行
          else {
            //当前延迟加载被配制，并且不是finalize方法
            if (lazyLoader.size() > 0 && !FINALIZE_METHOD.equals(methodName)) {
              //如果aggressive为true，表示要加载全部的属性
              if (aggressive || lazyLoadTriggerMethods.contains(methodName)) {
                lazyLoader.loadAll();
              }
              //如果当前为set属性，则跳过加载
              else if (PropertyNamer.isSetter(methodName)) {
                final String property = PropertyNamer.methodToProperty(methodName);
                lazyLoader.remove(property);
              }
              //如果当前为get属性，则进行加载验证
              else if (PropertyNamer.isGetter(methodName)) {
                //取得当前的属性名
                final String property = PropertyNamer.methodToProperty(methodName);
                //检查当前是否在延迟加载中,如果在，则执行加载操作
                if (lazyLoader.hasLoader(property)) {
                  lazyLoader.load(property);
                }
              }
            }
          }
        }
        //执行原方法的调用
        return methodProxy.invoke(enhanced, args);
      } catch (Throwable t) {
        throw ExceptionUtil.unwrapThrowable(t);
      }
    }
  }
}
```
在延迟加载的方法调用中，会检查属性是否配制了延迟加载，如果配制了延迟加载，则按当前的属性进行加载操作。

### 3.6 lazyLoader的loader方法
```java
package org.apache.ibatis.executor.loader;

public class ResultLoaderMap {
  public boolean load(String property) throws SQLException {
    LoadPair pair = loaderMap.remove(property.toUpperCase(Locale.ENGLISH));
    if (pair != null) {
      pair.load();
      return true;
    }
    return false;
  }
  
  /**
   * Property which was not loaded yet.
   */
  public static class LoadPair implements Serializable {
    public void load() throws SQLException {
      /* These field should not be null unless the loadpair was serialized.
       * Yet in that case this method should not be called. */
      if (this.metaResultObject == null) {
        throw new IllegalArgumentException("metaResultObject is null");
      }
      if (this.resultLoader == null) {
        throw new IllegalArgumentException("resultLoader is null");
      }

      this.load(null);
    }
	
    public void load(final Object userObject) throws SQLException {
      if (this.metaResultObject == null || this.resultLoader == null) {
        if (this.mappedParameter == null) {
          throw new ExecutorException("Property [" + this.property + "] cannot be loaded because "
            + "required parameter of mapped statement ["
            + this.mappedStatement + "] is not serializable.");
        }

        final Configuration config = this.getConfiguration();
        final MappedStatement ms = config.getMappedStatement(this.mappedStatement);
        if (ms == null) {
          throw new ExecutorException("Cannot lazy load property [" + this.property
            + "] of deserialized object [" + userObject.getClass()
            + "] because configuration does not contain statement ["
            + this.mappedStatement + "]");
        }

        this.metaResultObject = config.newMetaObject(userObject);
        this.resultLoader = new ResultLoader(config, new ClosedExecutor(), ms, this.mappedParameter,
          metaResultObject.getSetterType(this.property), null, null);
      }

      /* We are using a new executor because we may be (and likely are) on a new thread
       * and executors aren't thread safe. (Is this sufficient?)
       *
       * A better approach would be making executors thread safe. */
      if (this.serializationCheck == null) {
        final ResultLoader old = this.resultLoader;
        this.resultLoader = new ResultLoader(old.configuration, new ClosedExecutor(), old.mappedStatement,
          old.parameterObject, old.targetType, old.cacheKey, old.boundSql);
      }
	
	  //加载数据设置到属性中
      this.metaResultObject.setValue(property, this.resultLoader.loadResult());
    }
  }
}
```

通过上面的跟踪可以发现，最后调用了属性的设置方法，调用了ResultLoader对象执行了loadResult方法。那就继续跟踪下数据的加载方法loadResult()

### 3.7 ResultLoader的loadResult方法
```java
package org.apache.ibatis.executor.loader;

public class ResultLoader {
  public Object loadResult() throws SQLException {
    List<Object> list = selectList();
    resultObject = resultExtractor.extractObjectFromList(list, targetType);
    return resultObject;
  }

  private <E> List<E> selectList() throws SQLException {
    Executor localExecutor = executor;
    if (Thread.currentThread().getId() != this.creatorThreadId || localExecutor.isClosed()) {
      localExecutor = newExecutor();
    }
    try {
      return localExecutor.query(mappedStatement, parameterObject, RowBounds.DEFAULT, Executor.NO_RESULT_HANDLER, cacheKey, boundSql);
    } finally {
      if (localExecutor != executor) {
        localExecutor.close(false);
      }
    }
  }
}
```
此处的代码可以发现，此最终还是调用了Executor的查询方法。

至此延迟加载 的代码便分析完成了。