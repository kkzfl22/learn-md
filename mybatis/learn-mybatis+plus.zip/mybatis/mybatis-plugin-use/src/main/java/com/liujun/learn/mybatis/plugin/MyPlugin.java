package com.liujun.learn.mybatis.plugin;

import org.apache.ibatis.executor.statement.StatementHandler;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.plugin.Intercepts;
import org.apache.ibatis.plugin.Invocation;
import org.apache.ibatis.plugin.Plugin;
import org.apache.ibatis.plugin.Signature;

import java.sql.Connection;
import java.util.Properties;

/**
 * 自定义实现一个插件
 *
 * @author liujun
 * @since 2022/7/5
 */
@Intercepts({
  @Signature(
      type = StatementHandler.class,
      method = "prepare",
      args = {Connection.class, Integer.class})
})
public class MyPlugin implements Interceptor {

  /**
   * 插件的的拦截方法，只要被拦截的对象的目标方法被执行时，每次都会执行intercept方法
   *
   * @param invocation
   * @return
   * @throws Throwable
   */
  @Override
  public Object intercept(Invocation invocation) throws Throwable {
    System.out.println("在执行方法前，进行了增强");
    return invocation.proceed();
  }

  /**
   * 主要为了把当前拦截器生成的代理存到拦截器链中
   *
   * @param target
   * @return
   */
  @Override
  public Object plugin(Object target) {
    return Plugin.wrap(target, this);
  }

  /**
   * 获取配制文件的参数。
   *
   * @param properties
   */
  @Override
  public void setProperties(Properties properties) {
    System.out.println("收到的参数信息:" + properties);
  }
}
