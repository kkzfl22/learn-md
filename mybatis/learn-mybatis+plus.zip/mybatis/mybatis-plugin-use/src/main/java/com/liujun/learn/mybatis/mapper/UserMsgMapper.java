package com.liujun.learn.mybatis.mapper;

import com.liujun.learn.mybatis.po.UserMsgPO;

import java.util.List;

/**
 * 用户的数据库操作
 *
 * @author liujun
 * @since 2022/7/3
 */
public interface UserMsgMapper {

  /**
   * 查询所有用户的所有订单信息
   *
   * @return
   */
  List<UserMsgPO> queryAll();
}
