# mybatis源码分析 -mapper方式

## 1. 测试准备-单元测试
测试代码
```java
package org.apache.use.test;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.use.use.mapper.UserMapper;
import org.apache.use.use.po.UserMsgPO;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.io.InputStream;

public class QuickMapperStart {
  @Test
  public void mapperQuery() throws IOException {
    //将mybatis的配制文件转换为流,供助类加载
    InputStream streamConfig = Resources.getResourceAsStream("sqlMapConfig.xml");
    //将流转换为配制文件配制对象
    SqlSessionFactory build = new SqlSessionFactoryBuilder().build(streamConfig);

    SqlSession sqlSession = build.openSession();
    UserMsgPO user = new UserMsgPO();
    user.setId(1);
    UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
    UserMsgPO userRsp = userMapper.query(user);
    System.out.println(userRsp);
    Assertions.assertNotNull(userRsp.getName());
  }
}
```
配制文件
sqlMapConfig.xml
```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE configuration PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-config.dtd">
<configuration>
    <properties resource="jdbc.properties"/>
    <environments default="default">
        <environment id="default">
            <!--JDBC表示把数据库的事务交给JDBC进行管理。 MANAGER让容器进行管理，很少使用，它从来不提交回滚一个连接。-->
            <transactionManager type="JDBC"></transactionManager>
            <!--POOLED使用mybatis的连接池，UNPOOLED表示不使用连接池,每次使用数据库时才打开和关闭连接，JNDI,使用容器配制的数据源。-->
            <dataSource type="POOLED">
                <property name="driver" value="${jdbc.driver}"/>
                <property name="url" value="${jdbc.url}"/>
                <property name="username" value="${jdbc.username}"/>
                <property name="password" value="${jdbc.password}"/>
            </dataSource>
        </environment>
    </environments>
    <mappers>
        <package name="org.apache.use.use.mapper"/>
    </mappers>
</configuration>
```
\resources\org\apache\use\use\mapper\UserMapper.xml
```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE mapper
  PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
  "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="org.apache.use.use.mapper.UserMapper">

  <select id="query" parameterType="org.apache.use.use.po.UserMsgPO"
          resultType="org.apache.use.use.po.UserMsgPO">
    select * from user_msg
    <where>
      <if test="id != null">
        and id = #{id}
      </if>
    </where>
  </select>
</mapper>
```
jdbc.properties
```properties
jdbc.driver=org.sqlite.JDBC
jdbc.url=jdbc:sqlite:../mybatis.db
jdbc.username=
jdbc.password=
```

数据库操作的mapper文件
```java
package org.apache.use.use.mapper;

import org.apache.use.use.po.UserMsgPO;

/**
 * @author liujun
 * @since 2022/7/13
 */
public interface UserMapper {

  UserMsgPO query(UserMsgPO user);
}
```

实例对象
```java
package org.apache.use.use.po;
import java.io.Serializable;
public class UserMsgPO implements Serializable {

  /**
   * 用户的id
   */
  private Integer id;

  /**
   * 名称的信息
   */
  private String name;

  public Integer getId() {
    return id;
  }
  public void setId(Integer id) {
    this.id = id;
  }
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }
  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("UserMsgPO{");
    sb.append("id=").append(id);
    sb.append(", name='").append(name).append('\'');
    sb.append('}');
    return sb.toString();
  }
}
```

运行可查看控制台输出输出信息

## 2 源码分析
在使用mapper方式后，我提出了两个问题：
1. getMapper方法是如何对UserMapper产生代理对象的？
2. 代理对象在执行时，底层的invoke是如何执行的?
下面就跟随源来来一起解徐这两个问题：
首先还是从配制文件加载看起。首先这里是使用package方式的引入，那跟之前的引入有啥区别呢？来以源码的角度看起：
资源加载首先使用的是SqlSessionFactoryBuilder，这里会创建XMLConfigBuilder对象，将xml文件转换为Configuration对象
### 2.1 java的mapper文件与数据库配制xml文件的映射关系的建立
```java
package org.apache.ibatis.session;

public class SqlSessionFactoryBuilder {

  /**
   * 调用初始化构造器对象，传递了一个文件输入流
   * @param inputStream 输入流
   * @return 加载成为配制信息
   */
  public SqlSessionFactory build(InputStream inputStream) {
    //调用了重载方法，环境和属性信息为空
    return build(inputStream, null, null);
  }

  /**
   * 构建方法，解析配制文件，封装Configuration对象
   * @param inputStream 配制文件的输入流
   * @param environment 环境信息
   * @param properties 属性信息。
   * @return
   */
  public SqlSessionFactory build(InputStream inputStream, String environment, Properties properties) {
    try {
      //创建XMLConfigBuilder，XMLConfigBuilder是专门用于解析mybatis配制文件的类。
      XMLConfigBuilder parser = new XMLConfigBuilder(inputStream, environment, properties);
      //parser.parse()将配制文件转换成配制类。
      return build(parser.parse());
    } catch (Exception e) {
      throw ExceptionFactory.wrapException("Error building SqlSession.", e);
    } finally {
      ErrorContext.instance().reset();
      try {
        inputStream.close();
      } catch (IOException e) {
        // Intentionally ignore. Prefer previous error.
      }
    }
  }
}
```
接下来查看xml文件转换为Configuration对象的方法.此处特别在查看了mappers标签的处理，接下来跟踪其转换的过程。
```java
package org.apache.ibatis.builder.xml;

public class XMLConfigBuilder extends BaseBuilder {
  /**
   * 将mybatis配制对象转换为Configuration对象
   * @return
   */
  public Configuration parse() {
    //若已经解析，则抛出异常。
    if (parsed) {
      throw new BuilderException("Each XMLConfigBuilder can only be used once.");
    }
    //标记当前已经解析
    parsed = true;
    //读取mybatis配制文件的元素configuration，交给parseConfiguration方法处理
    parseConfiguration(parser.evalNode("/configuration"));
    return configuration;
  }
  
  /**
   * 进行mapper标签的处理，
   *
   * @param parent xml文件的标签对象
   * @throws Exception 异常
   */
  private void mapperElement(XNode parent) throws Exception {
    if (parent != null) {
      for (XNode child : parent.getChildren()) {
        //优先处理mappers标签中的package标签
        if ("package".equals(child.getName())) {
          //读取那么属性，配制信息为一个包的路径
          String mapperPackage = child.getStringAttribute("name");
          configuration.addMappers(mapperPackage);
        } else {
          String resource = child.getStringAttribute("resource");
          String url = child.getStringAttribute("url");
          String mapperClass = child.getStringAttribute("class");
          //当前仅配制了resource标签
          if (resource != null && url == null && mapperClass == null) {
            ErrorContext.instance().resource(resource);
            InputStream inputStream = Resources.getResourceAsStream(resource);
            XMLMapperBuilder mapperParser = new XMLMapperBuilder(inputStream, configuration, resource, configuration.getSqlFragments());
            mapperParser.parse();
          }
          //当前仅配制了url标签
          else if (resource == null && url != null && mapperClass == null) {
            ErrorContext.instance().resource(url);
            InputStream inputStream = Resources.getUrlAsStream(url);
            XMLMapperBuilder mapperParser = new XMLMapperBuilder(inputStream, configuration, url, configuration.getSqlFragments());
            mapperParser.parse();
          }
          //当前仅配制了class标签
          else if (resource == null && url == null && mapperClass != null) {
            Class<?> mapperInterface = Resources.classForName(mapperClass);
            configuration.addMapper(mapperInterface);
          } else {
            throw new BuilderException("A mapper element may only specify a url, resource or class, but not more than one.");
          }
        }
      }
    }
  }
}
```
进入`configuration.addMappers(mapperPackage);`这一段代码中，
```java
package org.apache.ibatis.session;

public class Configuration {
  protected final MapperRegistry mapperRegistry = new MapperRegistry(this);
  
  public void addMappers(String packageName) {
    mapperRegistry.addMappers(packageName);
  }
}
```
从以上代码中可以看出，这出又调用了MapperRegistry的addMappers方法，那就继续跟踪
```java
package org.apache.ibatis.binding;

public class MapperRegistry {

  private final Configuration config;
  private final Map<Class<?>, MapperProxyFactory<?>> knownMappers = new HashMap<>();

  public MapperRegistry(Configuration config) {
    this.config = config;
  }

  public <T> boolean hasMapper(Class<T> type) {
    return knownMappers.containsKey(type);
  }

  /**
   * 对每个mapper映射的java文件的处理,做加载转换处理
   * @param type
   * @param <T>
   */
  public <T> void addMapper(Class<T> type) {
    if (type.isInterface()) {
      if (hasMapper(type)) {
        throw new BindingException("Type " + type + " is already known to the MapperRegistry.");
      }
      boolean loadCompleted = false;
      try {
        knownMappers.put(type, new MapperProxyFactory<>(type));
        // It's important that the type is added before the parser is run
        // otherwise the binding may automatically be attempted by the
        // mapper parser. If the type is already known, it won't try.
        //针对当前的类文件按与xml文件文件的映射关系进行加载转换处理
        MapperAnnotationBuilder parser = new MapperAnnotationBuilder(config, type);
        parser.parse();
        loadCompleted = true;
      } finally {
        if (!loadCompleted) {
          knownMappers.remove(type);
        }
      }
    }
  }

  public Collection<Class<?>> getMappers() {
    return Collections.unmodifiableCollection(knownMappers.keySet());
  }

  public void addMappers(String packageName, Class<?> superType) {
    ResolverUtil<Class<?>> resolverUtil = new ResolverUtil<>();
    //递归遍历拿到所有的Class文件列表
    resolverUtil.find(new ResolverUtil.IsA(superType), packageName);
    Set<Class<? extends Class<?>>> mapperSet = resolverUtil.getClasses();
    //对每一个class文件做处理
    for (Class<?> mapperClass : mapperSet) {
      addMapper(mapperClass);
    }
  }

  public void addMappers(String packageName) {
    addMappers(packageName, Object.class);
  }
}
```
经过以上的代码，java的mapper文件与数据库配制的xml文件之间的映射关系已经建立。


### 2.2 java的mapper文件是如何产生代理对象的？
首先我们还是得从
`UserMapper userMapper = sqlSession.getMapper(UserMapper.class);`这行代码开始跟踪了
此时将来到sqlSession的getMapper方法
```java
package org.apache.ibatis.session.defaults;

public class DefaultSqlSession implements SqlSession {
  private final Configuration configuration;
  @Override
  public <T> T getMapper(Class<T> type) {
    return configuration.getMapper(type, this);
  }
}
```
进一步跟踪发现是调用了MapperRegistry的getMapper的方法，而MapperRegistry在加载映射关系时，就是将相关信息存储到了这个对象中
```java
package org.apache.ibatis.session;

public class Configuration {
  protected final MapperRegistry mapperRegistry = new MapperRegistry(this);
  
  public <T> T getMapper(Class<T> type, SqlSession sqlSession) {
    return mapperRegistry.getMapper(type, sqlSession);
  }
}
```
接下来看看加载方法
```java
package org.apache.ibatis.binding;

public class MapperRegistry {

  private final Configuration config;
  private final Map<Class<?>, MapperProxyFactory<?>> knownMappers = new HashMap<>();

  public MapperRegistry(Configuration config) {
    this.config = config;
  }

  @SuppressWarnings("unchecked")
  public <T> T getMapper(Class<T> type, SqlSession sqlSession) {
    final MapperProxyFactory<T> mapperProxyFactory = (MapperProxyFactory<T>) knownMappers.get(type);
    if (mapperProxyFactory == null) {
      throw new BindingException("Type " + type + " is not known to the MapperRegistry.");
    }
    try {
      return mapperProxyFactory.newInstance(sqlSession);
    } catch (Exception e) {
      throw new BindingException("Error getting mapper instance. Cause: " + e, e);
    }
  }
}
```
在这里调用了mapperProxyFactory的newInstance方法，继续跟踪
```java
package org.apache.ibatis.binding;

public class MapperProxyFactory<T> {
  private final Class<T> mapperInterface;
  private final Map<Method, MapperMethod> methodCache = new ConcurrentHashMap<>();

  @SuppressWarnings("unchecked")
  protected T newInstance(MapperProxy<T> mapperProxy) {
    return (T) Proxy.newProxyInstance(mapperInterface.getClassLoader(), new Class[] { mapperInterface }, mapperProxy);
  }

  public T newInstance(SqlSession sqlSession) {
    final MapperProxy<T> mapperProxy = new MapperProxy<>(sqlSession, mapperInterface, methodCache);
    return newInstance(mapperProxy);
  }
}
```
通过以上代码发现，此使用的是jdk的动态代理来动态生成一个代理对象的，在jdk的代理中，需要实现一个InvocationHandler接口，
而MapperProxy则实现了这个接口,接下来看看是如何实现此接口的
```java
package org.apache.ibatis.binding;

public class MapperProxy<T> implements InvocationHandler, Serializable {

  @Override
  public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
    try {
      //判断当间为object定义的方法，直接调用
      if (Object.class.equals(method.getDeclaringClass())) {
        return method.invoke(this, args);
      } else if (method.isDefault()) {
        if (privateLookupInMethod == null) {
          return invokeDefaultMethodJava8(proxy, method, args);
        } else {
          return invokeDefaultMethodJava9(proxy, method, args);
        }
      }
    } catch (Throwable t) {
      throw ExceptionUtil.unwrapThrowable(t);
    }
    //获得MapperMethod对象
    final MapperMethod mapperMethod = cachedMapperMethod(method);
    //重点在这，调用这个方法进行执行
    return mapperMethod.execute(sqlSession, args);
  }

}
```
通过查看此接口发现接口实现了invoke方法，在这接口中又创建了一个MapperMethod对象，然后进行执行。
下面继续来查看下此执行
```java
package org.apache.ibatis.binding;

public class MapperMethod {

  public Object execute(SqlSession sqlSession, Object[] args) {
    Object result;
    //判断mapper方法的类型，最终调用的，还是SQLSession中的方法
    switch (command.getType()) {
      case INSERT: {
        //做对象的转换
        Object param = method.convertArgsToSqlCommandParam(args);
        //执行插入操作
        //并将结果记录到影响的行数
        result = rowCountResult(sqlSession.insert(command.getName(), param));
        break;
      }
      case UPDATE: {
        //做对象的转换操作
        Object param = method.convertArgsToSqlCommandParam(args);
        //执行修改操作
        //将结果记录到影响的行数中
        result = rowCountResult(sqlSession.update(command.getName(), param));
        break;
      }
      case DELETE: {
        //做参数对象的转换
        Object param = method.convertArgsToSqlCommandParam(args);
        //执行删除操作
        //将结果记录到影响的行数中
        result = rowCountResult(sqlSession.delete(command.getName(), param));
        break;
      }
      case SELECT:
        //无返回结果，并且有ResultHandler处理，那将就结果交给ResultHandler进行处理
        if (method.returnsVoid() && method.hasResultHandler()) {
          executeWithResultHandler(sqlSession, args);
          result = null;
        }
        //如果当前记录存在多行
        else if (method.returnsMany()) {
          result = executeForMany(sqlSession, args);
        }
        //如果返回结果为map
        else if (method.returnsMap()) {
          result = executeForMap(sqlSession, args);
        }
        //如果返回结果为Cursor,即游标
        else if (method.returnsCursor()) {
          result = executeForCursor(sqlSession, args);
        }
        //其他则为执行查询返回单个对象。
        else {
          //封装参数
          Object param = method.convertArgsToSqlCommandParam(args);
          //调用单个的查询
          result = sqlSession.selectOne(command.getName(), param);
          if (method.returnsOptional()
              && (result == null || !method.getReturnType().equals(result.getClass()))) {
            result = Optional.ofNullable(result);
          }
        }
        break;
      case FLUSH:
        result = sqlSession.flushStatements();
        break;
      default:
        throw new BindingException("Unknown execution method for: " + command.getName());
    }
    if (result == null && method.getReturnType().isPrimitive() && !method.returnsVoid()) {
      throw new BindingException("Mapper method '" + command.getName()
          + " attempted to return null from a method with a primitive return type (" + method.getReturnType() + ").");
    }
    return result;
  }

  private Object rowCountResult(int rowCount) {
    final Object result;
    if (method.returnsVoid()) {
      result = null;
    } else if (Integer.class.equals(method.getReturnType()) || Integer.TYPE.equals(method.getReturnType())) {
      result = rowCount;
    } else if (Long.class.equals(method.getReturnType()) || Long.TYPE.equals(method.getReturnType())) {
      result = (long)rowCount;
    } else if (Boolean.class.equals(method.getReturnType()) || Boolean.TYPE.equals(method.getReturnType())) {
      result = rowCount > 0;
    } else {
      throw new BindingException("Mapper method '" + command.getName() + "' has an unsupported return type: " + method.getReturnType());
    }
    return result;
  }

  private void executeWithResultHandler(SqlSession sqlSession, Object[] args) {
    MappedStatement ms = sqlSession.getConfiguration().getMappedStatement(command.getName());
    if (!StatementType.CALLABLE.equals(ms.getStatementType())
        && void.class.equals(ms.getResultMaps().get(0).getType())) {
      throw new BindingException("method " + command.getName()
          + " needs either a @ResultMap annotation, a @ResultType annotation,"
          + " or a resultType attribute in XML so a ResultHandler can be used as a parameter.");
    }
    Object param = method.convertArgsToSqlCommandParam(args);
    if (method.hasRowBounds()) {
      RowBounds rowBounds = method.extractRowBounds(args);
      sqlSession.select(command.getName(), param, rowBounds, method.extractResultHandler(args));
    } else {
      sqlSession.select(command.getName(), param, method.extractResultHandler(args));
    }
  }

  private <E> Object executeForMany(SqlSession sqlSession, Object[] args) {
    List<E> result;
    Object param = method.convertArgsToSqlCommandParam(args);
    if (method.hasRowBounds()) {
      RowBounds rowBounds = method.extractRowBounds(args);
      result = sqlSession.selectList(command.getName(), param, rowBounds);
    } else {
      result = sqlSession.selectList(command.getName(), param);
    }
    // issue #510 Collections & arrays support
    if (!method.getReturnType().isAssignableFrom(result.getClass())) {
      if (method.getReturnType().isArray()) {
        return convertToArray(result);
      } else {
        return convertToDeclaredCollection(sqlSession.getConfiguration(), result);
      }
    }
    return result;
  }
}
```
通过查看源码，可以发现，此调用最终还是sqlSession的相关方法，executeForMany批量结果集，调用的还是selectList方法
而样例中，我们调用的是query,返回结果集仅为一个对象，调用的sqlSession.selectOne方法。

## 结束
至此mybatis的mapper代理方式的一个执行就结束了，这里我以源码方式将mybatis的相关实现，做了一个阅读，当然很粗，不过没有关系，很多的细节，
在能完整理解整个结构后，细节点就可以自己去慢慢加入深入。
