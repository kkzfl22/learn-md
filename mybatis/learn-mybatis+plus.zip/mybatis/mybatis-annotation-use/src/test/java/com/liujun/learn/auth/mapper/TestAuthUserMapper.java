package com.liujun.learn.auth.mapper;

import com.liujun.learn.auth.po.AuthUser;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.io.InputStream;
import java.util.List;

/**
 * 查询用户的所有角色
 *
 * @author liujun
 * @since 2022/7/3
 */
public class TestAuthUserMapper {

  @Test
  public void baseQuery() {
    // 1,加载Mybatis的核心配制文件为流
    InputStream mapConfigStream =
        this.getClass().getClassLoader().getResourceAsStream("sqlMapConfig.xml");

    // 2,构建一个SqlSessionFactory对象
    SqlSessionFactory sessionFactory = new SqlSessionFactoryBuilder().build(mapConfigStream);

    // 3,打开一个Session对象
    // SqlSession session = sessionFactory.openSession(true);当参数设置为true时，将不再需要手动提交事务.自动提交。
    try (SqlSession session = sessionFactory.openSession(); ) {

      AuthUserMapper userMsgMapper = session.getMapper(AuthUserMapper.class);

      // 4, 执行一个查询
      List<AuthUser> dataDataResult = userMsgMapper.queryAllUserAndRole();

      for (AuthUser userItem : dataDataResult) {
        System.out.println(userItem);
      }

      System.out.println();
      // System.out.println(dataDataResult);
      Assertions.assertNotNull(dataDataResult);
    } catch (Exception e) {
      e.printStackTrace();
      Assertions.fail();
    }
  }
}
