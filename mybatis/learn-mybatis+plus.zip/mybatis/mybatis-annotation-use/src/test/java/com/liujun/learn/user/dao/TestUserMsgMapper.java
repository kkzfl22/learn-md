package com.liujun.learn.user.dao;

import com.liujun.learn.user.mapper.UserMsgMapper;
import com.liujun.learn.user.po.UserMsgPO;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.InputStream;
import java.util.List;

/**
 * @author liujun
 * @since 2022/7/3
 */
public class TestUserMsgMapper {

  /** 会话对象 */
  private SqlSession session;

  /** 会话信息 */
  private UserMsgMapper userMsgMapper;

  @BeforeEach
  public void before() {
    // 1,加载Mybatis的核心配制文件为流
    InputStream mapConfigStream =
        this.getClass().getClassLoader().getResourceAsStream("sqlMapConfig.xml");

    // 2,构建一个SqlSessionFactory对象
    SqlSessionFactory sessionFactory = new SqlSessionFactoryBuilder().build(mapConfigStream);

    // 3,打开一个Session对象
    // SqlSession session = sessionFactory.openSession(true);当参数设置为true时，将不再需要手动提交事务.自动提交。
    session = sessionFactory.openSession();

    userMsgMapper = session.getMapper(UserMsgMapper.class);
  }

  @Test
  public void insert() {
    UserMsgPO user = new UserMsgPO();
    user.setId(11);
    user.setName("nam12");
    int add = userMsgMapper.insert(user);
    Assertions.assertEquals(1, add);
  }

  @Test
  public void update() {
    UserMsgPO user = new UserMsgPO();
    user.setId(11);
    user.setName("nam13");
    int update = userMsgMapper.update(user);
    Assertions.assertEquals(1, update);
  }

  @Test
  public void delete() {
    int delete = userMsgMapper.delete(11);
    Assertions.assertEquals(1, delete);
  }

  @Test
  public void query() {
    UserMsgPO user = new UserMsgPO();
    user.setId(11);
    List<UserMsgPO> list = userMsgMapper.queryByConditionId(user);
    Assertions.assertEquals(1, list.size());
  }

  /** 查询用户的所有订单 */
  @Test
  public void queryUerAllOrder() {
    List<UserMsgPO> userList = userMsgMapper.queryUserOrder();

    for (UserMsgPO userInfo : userList) {
      System.out.println(userInfo);
    }

    Assertions.assertNotNull(userList);
  }

  @AfterEach
  public void closeOper() {
    session.commit();
    session.close();
  }
}
