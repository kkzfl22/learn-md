package com.liujun.learn.user.mapper;

import com.liujun.learn.user.po.OrderPO;
import com.liujun.learn.user.po.UserMsgPO;
import org.apache.ibatis.annotations.One;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @author liujun
 * @since 2022/7/3
 */
public interface OrderInfoMapper {

  /**
   * 查询用户所关联的订单信息
   *
   * @param id
   * @return
   */
  @Results({
    @Result(property = "id", column = "id"),
    @Result(property = "money", column = "money"),
    @Result(property = "orderTime", column = "orderTime"),
    @Result(
        property = "user",
        column = "user_id",
        javaType = UserMsgPO.class,
        one = @One(select = "com.liujun.learn.user.mapper.UserMsgMapper.queryById")),
  })
  @Select("select * from order_info where id = #{id}")
  OrderPO queryOneLink(Integer id);

  /**
   * 根据用户的id查询订单信息
   *
   * @param uid
   * @return
   */
  @Select("select * from order_info where user_id=#{uid}")
  List<OrderPO> queryOrderByUid(Integer uid);
}
