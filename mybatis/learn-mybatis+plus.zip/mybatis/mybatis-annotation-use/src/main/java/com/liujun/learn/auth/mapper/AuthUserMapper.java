package com.liujun.learn.auth.mapper;

import com.liujun.learn.auth.po.AuthUser;
import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 用户的查询 多对多的关联查询
 *
 * @author liujun
 * @since 2022/7/3
 */
public interface AuthUserMapper {

  /**
   * 查询所有用户的所有角色
   *
   * @return
   */
  @Results({
    @Result(property = "id", column = "id"),
    @Result(property = "name", column = "name"),
    @Result(
        property = "userRole",
        column = "id",
        javaType = List.class,
        many = @Many(select = "com.liujun.learn.auth.mapper.AuthRoleMapper.queryRoleByUid")),
  })
  @Select("select * from auth_user")
  List<AuthUser> queryAllUserAndRole();
}
