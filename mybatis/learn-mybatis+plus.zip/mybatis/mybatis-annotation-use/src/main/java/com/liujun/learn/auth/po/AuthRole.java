package com.liujun.learn.auth.po;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 角色的信息
 *
 * @author liujun
 * @since 2022/7/3
 */
@Getter
@Setter
@ToString
public class AuthRole {

  /** 用户的id */
  private Integer id;

  /** 用户的名称 */
  private String name;
}
