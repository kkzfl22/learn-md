package com.liujun.learn.user.mapper;

import com.liujun.learn.user.po.UserMsgPO;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.One;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * 用户的数据库操作
 *
 * @author liujun
 * @since 2022/7/3
 */
public interface UserMsgMapper {

  /**
   * 添加数据
   *
   * @param user
   * @return
   */
  @Insert("insert into user_msg(id,name) values(#{id},#{name})")
  int insert(UserMsgPO user);

  /**
   * 数据修改
   *
   * @param user
   * @return
   */
  @Update("update user_msg set name=#{name} where id=#{id}")
  int update(UserMsgPO user);

  /**
   * 删除操作
   *
   * @param id
   * @return
   */
  @Delete("delete from user_msg where id=#{id}")
  int delete(Integer id);

  /**
   * 查询所有用户的所有订单信息
   *
   * @return
   */
  @Select("select * from user_msg where id=#{id} ")
  List<UserMsgPO> queryByConditionId(UserMsgPO user);

  /**
   * 查询所有用户的所有订单信息
   *
   * @return
   */
  @Select("select * from user_msg where id=#{id} ")
  List<UserMsgPO> queryById(Integer id);

  /**
   * 查询用户的所有订单
   *
   * @return
   */
  @Results({
    @Result(property = "id", column = "id"),
    @Result(property = "name", column = "name"),
    @Result(
        property = "orderList",
        column = "id",
        javaType = List.class,
        many = @Many(select = "com.liujun.learn.user.mapper.OrderInfoMapper.queryOrderByUid"))
  })
  @Select("select * from user_msg ")
  List<UserMsgPO> queryUserOrder();
}
