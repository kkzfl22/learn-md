package com.liujun.learn.auth.po;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

/**
 * @author liujun
 * @since 2022/7/3
 */
@Getter
@Setter
@ToString
public class AuthUser {

  /** 用户的id */
  private Integer id;

  /** 用户名 */
  private String name;

  /** 用户关联的角色信息 */
  private List<AuthRole> userRole = new ArrayList<>();
}
