package com.liujun.learn.auth.mapper;

import com.liujun.learn.auth.po.AuthUser;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 角色的查询 多对多的关联查询
 *
 * @author liujun
 * @since 2022/7/3
 */
public interface AuthRoleMapper {

  /**
   * 查询所有用户关联的角色信息
   *
   * @return
   */
  @Select("select * from auth_role r, auth_user_role ur where ur.role_id = r.id and ur.user_id = #{uid}")
  List<AuthUser> queryRoleByUid(Integer uid);
}
