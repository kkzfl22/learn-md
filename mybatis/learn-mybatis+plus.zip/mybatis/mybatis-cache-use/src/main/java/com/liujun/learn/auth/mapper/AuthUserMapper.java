package com.liujun.learn.auth.mapper;

import com.liujun.learn.auth.po.AuthUser;

/**
 * 用户的查询 多对多的关联查询
 *
 * @author liujun
 * @since 2022/7/3
 */
public interface AuthUserMapper {

  /**
   * 按id查询用户
   *
   * @return
   */
  AuthUser queryUserById(Integer id);

  /**
   * 修改操作
   *
   * @param user
   * @return
   */
  int update(AuthUser user);
}
