package com.liujun.learn.user.mapper;

import com.liujun.learn.user.po.UserMsgPO;
import org.apache.ibatis.annotations.CacheNamespace;
import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.mybatis.caches.redis.RedisCache;

import java.util.List;

/**
 * 用户的数据库操作 @CacheNamespace 此为通过注解来开启二级缓存
 *
 * @author liujun
 * @since 2022/7/3
 */
@CacheNamespace(implementation = RedisCache.class)
public interface UserMsgMapper {

  @Update("update user_msg set name = #{name} where id = #{id}")
  int update(UserMsgPO user);

  /**
   * 查询所有用户的所有订单信息
   *
   * @return
   */
  @Select("select * from user_msg where id=#{id} ")
  List<UserMsgPO> queryByConditionId(UserMsgPO user);

  /**
   * 查询所有用户的所有订单信息
   *
   * @return
   */
  @Select("select * from user_msg where id=#{id} ")
  List<UserMsgPO> queryById(Integer id);

  /**
   * 查询用户的所有订单
   *
   * @return
   */
  @Results({
    @Result(property = "id", column = "id"),
    @Result(property = "name", column = "name"),
    @Result(
        property = "orderList",
        column = "id",
        javaType = List.class,
        many = @Many(select = "com.liujun.learn.user.mapper.OrderInfoMapper.queryOrderByUid"))
  })
  @Select("select * from user_msg ")
  List<UserMsgPO> queryUserOrder();
}
