package com.liujun.learn.auth.mapper;

import com.liujun.learn.auth.po.AuthUser;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.InputStream;

/**
 * 获取mapper的查询
 *
 * @author liujun
 * @since 2022/7/3
 */
public class TestAuthUserMapper {

  /** session的工厂对象 */
  private SqlSessionFactory sessionFactory;

  @BeforeEach
  public void before() {
    // 1,加载Mybatis的核心配制文件为流
    InputStream mapConfigStream =
        this.getClass().getClassLoader().getResourceAsStream("sqlMapConfig.xml");

    // 2,构建一个SqlSessionFactory对象
    sessionFactory = new SqlSessionFactoryBuilder().build(mapConfigStream);

    Configuration config = sessionFactory.getConfiguration();
    System.out.println("缓存操作开关:" + config.isCacheEnabled());
  }

  @Test
  public void operator() {
    SqlSession session1 = sessionFactory.openSession();
    SqlSession session2 = sessionFactory.openSession();
    AuthUserMapper userMsgMapper1 = session1.getMapper(AuthUserMapper.class);
    AuthUserMapper userMsgMapper2 = session2.getMapper(AuthUserMapper.class);

    AuthUser list = userMsgMapper1.queryUserById(1);
    Assertions.assertNotNull(list);

    // 清空一级缓存
    session1.close();
    // 当再次去获取时，不再去数据库中去获取数据。未发送查询的SQL语句
    AuthUser list2 = userMsgMapper2.queryUserById(1);
    System.out.println(list == list2);
  }

  @Test
  public void operatorUpdate() {
    SqlSession session1 = sessionFactory.openSession();
    SqlSession session2 = sessionFactory.openSession();
    SqlSession session3 = sessionFactory.openSession();
    AuthUserMapper userMsgMapper1 = session1.getMapper(AuthUserMapper.class);
    AuthUserMapper userMsgMapper2 = session2.getMapper(AuthUserMapper.class);
    AuthUserMapper userMsgMapper3 = session3.getMapper(AuthUserMapper.class);

    AuthUser list = userMsgMapper1.queryUserById(1);
    Assertions.assertNotNull(list);
    // 清空一级缓存
    session1.close();

    AuthUser userInfo = new AuthUser();
    userInfo.setId(2);
    userInfo.setName("feifei1");
    // 使用会话3来发送操作
    int updateRsp = userMsgMapper3.update(userInfo);
    Assertions.assertEquals(1, updateRsp);
    // 执行事务的提交操作
    session3.commit();

    // 当再次去获取时，由于发生了数据更新，则会再次发送查询的SQL语句
    AuthUser list2 = userMsgMapper2.queryUserById(1);
    System.out.println(list == list2);
  }

  /** 当在查询语句中将cache的参数配制为false时，则不再走缓存，每次都直接查询数据库 */
  @Test
  public void operatorCacheFalse() {
    SqlSession session1 = sessionFactory.openSession();
    SqlSession session2 = sessionFactory.openSession();
    AuthUserMapper userMsgMapper1 = session1.getMapper(AuthUserMapper.class);
    AuthUserMapper userMsgMapper2 = session2.getMapper(AuthUserMapper.class);

    AuthUser list = userMsgMapper1.queryUserById(1);
    Assertions.assertNotNull(list);

    // 清空一级缓存
    session1.close();
    // 当再次去获取时，不再去数据库中去获取数据。未发送查询的SQL语句
    AuthUser list2 = userMsgMapper2.queryUserById(1);
    System.out.println(list == list2);
  }

  /** 当flushCache参数配制为false时，即使数据发生了改变，也不仅查询本地缓存
   *
   *
   * 但此参数设置并未起作用，原因待查
   *
   * */
  @Test
  public void operatorUpdateFlushCache() {
    SqlSession session1 = sessionFactory.openSession();
    SqlSession session2 = sessionFactory.openSession();
    SqlSession session3 = sessionFactory.openSession();
    AuthUserMapper userMsgMapper1 = session1.getMapper(AuthUserMapper.class);
    AuthUserMapper userMsgMapper2 = session2.getMapper(AuthUserMapper.class);
    AuthUserMapper userMsgMapper3 = session3.getMapper(AuthUserMapper.class);

    AuthUser list = userMsgMapper1.queryUserById(1);
    Assertions.assertNotNull(list);
    // 清空一级缓存
    session1.close();

    AuthUser userInfo = new AuthUser();
    userInfo.setId(2);
    userInfo.setName("feifei1");
    // 使用会话3来发送操作
    int updateRsp = userMsgMapper3.update(userInfo);
    Assertions.assertEquals(1, updateRsp);
    // 执行事务的提交操作
    session3.commit();

    // 当再次去获取时，由于发生了数据更新，则会再次发送查询的SQL语句
    AuthUser list2 = userMsgMapper2.queryUserById(1);
    System.out.println(list == list2);
  }
}
