 package com.liujun.learn.user.dao;

 import com.liujun.learn.user.mapper.OrderInfoMapper;
 import com.liujun.learn.user.mapper.UserMsgMapper;
 import com.liujun.learn.user.po.OrderPO;
 import com.liujun.learn.user.po.UserMsgPO;
 import org.apache.ibatis.session.SqlSession;
 import org.apache.ibatis.session.SqlSessionFactory;
 import org.apache.ibatis.session.SqlSessionFactoryBuilder;
 import org.junit.jupiter.api.AfterEach;
 import org.junit.jupiter.api.Assertions;
 import org.junit.jupiter.api.BeforeEach;
 import org.junit.jupiter.api.Test;

 import java.io.InputStream;
 import java.util.List;

/**
 * @author liujun
 * @since 2022/7/3
 */
 public class TestUserMsgMapper {

  /** 会话对象 */
  private SqlSession session;

  /** 用户信息 */
  private UserMsgMapper userMsgMapper;

  /** 订单对象 */
  private OrderInfoMapper orderInfoMapper;

  @BeforeEach
  public void before() {
    // 1,加载Mybatis的核心配制文件为流
    InputStream mapConfigStream =
        this.getClass().getClassLoader().getResourceAsStream("sqlMapConfig.xml");

    // 2,构建一个SqlSessionFactory对象
    SqlSessionFactory sessionFactory = new SqlSessionFactoryBuilder().build(mapConfigStream);

    // 3,打开一个Session对象
    // SqlSession session = sessionFactory.openSession(true);当参数设置为true时，将不再需要手动提交事务.自动提交。
    session = sessionFactory.openSession();

    userMsgMapper = session.getMapper(UserMsgMapper.class);
    orderInfoMapper = session.getMapper(OrderInfoMapper.class);
  }

  /** 一级缓存，默认是开启的，当执行第一次相同语句，相同参数的SQL，则不再发送SQL的查询 */
  @Test
  public void query() {
    UserMsgPO user = new UserMsgPO();
    user.setId(11);
    List<UserMsgPO> list = userMsgMapper.queryByConditionId(user);
    Assertions.assertEquals(1, list.size());

    // 第二次如果中间未发生数据变更操作，则不会去数据库中查询
    List<UserMsgPO> list2 = userMsgMapper.queryByConditionId(user);
    Assertions.assertEquals(list, list2);

    System.out.println(list == list2);
  }

  /** 当数据发生更新后，则再次进行进行数据库刷新操作 */
  @Test
  public void queryCacheUpdate() {
    UserMsgPO user = new UserMsgPO();
    user.setId(11);
    List<UserMsgPO> list = userMsgMapper.queryByConditionId(user);
    Assertions.assertEquals(1, list.size());

    UserMsgPO updateUs = new UserMsgPO();
    updateUs.setId(11);
    updateUs.setName("namess");
    int rs = userMsgMapper.update(updateUs);
    session.commit();
    Assertions.assertEquals(1, rs);

    // 当发生了数据库的更新操作后，不会再使用缓存中的数据
    List<UserMsgPO> list2 = userMsgMapper.queryByConditionId(user);

    System.out.println(list == list2);
  }

  /** 当数据发生更新后，则再次进行进行数据库刷新操作 */
  @Test
  public void queryCacheUpdate2() {
    UserMsgPO user = new UserMsgPO();
    user.setId(11);
    List<UserMsgPO> list = userMsgMapper.queryByConditionId(user);
    Assertions.assertEquals(1, list.size());

    OrderPO orderData = new OrderPO();
    orderData.setId(10);
    orderData.setMoney(111);
    int rs = orderInfoMapper.update(orderData);
    session.commit();
    Assertions.assertEquals(1, rs);

    // 当发生了数据库的更新操作后，不会再使用缓存中的数据
    List<UserMsgPO> list2 = userMsgMapper.queryByConditionId(user);

    System.out.println(list == list2);
  }

  /** 当数据发生更新后，则再次进行进行数据库刷新操作 */
  @Test
  public void queryCacheUpdate3() {
    UserMsgPO user = new UserMsgPO();
    user.setId(11);
    List<UserMsgPO> list = userMsgMapper.queryByConditionId(user);
    Assertions.assertEquals(1, list.size());

    // 手动清空cache，则也会进行再次发送SQL
    session.clearCache();

    // 当发生了数据库的更新操作后，不会再使用缓存中的数据
    List<UserMsgPO> list2 = userMsgMapper.queryByConditionId(user);

    System.out.println(list == list2);
  }

  /** 查询用户的所有订单 */
  @Test
  public void queryUerAllOrder() {
    List<UserMsgPO> userList = userMsgMapper.queryUserOrder();

    for (UserMsgPO userInfo : userList) {
      System.out.println(userInfo);
    }

    Assertions.assertNotNull(userList);
  }

  @AfterEach
  public void closeOper() {
    session.commit();
    session.close();
  }
 }
