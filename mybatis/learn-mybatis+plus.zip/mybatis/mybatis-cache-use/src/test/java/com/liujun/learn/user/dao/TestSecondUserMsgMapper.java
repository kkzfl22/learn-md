package com.liujun.learn.user.dao;

import com.liujun.learn.user.mapper.UserMsgMapper;
import com.liujun.learn.user.po.UserMsgPO;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.InputStream;
import java.util.List;

/**
 * 二级缓存的操作
 *
 * @author liujun
 * @since 2022/7/3
 */
public class TestSecondUserMsgMapper {

  /** session的工厂对象 */
  private SqlSessionFactory sessionFactory;

  @BeforeEach
  public void before() {
    // 1,加载Mybatis的核心配制文件为流
    InputStream mapConfigStream =
        this.getClass().getClassLoader().getResourceAsStream("sqlMapConfig.xml");

    // 2,构建一个SqlSessionFactory对象
    sessionFactory = new SqlSessionFactoryBuilder().build(mapConfigStream);
  }

  /**
   * 二级缓存，能过参数开启后，跨SqlSession则不需要再次去数据库中查询 在开启二级缓存时，使用了xml文件配制SQL，则使用xml的方式开启
   *
   * <p>如果使用注解配制SQL，则使用@CacheNamespace来开启缓存.
   */
  @Test
  public void query() {
    // SqlSession session = sessionFactory.openSession(true);当参数设置为true时，将不再需要手动提交事务.自动提交。
    SqlSession session1 = sessionFactory.openSession();
    SqlSession session2 = sessionFactory.openSession();
    UserMsgMapper userMsgMapper1 = session1.getMapper(UserMsgMapper.class);
    UserMsgMapper userMsgMapper2 = session2.getMapper(UserMsgMapper.class);

    UserMsgPO user = new UserMsgPO();
    user.setId(11);
    List<UserMsgPO> list = userMsgMapper1.queryByConditionId(user);
    Assertions.assertEquals(1, list.size());

    // 清空一级缓存
    session1.close();
    // 当再次去获取时，不再去数据库中去获取数据。
    List<UserMsgPO> list2 = userMsgMapper2.queryByConditionId(user);

    System.out.println(list == list2);
  }
  /**
   * 二级缓存，能过参数开启后，跨SqlSession则不需要再次去数据库中查询 在开启二级缓存时，使用了xml文件配制SQL，则使用xml的方式开启
   *
   * <p>如果使用注解配制SQL，则使用@CacheNamespace来开启缓存.
   */
  @Test
  public void queryOperator() {
    // SqlSession session = sessionFactory.openSession(true);当参数设置为true时，将不再需要手动提交事务.自动提交。
    SqlSession session1 = sessionFactory.openSession();
    SqlSession session2 = sessionFactory.openSession();
    SqlSession session3 = sessionFactory.openSession();
    UserMsgMapper userMsgMapper1 = session1.getMapper(UserMsgMapper.class);
    UserMsgMapper userMsgMapper2 = session2.getMapper(UserMsgMapper.class);
    UserMsgMapper userMsgMapper3 = session3.getMapper(UserMsgMapper.class);

    UserMsgPO user = new UserMsgPO();
    user.setId(11);
    List<UserMsgPO> list = userMsgMapper1.queryByConditionId(user);
    Assertions.assertEquals(1, list.size());
    // 清空一级缓存
    session1.close();

    // 当中间发生了数据库更新操作时, 再次查询则需要去数据库进行操作
    UserMsgPO userUpdate = new UserMsgPO();
    userUpdate.setId(11);
    userUpdate.setName("name11");
    int update = userMsgMapper3.update(userUpdate);
    Assertions.assertEquals(1, update);
    // 当SQLsession发生了提交操作时，则不再走缓存获取 。
    session3.commit();

    // 当再次去获取时，不再去数据库中去获取数据。
    List<UserMsgPO> list2 = userMsgMapper2.queryByConditionId(user);

    System.out.println(list == list2);
  }
}
