package com.nullnull.learn.springboot.config;

import com.baomidou.mybatisplus.extension.plugins.PaginationInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author liujun
 * @since 2022/8/31
 */
@Configuration
public class MybatisPageConfig {


    /**
     * 配制一个分页的插件对象
     *
     * @return
     */
    @Bean
    public PaginationInterceptor paginationInnerInterceptor() {
        return new PaginationInterceptor();
    }



}
