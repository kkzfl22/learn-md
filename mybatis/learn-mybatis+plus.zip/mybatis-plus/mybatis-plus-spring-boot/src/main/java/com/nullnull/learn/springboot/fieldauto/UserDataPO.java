package com.nullnull.learn.springboot.fieldauto;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 用户对象
 *
 * @author liujun
 * @since 2022/6/29
 */
@Setter
@Getter
@ToString
@TableName("user_data")
public class UserDataPO {

    /**
     * 用户的id
     */
    private Long userId;

    /**
     * 名称的信息
     *
     * @TableField(value = "name")解决列名与字段名不一致的问题
     * @TableField(select = false) 查询不返回该字段的值
     */
    private String userName;


    /**
     * 当表中不存在的字段使用此注解映射
     */
    @TableField(fill = FieldFill.INSERT)
    private Long createTime;


    /**
     * 修改时间
     */
    @TableField(fill = FieldFill.UPDATE)
    private Long updateTime;


    /**
     * 删除的标识
     */
    @TableLogic
    private Integer deleted;

}
