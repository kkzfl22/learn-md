package com.nullnull.learn.springboot.fieldauto;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @author liujun
 * @since 2023/1/19
 */
public interface UserDataMapper extends BaseMapper<UserDataPO> {
}
