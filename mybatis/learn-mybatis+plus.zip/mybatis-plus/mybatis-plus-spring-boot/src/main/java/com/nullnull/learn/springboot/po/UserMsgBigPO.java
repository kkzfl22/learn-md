package com.nullnull.learn.springboot.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 用户对象
 *
 * @author liujun
 * @since 2022/6/29
 */
@Setter
@Getter
@ToString
@TableName("user_msg_big")
public class UserMsgBigPO {

    /**
     * 用户的id
     */
    @TableId(type = IdType.AUTO)
    @TableField("id")
    private Long id;

    /**
     * 名称的信息
     *
     * @TableField(value = "name")解决列名与字段名不一致的问题
     * @TableField(select = false) 查询不返回该字段的值
     */
    //@TableField(value = "name")
    @TableField(select = true)
    private String name;


    /**
     * 当表中不存在的字段使用此注解映射
     */
    @TableField(exist = false)
    private String address;
}
