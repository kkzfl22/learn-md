package com.nullnull.learn.springboot.basemapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * 扩充自己的BaseMapper查询方法，这样就可以拥有更加片定义的方法
 *
 * @author liujun
 * @since 2023/1/19
 */
public interface MyBaseMapper<T> extends BaseMapper<T> {


    /**
     * 查询所有数据的方法
     *
     * @return
     */
    List<T> queryAll();

}
