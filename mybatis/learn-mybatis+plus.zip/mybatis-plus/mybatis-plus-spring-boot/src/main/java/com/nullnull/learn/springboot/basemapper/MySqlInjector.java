package com.nullnull.learn.springboot.basemapper;

import com.baomidou.mybatisplus.core.injector.AbstractMethod;
import com.baomidou.mybatisplus.core.injector.DefaultSqlInjector;

import java.util.List;

/**
 * @author liujun
 * @since 2023/1/19
 */
public class MySqlInjector extends DefaultSqlInjector {

    @Override
    public List<AbstractMethod> getMethodList() {
        List<AbstractMethod> allMethodList = super.getMethodList();

        //扩充方法
        allMethodList.add(new QueryAll());

        return allMethodList;

    }
}
