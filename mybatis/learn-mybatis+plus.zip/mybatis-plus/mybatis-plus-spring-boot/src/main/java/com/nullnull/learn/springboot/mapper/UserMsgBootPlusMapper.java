package com.nullnull.learn.springboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.nullnull.learn.springboot.po.UserMsgBigPO;

import java.util.List;

/**
 * 进行用户查询的Mapper
 *
 * @author liujun
 * @since 2022/8/2
 */
public interface UserMsgBootPlusMapper extends BaseMapper<UserMsgBigPO> {


    /**
     * 查询操作
     *
     * @param data
     * @return
     */
    List<UserMsgBigPO> whereQuery(UserMsgBigPO data);
}
