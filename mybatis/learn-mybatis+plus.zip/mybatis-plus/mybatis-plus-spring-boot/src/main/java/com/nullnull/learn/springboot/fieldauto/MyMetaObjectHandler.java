package com.nullnull.learn.springboot.fieldauto;

import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.stereotype.Component;

/**
 * 设置填充的信息
 *
 * @author liujun
 * @since 2023/1/19
 */
@Component
public class MyMetaObjectHandler implements MetaObjectHandler {

    private static final String INSERT_TIME = "createTime";

    private static final String UPDATE_TIME = "updateTime";

    @Override
    public void insertFill(MetaObject metaObject) {
        Object value = getFieldValByName(INSERT_TIME, metaObject);

        //当未设置创建时间时，则进行自动填充操作
        if (null == value) {
            setFieldValByName(INSERT_TIME, System.currentTimeMillis(), metaObject);
        }

    }

    @Override
    public void updateFill(MetaObject metaObject) {
        Object value = getFieldValByName(UPDATE_TIME, metaObject);

        //当未设置创建时间时，则进行自动填充操作
        if (null == value) {
            setFieldValByName(UPDATE_TIME, System.currentTimeMillis(), metaObject);
        }
    }
}
