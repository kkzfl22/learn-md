package com.nullnull.learn.springboot.basemapper;

import com.nullnull.learn.springboot.po.UserMsgBigPO;

/**
 * @author liujun
 * @since 2023/1/19
 */
public interface UserMsgMapper extends MyBaseMapper<UserMsgBigPO> {

}
