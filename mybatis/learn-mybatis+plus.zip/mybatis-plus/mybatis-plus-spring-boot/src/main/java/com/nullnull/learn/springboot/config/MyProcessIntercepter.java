package com.nullnull.learn.springboot.config;

import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.plugin.Intercepts;
import org.apache.ibatis.plugin.Invocation;
import org.apache.ibatis.plugin.Plugin;
import org.apache.ibatis.plugin.Signature;

import java.util.Properties;

/**
 * mybatis的拦截器示例
 *
 * @author liujun
 * @since 2023/1/19
 */
@Intercepts({@Signature(type = Executor.class,
        method = "update",
        args = {MappedStatement.class, Object.class}
)})
public class MyProcessIntercepter implements Interceptor {


    @Override
    public Object intercept(Invocation invocation) throws Throwable {
        long startTime = System.currentTimeMillis();
        //拦截，执行具体的业务逻辑
        Object result = invocation.proceed();

        long endTime = System.currentTimeMillis();

        System.out.println("用时：" + (endTime - startTime) + "毫秒");
        return result;
    }

    @Override
    public Object plugin(Object target) {
        return Plugin.wrap(target, this);
    }

    @Override
    public void setProperties(Properties properties) {
        //相关的属性设置
    }
}
