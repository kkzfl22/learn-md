package com.nullnull.learn.springboot.mapper;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nullnull.learn.springboot.po.UserMsgBigPO;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;

import java.util.concurrent.ThreadLocalRandom;

/**
 * 测试，使用Junit5进行mybatis的集成
 *
 * @author liujun
 * @since 2022/8/3
 */
@SpringBootTest
@TestPropertySource("classpath:application.yml")
//@Import(value = {MybatisPageConfig.class})
@ActiveProfiles("mysql")
public class TestUserMsgMybatisPlusPageMapper {

    @Autowired
    private UserMsgBootPlusMapper userMsgBootPlusMapper;


    @Test
    public void selectPage() {

        //PageHelper.startPage(2, 3);

        UserMsgBigPO user = new UserMsgBigPO();
        user.setName("testName" + ThreadLocalRandom.current().nextInt());
        // int insertRsp = userMsgBootPlusMapper.insert(user);

        Page pageData = new Page<>(1, 1);

        QueryWrapper queryWrapper = new QueryWrapper();
        queryWrapper.gt("id", 1L);
        IPage<UserMsgBigPO> datUserPage = userMsgBootPlusMapper.selectPage(pageData, queryWrapper);
        System.out.println("总条数:" + datUserPage.getTotal());
        System.out.println("总页数:" + datUserPage.getPages());
        System.out.println("分页数据:" + datUserPage.getRecords());


        System.out.println("总条数：" + pageData.getTotal());

        Assertions.assertNotEquals(0, datUserPage);


    }


    @Test
    public void pageWrappger() {

        QueryWrapper<UserMsgBigPO> queryWrapper = new QueryWrapper<>();
        queryWrapper.gt("id", 1); // 查询年龄大于18的

        // 第一个参数：当前页   第二个参数：每页显示条数
        Page<UserMsgBigPO> page = new Page<>(2, 2);


        IPage<UserMsgBigPO> userIPage = userMsgBootPlusMapper.selectPage(page, queryWrapper);
        System.out.println("总条数" + userIPage.getTotal());
        System.out.println("总页数" + userIPage.getPages());

        System.out.println("分页数据" + userIPage.getRecords());
    }

}
