package com.nullnull.learn.springboot.plugin;

import com.baomidou.mybatisplus.core.parser.ISqlParser;
import com.baomidou.mybatisplus.extension.parsers.BlockAttackSqlParser;
import com.baomidou.mybatisplus.extension.plugins.PerformanceInterceptor;
import com.baomidou.mybatisplus.extension.plugins.SqlExplainInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

/**
 * @author liujun
 * @since 2023/1/19
 */
@Configuration
public class TestConfigLogader {

    ///**
    // * sql隔断分析器
    // *
    // * @return
    // */
    //@Bean
    //public SqlExplainInterceptor sqlExplainInterceptor() {
    //    SqlExplainInterceptor sqlExplainInterceptor = new SqlExplainInterceptor();
    //
    //    List<ISqlParser> sqlParserList = new ArrayList<>();
    //    sqlParserList.add(new BlockAttackSqlParser());
    //
    //    sqlExplainInterceptor.setSqlParserList(sqlParserList);
    //
    //    return sqlExplainInterceptor;
    //}


    /**
     * 配制SQL的性能插件
     *
     * @return
     */
    @Bean
    public PerformanceInterceptor performanceMonitorInterceptor() {
        PerformanceInterceptor performanceMonitorInterceptor = new PerformanceInterceptor();

        performanceMonitorInterceptor.setMaxTime(100);
        performanceMonitorInterceptor.setFormat(true);

        return performanceMonitorInterceptor;
    }
}
