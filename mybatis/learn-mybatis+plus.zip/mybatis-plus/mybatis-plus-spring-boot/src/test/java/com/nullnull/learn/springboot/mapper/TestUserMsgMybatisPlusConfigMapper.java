package com.nullnull.learn.springboot.mapper;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nullnull.learn.springboot.config.MybatisPageConfig;
import com.nullnull.learn.springboot.po.UserMsgBigPO;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/**
 * 测试，使用Junit5进行mybatis的集成
 *
 * @author liujun
 * @since 2022/8/3
 */
@SpringBootTest
@TestPropertySource("classpath:application.yml")
public class TestUserMsgMybatisPlusConfigMapper {

    @Autowired
    private UserMsgBootPlusMapper userMsgBootPlusMapper;


    @Test
    public void selectPage() {

        //PageHelper.startPage(2, 3);

        UserMsgBigPO user = new UserMsgBigPO();
        user.setName("testName" + ThreadLocalRandom.current().nextInt());
        int insertRsp = userMsgBootPlusMapper.insert(user);

        Page pageData = new Page<>(2, 1);

        LambdaQueryWrapper queryWrapper = Wrappers.<UserMsgBigPO>lambdaQuery().gt(UserMsgBigPO::getId, 1L);
        IPage<UserMsgBigPO> datUserPage = userMsgBootPlusMapper.selectPage(pageData, queryWrapper);
        System.out.println("总条数:" + datUserPage.getTotal());
        System.out.println("总页数:" + datUserPage.getPages());
        System.out.println("分页数据:" + datUserPage.getRecords());
        Assertions.assertNotEquals(0, datUserPage);


    }

}
