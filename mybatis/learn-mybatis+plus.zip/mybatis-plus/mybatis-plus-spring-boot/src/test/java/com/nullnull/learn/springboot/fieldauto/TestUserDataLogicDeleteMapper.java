package com.nullnull.learn.springboot.fieldauto;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import java.util.List;

/**
 * 用户对象的逻辑删除操作
 *
 * @author liujun
 * @since 2023/1/19
 */
@SpringBootTest
@TestPropertySource("classpath:application.yml")
public class TestUserDataLogicDeleteMapper {


    @Autowired
    private UserDataMapper userDataMapper;


    @Test
    public void delete() {
        LambdaQueryWrapper delete = Wrappers.<UserDataPO>lambdaQuery().eq(UserDataPO::getUserId, 1L);
        int insertData = userDataMapper.delete(delete);
        Assertions.assertEquals(1, insertData);
    }


    @Test
    public void testQuery() {
        List<UserDataPO> userList = userDataMapper.selectList(Wrappers.emptyWrapper());
        System.out.println(userList);
        Assertions.assertNotNull(userList);
    }

}
