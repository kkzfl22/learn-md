package com.nullnull.learn.springboot.mapper;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.nullnull.learn.springboot.po.UserMsgBigPO;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import java.util.List;

/**
 * 测试，使用Junit5进行mybatis的集成
 *
 * @author liujun
 * @since 2022/8/3
 */
@SpringBootTest
@TestPropertySource("classpath:application.yml")
public class TestUserMsgMybatisMapper {

    @Autowired
    private SqlSessionFactory sqlSessionFactory;


    @Test
    public void selectAllList() {
        SqlSession sqlSession = sqlSessionFactory.openSession(true);

        UserMsgBootPlusMapper msgMapper = sqlSession.getMapper(UserMsgBootPlusMapper.class);

        List<UserMsgBigPO> dataList = msgMapper.selectList(Wrappers.emptyWrapper());
        System.out.println(dataList);
        Assertions.assertNotNull(dataList);
    }


    @Test
    public void crud() {
        SqlSession sqlSession = sqlSessionFactory.openSession(true);

        UserMsgBootPlusMapper msgMapper = sqlSession.getMapper(UserMsgBootPlusMapper.class);

        UserMsgBigPO user = new UserMsgBigPO();
        user.setName("testName100");
        int insertRsp = msgMapper.insert(user);
        Assertions.assertEquals(1, insertRsp);

        System.out.println("回填的id" + user.getId());

        //修改操作
        UserMsgBigPO update = new UserMsgBigPO();
        update.setId(1L);
        update.setName("name1L");
        int updateRsp = msgMapper.updateById(update);
        Assertions.assertEquals(1, updateRsp);

        //使用对象做值，查询对象做条件的修改
        UserMsgBigPO updateQuery = new UserMsgBigPO();
        updateQuery.setName("name2L");
        QueryWrapper<UserMsgBigPO> userWrapper = new QueryWrapper<>();
        userWrapper.eq("id", 1L);
        int updateRsp2 = msgMapper.update(updateQuery, userWrapper);
        Assertions.assertEquals(1, updateRsp2);


        //使用对象做值，查询对象做条件的修改2,使用LambdaQueryWrapper对象
        UserMsgBigPO updateQuery2 = new UserMsgBigPO();
        updateQuery2.setName("name2L");
        LambdaQueryWrapper<UserMsgBigPO> userWrapper2 = new LambdaQueryWrapper<>();
        userWrapper2.eq(UserMsgBigPO::getId, 1L);
        int updateRsp3 = msgMapper.update(updateQuery2, userWrapper2);
        Assertions.assertEquals(1, updateRsp3);


        //使用UpdateWrapper对象
        UpdateWrapper<UserMsgBigPO> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id", 1).set("name", "name11");
        int updateWrapperRsp = msgMapper.update(null, updateWrapper);
        Assertions.assertEquals(1, updateWrapperRsp);

        //使用LambdaUpdateWrapper对象
        LambdaUpdateWrapper<UserMsgBigPO> updateLambdaWrapper = new LambdaUpdateWrapper<>();
        updateLambdaWrapper.eq(UserMsgBigPO::getId, 1).set(UserMsgBigPO::getName, "name11");
        int updateLambdaWrapperRsp = msgMapper.update(null, updateLambdaWrapper);
        Assertions.assertEquals(1, updateLambdaWrapperRsp);
    }


}
