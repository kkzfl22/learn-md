package com.nullnull.learn.springboot.fieldauto;

import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

/**
 * @author liujun
 * @since 2023/1/19
 */
@SpringBootTest
@TestPropertySource("classpath:application.yml")
public class TestUserDataMapper {


    @Autowired
    private UserDataMapper userDataMapper;


    @Test
    public void insert() {
        UserDataPO userInfo = new UserDataPO();
        userInfo.setUserId(1L);
        userInfo.setUserName("name1");

        int insertData = userDataMapper.insert(userInfo);
        Assertions.assertEquals(1, insertData);
    }

    @Test
    public void update() {
        UserDataPO userInfo = new UserDataPO();
        userInfo.setUserId(2L);
        userInfo.setUserName("name2");

        int insertData = userDataMapper.insert(userInfo);
        Assertions.assertEquals(1, insertData);

        userInfo.setUserName("name22");

        LambdaUpdateWrapper updateWrapper = Wrappers.<UserDataPO>lambdaUpdate()
                //设置更新的列
                .set(UserDataPO::getUserName, userInfo.getUserName())
                //设置条件
                .eq(UserDataPO::getUserId, userInfo.getUserId());


        int update = userDataMapper.update(userInfo, updateWrapper);
        Assertions.assertEquals(1, update);
    }

}
