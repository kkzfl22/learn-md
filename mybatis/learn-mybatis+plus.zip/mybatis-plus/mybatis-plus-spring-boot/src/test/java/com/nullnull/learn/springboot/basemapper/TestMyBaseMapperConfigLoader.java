package com.nullnull.learn.springboot.basemapper;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author liujun
 * @since 2023/1/19
 */
@Configuration
public class TestMyBaseMapperConfigLoader {


    @Bean
    public MySqlInjector sqlInjector() {
        return new MySqlInjector();
    }

}
