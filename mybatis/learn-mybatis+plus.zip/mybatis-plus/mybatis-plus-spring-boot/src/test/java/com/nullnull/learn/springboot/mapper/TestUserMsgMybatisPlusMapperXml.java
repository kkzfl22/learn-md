package com.nullnull.learn.springboot.mapper;

import com.nullnull.learn.springboot.po.UserMsgBigPO;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import java.util.List;

/**
 * 测试，使用Junit5进行mybatis的集成
 *
 * @author liujun
 * @since 2022/8/3
 */
@SpringBootTest
@TestPropertySource("classpath:application.yml")
public class TestUserMsgMybatisPlusMapperXml {

    @Autowired
    private UserMsgBootPlusMapper userMsgBootPlusMapper;


    @Test
    public void whereQuery() {

        UserMsgBigPO user = new UserMsgBigPO();
        user.setId(1L);
        List<UserMsgBigPO> datUserPage = userMsgBootPlusMapper.whereQuery(user);

        Assertions.assertNotEquals(0, datUserPage);


    }

}
