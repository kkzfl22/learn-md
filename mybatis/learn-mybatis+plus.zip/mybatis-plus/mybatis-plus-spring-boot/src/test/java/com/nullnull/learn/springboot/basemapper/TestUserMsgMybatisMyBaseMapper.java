package com.nullnull.learn.springboot.basemapper;

import com.nullnull.learn.springboot.po.UserMsgBigPO;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;

import java.util.List;

/**
 * 测试，使用Junit5进行mybatis的集成
 * <p>
 * SQL集成插件，对于sqllite的集成还存在问题
 *
 * @author liujun
 * @since 2022/8/3
 */
@SpringBootTest
@Import(TestMyBaseMapperConfigLoader.class)
@TestPropertySource("classpath:application.yml")
public class TestUserMsgMybatisMyBaseMapper {

    /**
     * 用户注入的类
     */
    @Autowired
    private UserMsgMapper userMsgMapper;


    @Test
    public void queryAll() {
        List<UserMsgBigPO> dataList = userMsgMapper.queryAll();
        System.out.println(dataList);
        Assertions.assertNotNull(dataList);
    }
}
