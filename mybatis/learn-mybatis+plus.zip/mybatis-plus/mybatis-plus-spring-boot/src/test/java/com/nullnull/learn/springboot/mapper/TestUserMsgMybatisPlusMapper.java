package com.nullnull.learn.springboot.mapper;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nullnull.learn.springboot.config.MybatisPageConfig;
import com.nullnull.learn.springboot.po.UserMsgBigPO;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/**
 * 测试，使用Junit5进行mybatis的集成
 *
 * @author liujun
 * @since 2022/8/3
 */
@SpringBootTest
@TestPropertySource("classpath:application.yml")
@Import(value = {MybatisPageConfig.class})
public class TestUserMsgMybatisPlusMapper {

    @Autowired
    private UserMsgBootPlusMapper userMsgBootPlusMapper;


    @Test
    public void delete() {
        UserMsgBigPO user = new UserMsgBigPO();
        user.setName("testName1020");
        int insertRsp = userMsgBootPlusMapper.insert(user);
        Assertions.assertEquals(1, insertRsp);


        int deleteRsp = userMsgBootPlusMapper.deleteById(user.getId());
        Assertions.assertEquals(1, deleteRsp);
    }


    @Test
    public void deleteByMap() {
        UserMsgBigPO user = new UserMsgBigPO();
        user.setName("testName1020");
        int insertRsp = userMsgBootPlusMapper.insert(user);
        Assertions.assertEquals(1, insertRsp);


        Map<String, Object> deleteMap = new HashMap<>();
        deleteMap.put("name", user.getName());
        int deleteRsp = userMsgBootPlusMapper.deleteByMap(deleteMap);
        Assertions.assertEquals(1, deleteRsp);
    }


    @Test
    public void deleteByWrapper() {
        UserMsgBigPO user = new UserMsgBigPO();
        user.setName("testName1020");
        int insertRsp = userMsgBootPlusMapper.insert(user);
        Assertions.assertEquals(1, insertRsp);


        QueryWrapper<UserMsgBigPO> deleteQuery = new QueryWrapper<>();
        deleteQuery.eq("name", user.getName());

        int deleteRsp = userMsgBootPlusMapper.delete(deleteQuery);
        Assertions.assertEquals(1, deleteRsp);
    }


    @Test
    public void deleteByLambdaWrapper() {
        UserMsgBigPO user = new UserMsgBigPO();
        user.setName("testName1020");
        int insertRsp = userMsgBootPlusMapper.insert(user);
        Assertions.assertEquals(1, insertRsp);


        LambdaQueryWrapper<UserMsgBigPO> deleteQuery = new LambdaQueryWrapper<>();
        deleteQuery.eq(UserMsgBigPO::getName, user.getName());

        int deleteRsp = userMsgBootPlusMapper.delete(deleteQuery);
        Assertions.assertEquals(1, deleteRsp);
    }


    @Test
    public void deleteByQueryWrapper() {
        UserMsgBigPO user = new UserMsgBigPO();
        user.setName("testName1020");
        int insertRsp = userMsgBootPlusMapper.insert(user);
        Assertions.assertEquals(1, insertRsp);


        QueryWrapper<UserMsgBigPO> deleteQuery = new QueryWrapper<>(user);
        int deleteRsp = userMsgBootPlusMapper.delete(deleteQuery);
        Assertions.assertEquals(1, deleteRsp);
    }

    @Test
    public void deleteBatch() {
        UserMsgBigPO user = new UserMsgBigPO();
        user.setName("testName1020");
        int insertRsp = userMsgBootPlusMapper.insert(user);
        Assertions.assertEquals(1, insertRsp);


        int deleteRsp = userMsgBootPlusMapper.deleteBatchIds(Arrays.asList(user.getId()));
        Assertions.assertEquals(1, deleteRsp);
    }


    @Test
    public void selectById() {
        UserMsgBigPO user = new UserMsgBigPO();
        user.setName("testName1020");
        int insertRsp = userMsgBootPlusMapper.insert(user);
        Assertions.assertEquals(1, insertRsp);


        UserMsgBigPO datUser = userMsgBootPlusMapper.selectById(user.getId());
        Assertions.assertNotNull(datUser);
    }

    @Test
    public void selectBatchIds() {
        UserMsgBigPO user = new UserMsgBigPO();
        user.setName("testName1020");
        int insertRsp = userMsgBootPlusMapper.insert(user);
        Assertions.assertEquals(1, insertRsp);


        List<UserMsgBigPO> datUser = userMsgBootPlusMapper.selectBatchIds(Arrays.asList(user.getId(), 1L));
        Assertions.assertNotNull(datUser);
        Assertions.assertEquals(2, datUser.size());
    }

    @Test
    public void selectOne() {
        UserMsgBigPO user = new UserMsgBigPO();
        user.setName("testName1020");
        int insertRsp = userMsgBootPlusMapper.insert(user);
        Assertions.assertEquals(1, insertRsp);


        LambdaQueryWrapper queryWrapper = Wrappers.<UserMsgBigPO>lambdaQuery().eq(UserMsgBigPO::getId, user.getId());
        UserMsgBigPO datUser = userMsgBootPlusMapper.selectOne(queryWrapper);
        Assertions.assertNotNull(datUser);
    }


    @Test
    public void selectCount() {
        UserMsgBigPO user = new UserMsgBigPO();
        user.setName("testName1020");
        int insertRsp = userMsgBootPlusMapper.insert(user);
        Assertions.assertEquals(1, insertRsp);
        LambdaQueryWrapper queryWrapper = Wrappers.<UserMsgBigPO>lambdaQuery().eq(UserMsgBigPO::getId, user.getId());
        Integer datUser = userMsgBootPlusMapper.selectCount(queryWrapper);
        Assertions.assertNotEquals(0, datUser);
    }


    @Test
    public void selectPage() {

        //PageHelper.startPage(2, 3);

        UserMsgBigPO user = new UserMsgBigPO();
        user.setName("testName" + ThreadLocalRandom.current().nextInt());
        int insertRsp = userMsgBootPlusMapper.insert(user);

        Page pageData = new Page<>(1, 1);

        LambdaQueryWrapper queryWrapper = Wrappers.<UserMsgBigPO>lambdaQuery().gt(UserMsgBigPO::getId, 1L);
        IPage<UserMsgBigPO> datUserPage = userMsgBootPlusMapper.selectPage(pageData, queryWrapper);
        System.out.println("总条数:" + datUserPage.getTotal());
        System.out.println("总页数:" + datUserPage.getPages());
        System.out.println("分页数据:" + datUserPage.getRecords());
        Assertions.assertNotEquals(0, datUserPage);
    }


    @Test
    public void selectAllEq() {
        UserMsgBigPO user = new UserMsgBigPO();
        user.setName("testName1020");
        int insertRsp = userMsgBootPlusMapper.insert(user);
        Assertions.assertEquals(1, insertRsp);

        Map<String, String> allEqMap = new HashMap<>();
        allEqMap.put("name", user.getName());

        QueryWrapper wrapper = new QueryWrapper();
        wrapper.allEq(allEqMap);


        List<UserMsgBigPO> datUser = userMsgBootPlusMapper.selectList(wrapper);
        Assertions.assertNotNull(datUser);


        QueryWrapper wrapper2 = new QueryWrapper();
        wrapper2.allEq((K, V) -> !K.equals("name"), allEqMap, true);

        List<UserMsgBigPO> datUser2 = userMsgBootPlusMapper.selectList(wrapper2);
        Assertions.assertNotNull(datUser2);
    }


    @Test
    public void like() {
        QueryWrapper wrapper = new QueryWrapper();
        wrapper.like("name", "Name");

        List<UserMsgBigPO> datUser = userMsgBootPlusMapper.selectList(wrapper);
        Assertions.assertNotNull(datUser);
    }

    @Test
    public void select() {
        QueryWrapper wrapper = new QueryWrapper();
        wrapper.like("name", "Name");
        wrapper.select("name");

        List<UserMsgBigPO> datUser = userMsgBootPlusMapper.selectList(wrapper);
        Assertions.assertNotNull(datUser);
    }


}
