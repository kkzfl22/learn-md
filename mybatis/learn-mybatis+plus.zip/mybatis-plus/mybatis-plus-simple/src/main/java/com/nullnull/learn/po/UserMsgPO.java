package com.nullnull.learn.po;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * 用户对象
 *
 * @author liujun
 * @since 2022/6/29
 */
@Setter
@Getter
@ToString
@TableName("user_msg")
public class UserMsgPO {

    /**
     * 用户的id
     */
    private Integer id;

    /**
     * 名称的信息
     */
    private String name;

}
