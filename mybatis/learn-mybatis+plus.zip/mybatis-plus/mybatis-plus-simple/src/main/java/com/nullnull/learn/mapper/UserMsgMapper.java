package com.nullnull.learn.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.nullnull.learn.po.UserMsgPO;

import java.util.List;

/**
 * 进行用户查询的Mapper
 *
 * @author liujun
 * @since 2022/8/2
 */
public interface UserMsgMapper extends BaseMapper<UserMsgPO> {


    /**
     * 查询所有的用户信息
     *
     * @return
     */
    List<UserMsgPO> queryAll();

}
