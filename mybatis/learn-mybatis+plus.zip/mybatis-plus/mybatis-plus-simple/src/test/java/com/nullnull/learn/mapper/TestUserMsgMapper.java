package com.nullnull.learn.mapper;

import com.baomidou.mybatisplus.core.MybatisSqlSessionFactoryBuilder;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.nullnull.learn.po.UserMsgPO;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import java.io.InputStream;
import java.util.List;

/**
 * 测试普通加载
 *
 * @author liujun
 * @since 2022/8/2
 */
public class TestUserMsgMapper {


    @Test
    public void success() {
        // 1,加载Mybatis的核心配制文件为流
        InputStream mapConfigStream =
                this.getClass().getClassLoader().getResourceAsStream("sqlMapConfig.xml");

        //执行资源的加载操作
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(mapConfigStream);

        SqlSession session = sqlSessionFactory.openSession();

        UserMsgMapper userMsgMapper = session.getMapper(UserMsgMapper.class);
        List<UserMsgPO> userList = userMsgMapper.queryAll();
        System.out.println(userList);

        Assertions.assertNotNull(userList);

    }


    @Test
    public void successMp() {
        // 1,加载Mybatis的核心配制文件为流
        InputStream mapConfigStream =
                this.getClass().getClassLoader().getResourceAsStream("sqlMapConfig.xml");

        //执行资源的加载操作
        SqlSessionFactory sqlSessionFactory = new MybatisSqlSessionFactoryBuilder().build(mapConfigStream);

        SqlSession session = sqlSessionFactory.openSession();

        UserMsgMapper userMsgMapper = session.getMapper(UserMsgMapper.class);
        List<UserMsgPO> userList = userMsgMapper.queryAll();
        System.out.println(userList);

        Assertions.assertNotNull(userList);


        List<UserMsgPO> dataList = userMsgMapper.selectList(Wrappers.emptyWrapper());
        Assertions.assertNotNull(dataList);
        System.out.println(dataList);

    }

}
