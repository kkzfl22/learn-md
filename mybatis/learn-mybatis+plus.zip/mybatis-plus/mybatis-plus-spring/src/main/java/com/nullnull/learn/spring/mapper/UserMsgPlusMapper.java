package com.nullnull.learn.spring.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.nullnull.learn.spring.po.UserMsgPO;

/**
 * 进行用户查询的Mapper
 *
 * @author liujun
 * @since 2022/8/2
 */
public interface UserMsgPlusMapper extends BaseMapper<UserMsgPO> {


}
