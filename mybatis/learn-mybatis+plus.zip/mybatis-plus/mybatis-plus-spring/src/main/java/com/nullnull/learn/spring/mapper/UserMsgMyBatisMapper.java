package com.nullnull.learn.spring.mapper;

import com.nullnull.learn.spring.po.UserMsgPO;

import java.util.List;

/**
 * 进行用户查询的Mapper
 *
 * @author liujun
 * @since 2022/8/2
 */
public interface UserMsgMyBatisMapper {


    /**
     * 查询所以数据集
     *
     * @return
     */
    List<UserMsgPO> selectAllList();

}
