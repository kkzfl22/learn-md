package com.nullnull.learn.spring.mapper;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.nullnull.learn.spring.po.UserMsgPO;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;

/**
 * 测试，使用Junit5进行mybatis-plus的集成
 *
 * @author liujun
 * @since 2022/8/3
 */
//@RunWith(SpringJUnit4ClassRunner.class)
@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations = "classpath:applicationContext-plus.xml")
public class TestUserMsgMybatisPlusMapper {

    @Autowired
    private UserMsgPlusMapper msgMapper;


    @Test
    public void query() {
        List<UserMsgPO> dataList = msgMapper.selectList(Wrappers.emptyWrapper());
        System.out.println(dataList);
        Assertions.assertNotNull(dataList);
    }
}
