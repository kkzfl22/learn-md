package com.nullnull.learn.spring.mapper;

import com.nullnull.learn.spring.po.UserMsgPO;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;

/**
 * 测试，使用Junit5进行mybatis的集成
 *
 * @author liujun
 * @since 2022/8/3
 */
@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations = "classpath:applicationContext-mybatis.xml")
public class TestUserMsgMybatisMapper {

    @Autowired
    private SqlSessionFactory sqlSessionFactory;


    @Test
    public void selectAllList() {
        SqlSession sqlSession = sqlSessionFactory.openSession(true);

        UserMsgMyBatisMapper msgMapper = sqlSession.getMapper(UserMsgMyBatisMapper.class);

        List<UserMsgPO> dataList = msgMapper.selectAllList();
        System.out.println(dataList);
        Assertions.assertNotNull(dataList);
    }
}
