package com.nullnull.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.nullnull.domain.User;

public interface UserMapper extends BaseMapper<User> {
}