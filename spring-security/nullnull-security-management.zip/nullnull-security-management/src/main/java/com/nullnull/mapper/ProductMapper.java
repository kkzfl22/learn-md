package com.nullnull.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.nullnull.domain.Product;

public interface ProductMapper extends BaseMapper<Product> {
}
