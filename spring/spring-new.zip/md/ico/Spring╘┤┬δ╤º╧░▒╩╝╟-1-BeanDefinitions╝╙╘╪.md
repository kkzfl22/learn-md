# Spring源码学习笔记-BeanDefinitions加载



Spring的Bean对象是如何被加载的到内存的，中间会经过哪些步骤呢？这个问题在我读Spring的源码之前，一直都是一知半解的，直接我开始翻看Spring的源码，才开始将这些疑问一点一点的了解。现在就从Spring的源码的角度看看这个Bean是如何被加载到Spring的容器中的。这其实是一个很复杂很漫长的一个过程，还是一点一点的记录下来吧，这次就从Spring的定义被加载开始。

## 测试代码说明

Spring 版本：5.1.21.BUILD-SNAPSHOT

测试类：

```
public class TestSpringBeanDefinitions {
  @Test
  public void testBeanRun() throws Exception {
    // ApplicationContext是一个容器的高级接口。
    // BeanFactory是一个顶级容器或者根容器。规范和定义了容器的基础行为。IOC的基础行为，就是在这个接口中定义的。
    // IOC是创建和管理spring的生命周期的。
    ApplicationContext context =
        new ClassPathXmlApplicationContext(
            "classpath:/beandefinitions/applicationContext-beandefinitions.xml");
    SpringBeanDefinition data = (SpringBeanDefinition) context.getBean("beanDefinition");
    System.out.println("容器中的对象:" + data);
    data.run();
  }
}
```

applicationContext-beandefinitions.xml中对于Bean的定义。

```
<!--SpringBean对象的加载-->
	<bean id="beanDefinition" class="com.spring.feifei.data.beandefinitions.SpringBeanDefinition">
	</bean>
```

SpringBeanDefinition.java 

```java
public class SpringBeanDefinition {

  public SpringBeanDefinition() {
    System.out.println("对象实体化，初始化构建函数加载");
  }

  public void run() {
    System.out.println("Spring的实例对象运行");
  }
}
```



## 源码分析

在跟踪源分之前，还是先来看下下ApplicationContext的一个继承结构

![image-20211118093121907](D:\doc\博客\新技术学习\spring码源\application的继承结构.png)

下面就开始源码的分析

1.  **通过调试跟踪就来到了ClassPathXmlApplicationContext的源码，得到如下的代码，这就是最外层的入口位置。**

```
public ClassPathXmlApplicationContext(String configLocation) throws BeansException {
		this(new String[]{configLocation}, true, null);
	}
```



2. **通过再对this构造函数的进一步引用，就可以看到如下代码：**

```
public ClassPathXmlApplicationContext(
			String[] configLocations, boolean refresh, @Nullable ApplicationContext parent)
			throws BeansException {
		//调用父类的构建方法
		super(parent);
		//执行本地文件的相关设置操作
		setConfigLocations(configLocations);
		//标识是否进行本地的加载
		if (refresh) {
			//进行Srping容器的加载操作
			refresh();
		}
	}
```

重点观注于refresh。

(注：在读取源码时，要学会过滤过一些细节的代码，只关注主线。Spring的代码非常的复杂。细节分支特别特别的多。在刚开始读的时候，就关注那些主要的流程。以主线为引导进行源码的阅读。过分的关注细节，很容易迷失在细节中，我就曾深馅在细节中，总想搞清楚每个细节。这样源码读不了的。正确的姿势是以一个上帝的视角来看这些代码。然后按流程逐步深入。这样代码读取起来会容易很多。）

3. **继续调试跟踪，就来到了AbstractApplicationContext的refresh方法**

```
public void refresh() throws BeansException, IllegalStateException {
    // 加锁，在启动与关闭时，只能存在一个的调用。不允许即在启动，而另外的在调用关闭方法
    synchronized (this.startupShutdownMonitor) {
      // Prepare this context for refreshing.
      // 预处理操作 做资源的检查以及环境的检查工作
      // 并且还验证环境里一些必须存在的属性等
      prepareRefresh();

      // 解析Bean的配制文件，拿到bean工厂
      // Tell the subclass to refresh the internal bean factory.
      ConfigurableListableBeanFactory beanFactory = obtainFreshBeanFactory();

      // 预处理bean工厂,对工厂bean做预处理操作
      // Prepare the bean factory for use in this context.
      prepareBeanFactory(beanFactory);

      try {
        // Allows post-processing of the bean factory in context subclasses.
        postProcessBeanFactory(beanFactory);

        // Invoke factory processors registered as beans in the context.
        // bean工厂的处理器创建
        invokeBeanFactoryPostProcessors(beanFactory);

        // Register bean processors that intercept bean creation.
        // 将bean的处理器对象进行实例化,即实现了BeanPostProcessor的对象进行实例化
        registerBeanPostProcessors(beanFactory);

        // Initialize message source for this context.
        // 国际化资源处理
        initMessageSource();

        // Initialize event multicaster for this context.
        initApplicationEventMulticaster();

        // Initialize other special beans in specific context subclasses.
        onRefresh();

        // Check for listener beans and register them.
        registerListeners();

        // Instantiate all remaining (non-lazy-init) singletons.
        // 初始化所有非懒加载的Bean
        // 初始化创建非懒加载方式的单例bean的实例。
        // 属性填充
        // 初始化方法调用 如afterPropertiesSet方法，init-method方法)
        // 调用BeanPostProcessor对实例bean进行后置处理。
        finishBeanFactoryInitialization(beanFactory);

        // Last step: publish corresponding event.
        finishRefresh();
      } catch (BeansException ex) {
        if (logger.isWarnEnabled()) {
          logger.warn(
              "Exception encountered during context initialization - "
                  + "cancelling refresh attempt: "
                  + ex);
        }

        // Destroy already created singletons to avoid dangling resources.
        destroyBeans();

        // Reset 'active' flag.
        cancelRefresh(ex);

        // Propagate exception to caller.
        throw ex;
      } finally {
        // Reset common introspection caches in Spring's core, since we
        // might not ever need metadata for singleton beans anymore...
        resetCommonCaches();
      }
    }
  }
```

通过观察refresh可看到这里有很多的需要执行，首先在任务开始时就使用一把同步锁，此锁的目的在于让启动与停止不能同时进行，哪个拿到了同步锁，就执行相应的逻辑。

4. **跟踪obtainFreshBeanFactory方法。**

```
protected ConfigurableListableBeanFactory obtainFreshBeanFactory() {
    // 加载bean工厂
    refreshBeanFactory();
    // 获取bean工厂
    return getBeanFactory();
  }
```

5. **继续跟踪就来到了AbstractRefreshableApplicationContex的refreshBeanFactory方法。**

```
protected final void refreshBeanFactory() throws BeansException {
		//当bean工厂已经存在时，先将之前的bean进行销毁操作
		if (hasBeanFactory()) {
			destroyBeans();
			closeBeanFactory();
		}
		try {
			//创建一个集合形式的bean工厂对象
			DefaultListableBeanFactory beanFactory = createBeanFactory();
			//设置id
			beanFactory.setSerializationId(getId());
			//自定义bean工厂参数设置。两个参数，一个是否覆盖以及开启循环依赖
			customizeBeanFactory(beanFactory);
			//进行bean工厂对象的加载操作
			loadBeanDefinitions(beanFactory);
			this.beanFactory = beanFactory;
		} catch (IOException ex) {
			throw new ApplicationContextException("I/O error parsing bean definition source for " + getDisplayName(), ex);
		}
	}
```

6. **接下来就来到AbstractXmlApplicationContext的loadBeanDefinitions方法**

```
protected void loadBeanDefinitions(DefaultListableBeanFactory beanFactory) throws BeansException, IOException {
		// Create a new XmlBeanDefinitionReader for the given BeanFactory.
		//创建一个xml文件形式的读取器对象
		XmlBeanDefinitionReader beanDefinitionReader = new XmlBeanDefinitionReader(beanFactory);

		// Configure the bean definition reader with this context's
		// resource loading environment.
		beanDefinitionReader.setEnvironment(this.getEnvironment());
		beanDefinitionReader.setResourceLoader(this);
		beanDefinitionReader.setEntityResolver(new ResourceEntityResolver(this));

		// Allow a subclass to provide custom initialization of the reader,
		// then proceed with actually loading the bean definitions.
		initBeanDefinitionReader(beanDefinitionReader);
		//执行加载操作
		loadBeanDefinitions(beanDefinitionReader);
	}
```

此处创建了一个XmlBeanDefinitionReader,用来进行配制文件读取操作,再设置其他所需要加载器及环境信息。

7. **接下来就来到了同类的loadBeanDefinitions方法**

```
protected void loadBeanDefinitions(XmlBeanDefinitionReader reader) throws BeansException, IOException {
		//将reader对象转换为resource对象
		Resource[] configResources = getConfigResources();
		if (configResources != null) {
			reader.loadBeanDefinitions(configResources);
		}
		//代码中参数传递为字符指定的文件。所以按字符串的配制信息进行加载
		//经支持多文件，一般只传递一个文件
		String[] configLocations = getConfigLocations();
		if (configLocations != null) {
			reader.loadBeanDefinitions(configLocations);
		}
	}
```

此处Resource为null，将按照传递的文件也就是applicationContext-beandefinitions.xml文件进行加载操作。

8. **再跟踪就来到了AbstractBeanDefinitionReader的loadBeanDefinitions方法。**

```
public int loadBeanDefinitions(String... locations) throws BeanDefinitionStoreException {
		Assert.notNull(locations, "Location array must not be null");
		int count = 0;
		for (String location : locations) {
			//加载单个配制文件
			count += loadBeanDefinitions(location);
		}
		return count;
	}
```

此处将按刚传递的配制文件，进行遍历单文件进行加载操作。

9. **跟踪loadBeanDefinitions方法就会此为同样还是AbstractBeanDefinitionReader类还是调用loadBeanDefinitions仅参数不同。**

```
public int loadBeanDefinitions(String location) throws BeanDefinitionStoreException {
		return loadBeanDefinitions(location, null);
	}
```

10. **接下来就是调用同类的加载资源的方法**

```
public int loadBeanDefinitions(String location, @Nullable Set<Resource> actualResources) throws BeanDefinitionStoreException {
		ResourceLoader resourceLoader = getResourceLoader();
		if (resourceLoader == null) {
			throw new BeanDefinitionStoreException(
					"Cannot load bean definitions from location [" + location + "]: no ResourceLoader available");
		}

		if (resourceLoader instanceof ResourcePatternResolver) {
			// Resource pattern matching available.
			try {
				Resource[] resources = ((ResourcePatternResolver) resourceLoader).getResources(location);
				//加载bean的定义
				int count = loadBeanDefinitions(resources);
				if (actualResources != null) {
					Collections.addAll(actualResources, resources);
				}
				if (logger.isTraceEnabled()) {
					logger.trace("Loaded " + count + " bean definitions from location pattern [" + location + "]");
				}
				return count;
			} catch (IOException ex) {
				throw new BeanDefinitionStoreException(
						"Could not resolve bean definition resource pattern [" + location + "]", ex);
			}
		} else {
			// Can only load single resources by absolute URL.
			Resource resource = resourceLoader.getResource(location);
			int count = loadBeanDefinitions(resource);
			if (actualResources != null) {
				actualResources.add(resource);
			}
			if (logger.isTraceEnabled()) {
				logger.trace("Loaded " + count + " bean definitions from location [" + location + "]");
			}
			return count;
		}
	}
```

11. **调用loadBeanDefinitions方法。此处接收多个资源对象**

```
public int loadBeanDefinitions(Resource... resources) throws BeanDefinitionStoreException {
		Assert.notNull(resources, "Resource array must not be null");
		int count = 0;
		for (Resource resource : resources) {
			count += loadBeanDefinitions(resource);
		}
		return count;
	}
```

12. **再就是调用：loadBeanDefinitions此处只接受一个资源对象**

```
public int loadBeanDefinitions(Resource resource) throws BeanDefinitionStoreException {
   return loadBeanDefinitions(new EncodedResource(resource));
}
```

13. **接下来就来到了真正加载的地方：**

```
public int loadBeanDefinitions(EncodedResource encodedResource) throws BeanDefinitionStoreException {
   Assert.notNull(encodedResource, "EncodedResource must not be null");
   if (logger.isTraceEnabled()) {
      logger.trace("Loading XML bean definitions from " + encodedResource);
   }

   Set<EncodedResource> currentResources = this.resourcesCurrentlyBeingLoaded.get();
   if (currentResources == null) {
      currentResources = new HashSet<>(4);
      this.resourcesCurrentlyBeingLoaded.set(currentResources);
   }
   if (!currentResources.add(encodedResource)) {
      throw new BeanDefinitionStoreException(
            "Detected cyclic loading of " + encodedResource + " - check your import definitions!");
   }
   try {
      //从资源中获取了输入流
      InputStream inputStream = encodedResource.getResource().getInputStream();
      try {
         //转换为source对象
         InputSource inputSource = new InputSource(inputStream);
         if (encodedResource.getEncoding() != null) {
            inputSource.setEncoding(encodedResource.getEncoding());
         }
         //执行真正的加载操作
         return doLoadBeanDefinitions(inputSource, encodedResource.getResource());
      } finally {
         inputStream.close();
      }
   } catch (IOException ex) {
      throw new BeanDefinitionStoreException(
            "IOException parsing XML document from " + encodedResource.getResource(), ex);
   } finally {
      currentResources.remove(encodedResource);
      if (currentResources.isEmpty()) {
         this.resourcesCurrentlyBeingLoaded.remove();
      }
   }
}
```

将读取到的资源文件转换为文件流，并进行文件的读取。



14. **继续调试就来到了XmlBeanDefinitionReader的doLoadBeanDefinitions。**

```
protected int doLoadBeanDefinitions(InputSource inputSource, Resource resource)
			throws BeanDefinitionStoreException {

		try {
			//解析xml文件
			Document doc = doLoadDocument(inputSource, resource);
			//加载bean的定义操作
			int count = registerBeanDefinitions(doc, resource);
			if (logger.isDebugEnabled()) {
				logger.debug("Loaded " + count + " bean definitions from " + resource);
			}
			return count;
		} catch (BeanDefinitionStoreException ex) {
			throw ex;
		} catch (SAXParseException ex) {
			throw new XmlBeanDefinitionStoreException(resource.getDescription(),
					"Line " + ex.getLineNumber() + " in XML document from " + resource + " is invalid", ex);
		} catch (SAXException ex) {
			throw new XmlBeanDefinitionStoreException(resource.getDescription(),
					"XML document from " + resource + " is invalid", ex);
		} catch (ParserConfigurationException ex) {
			throw new BeanDefinitionStoreException(resource.getDescription(),
					"Parser configuration exception parsing XML from " + resource, ex);
		} catch (IOException ex) {
			throw new BeanDefinitionStoreException(resource.getDescription(),
					"IOException parsing XML document from " + resource, ex);
		} catch (Throwable ex) {
			throw new BeanDefinitionStoreException(resource.getDescription(),
					"Unexpected exception parsing XML document from " + resource, ex);
		}
	}
```

15. **跟踪获取解析xml的对象就来到了XmlBeanDefinitionReader的doLoadDocument方法。**

```
protected Document doLoadDocument(InputSource inputSource, Resource resource) throws Exception {
		return this.documentLoader.loadDocument(inputSource, getEntityResolver(), this.errorHandler,
				getValidationModeForResource(resource), isNamespaceAware());
	}
```



16. **继续跟踪就来到了最终的加载方法**

```
public Document loadDocument(InputSource inputSource, EntityResolver entityResolver,
			ErrorHandler errorHandler, int validationMode, boolean namespaceAware) throws Exception {

		DocumentBuilderFactory factory = createDocumentBuilderFactory(validationMode, namespaceAware);
		if (logger.isTraceEnabled()) {
			logger.trace("Using JAXP provider [" + factory.getClass().getName() + "]");
		}
		DocumentBuilder builder = createDocumentBuilder(factory, entityResolver, errorHandler);
		return builder.parse(inputSource);
	}
```

此com.sun.org.apache.xerces.internal.jaxp.DocumentBuilderImpl#parse位于jdk的代码中。

17. **退回到doLoadBeanDefinitions方法中，跟踪registerBeanDefinitions方法.**

```
public int registerBeanDefinitions(Document doc, Resource resource) throws BeanDefinitionStoreException {
		//创建一个文件读取器对象,类型为org.springframework.beans.factory.xml.DefaultBeanDefinitionDocumentReader
		BeanDefinitionDocumentReader documentReader = createBeanDefinitionDocumentReader();
		//进行读取之前的定义统计
		int countBefore = getRegistry().getBeanDefinitionCount();
		//将当前的配制文件中的定义进行定义读取
		documentReader.registerBeanDefinitions(doc, createReaderContext(resource));
		return getRegistry().getBeanDefinitionCount() - countBefore;
	}
```

18. **继续跟踪registerBeanDefinitions方法，就来到了DefaultBeanDefinitionDocumentReader的registerBeanDefinitions方法**

```
public void registerBeanDefinitions(Document doc, XmlReaderContext readerContext) {
		this.readerContext = readerContext;
		doRegisterBeanDefinitions(doc.getDocumentElement());
	}
```

19. **继续跟踪就来到了DefaultBeanDefinitionDocumentReader的doRegisterBeanDefinitions方法。**

```
protected void doRegisterBeanDefinitions(Element root) {
		// Any nested <beans> elements will cause recursion in this method. In
		// order to propagate and preserve <beans> default-* attributes correctly,
		// keep track of the current (parent) delegate, which may be null. Create
		// the new (child) delegate with a reference to the parent for fallback purposes,
		// then ultimately reset this.delegate back to its original (parent) reference.
		// this behavior emulates a stack of delegates without actually necessitating one.
		BeanDefinitionParserDelegate parent = this.delegate;
		//执行委托操作
		this.delegate = createDelegate(getReaderContext(), root, parent);

		if (this.delegate.isDefaultNamespace(root)) {
			String profileSpec = root.getAttribute(PROFILE_ATTRIBUTE);
			if (StringUtils.hasText(profileSpec)) {
				String[] specifiedProfiles = StringUtils.tokenizeToStringArray(
						profileSpec, BeanDefinitionParserDelegate.MULTI_VALUE_ATTRIBUTE_DELIMITERS);
				// We cannot use Profiles.of(...) since profile expressions are not supported
				// in XML config. See SPR-12458 for details.
				if (!getReaderContext().getEnvironment().acceptsProfiles(specifiedProfiles)) {
					if (logger.isDebugEnabled()) {
						logger.debug("Skipped XML bean definition file due to specified profiles [" + profileSpec +
								"] not matching: " + getReaderContext().getResource());
					}
					return;
				}
			}
		}
		//扩展方法，子类可实现加载之前的操作
		preProcessXml(root);
		//进行当前的bean的定义操作
		parseBeanDefinitions(root, this.delegate);
		//子类实现，加载定义在xml文件之后的操作
		postProcessXml(root);

		this.delegate = parent;
	}
```

20. **跟踪parseBeanDefinitions方法，就来到了DefaultBeanDefinitionDocumentReader#parseBeanDefinitions**

```
protected void parseBeanDefinitions(Element root, BeanDefinitionParserDelegate delegate) {
		if (delegate.isDefaultNamespace(root)) {
			//遍历xml的节点，进行注册操作
			NodeList nl = root.getChildNodes();
			for (int i = 0; i < nl.getLength(); i++) {
				Node node = nl.item(i);
				if (node instanceof Element) {
					Element ele = (Element) node;
					//如果是默认的spring的标签，则由内部处理
					if (delegate.isDefaultNamespace(ele)) {
						parseDefaultElement(ele, delegate);
					} else {
						//自定义的处理
						delegate.parseCustomElement(ele);
					}
				}
			}
		} else {
			delegate.parseCustomElement(root);
		}
	}
```

21. **当加载bean文件中的信息时，则由DefaultBeanDefinitionDocumentReader的parseDefaultElement**

```
private void parseDefaultElement(Element ele, BeanDefinitionParserDelegate delegate) {
		//import标签
		if (delegate.nodeNameEquals(ele, IMPORT_ELEMENT)) {
			importBeanDefinitionResource(ele);
		}
		//alias标签
		else if (delegate.nodeNameEquals(ele, ALIAS_ELEMENT)) {
			processAliasRegistration(ele);
		}
		//bean标签
		else if (delegate.nodeNameEquals(ele, BEAN_ELEMENT)) {
			processBeanDefinition(ele, delegate);
		}
		//beans标签
		else if (delegate.nodeNameEquals(ele, NESTED_BEANS_ELEMENT)) {
			// recurse
			doRegisterBeanDefinitions(ele);
		}
	}
```

22. **当前定义的为bean标签，则交由bean标签处理器。**

```
protected void processBeanDefinition(Element ele, BeanDefinitionParserDelegate delegate) {
		//创建一个bean的处理器。
		BeanDefinitionHolder bdHolder = delegate.parseBeanDefinitionElement(ele);
		if (bdHolder != null) {
			bdHolder = delegate.decorateBeanDefinitionIfRequired(ele, bdHolder);
			try {
				// Register the final decorated instance.
				BeanDefinitionReaderUtils.registerBeanDefinition(bdHolder, getReaderContext().getRegistry());
			} catch (BeanDefinitionStoreException ex) {
				getReaderContext().error("Failed to register bean definition with name '" +
						bdHolder.getBeanName() + "'", ele, ex);
			}
			// Send registration event.
			getReaderContext().fireComponentRegistered(new BeanComponentDefinition(bdHolder));
		}
	}
```

23. **当拿到Bean节点后进行加载操作。就来到了BeanDefinitionReaderUtils.registerBeanDefinition方法。**

```
public static void registerBeanDefinition(
			BeanDefinitionHolder definitionHolder, BeanDefinitionRegistry registry)
			throws BeanDefinitionStoreException {

		// Register bean definition under primary name.
		String beanName = definitionHolder.getBeanName();
		registry.registerBeanDefinition(beanName, definitionHolder.getBeanDefinition());

		// Register aliases for bean name, if any.
		String[] aliases = definitionHolder.getAliases();
		if (aliases != null) {
			for (String alias : aliases) {
				registry.registerAlias(beanName, alias);
			}
		}
	}
```

24. **继续跟踪registry.registerBeanDefinition查看加载，就来到了DefaultListableBeanFactory的registerBeanDefinition**

```
public void registerBeanDefinition(String beanName, BeanDefinition beanDefinition)
			throws BeanDefinitionStoreException {

		Assert.hasText(beanName, "Bean name must not be empty");
		Assert.notNull(beanDefinition, "BeanDefinition must not be null");

		if (beanDefinition instanceof AbstractBeanDefinition) {
			try {
				((AbstractBeanDefinition) beanDefinition).validate();
			}
			catch (BeanDefinitionValidationException ex) {
				throw new BeanDefinitionStoreException(beanDefinition.getResourceDescription(), beanName,
						"Validation of bean definition failed", ex);
			}
		}

		BeanDefinition existingDefinition = this.beanDefinitionMap.get(beanName);
		if (existingDefinition != null) {
			if (!isAllowBeanDefinitionOverriding()) {
				throw new BeanDefinitionOverrideException(beanName, beanDefinition, existingDefinition);
			}
			else if (existingDefinition.getRole() < beanDefinition.getRole()) {
				// e.g. was ROLE_APPLICATION, now overriding with ROLE_SUPPORT or ROLE_INFRASTRUCTURE
				if (logger.isInfoEnabled()) {
					logger.info("Overriding user-defined bean definition for bean '" + beanName +
							"' with a framework-generated bean definition: replacing [" +
							existingDefinition + "] with [" + beanDefinition + "]");
				}
			}
			else if (!beanDefinition.equals(existingDefinition)) {
				if (logger.isDebugEnabled()) {
					logger.debug("Overriding bean definition for bean '" + beanName +
							"' with a different definition: replacing [" + existingDefinition +
							"] with [" + beanDefinition + "]");
				}
			}
			else {
				if (logger.isTraceEnabled()) {
					logger.trace("Overriding bean definition for bean '" + beanName +
							"' with an equivalent definition: replacing [" + existingDefinition +
							"] with [" + beanDefinition + "]");
				}
			}
			this.beanDefinitionMap.put(beanName, beanDefinition);
		}
		else {
			if (hasBeanCreationStarted()) {
				// Cannot modify startup-time collection elements anymore (for stable iteration)
				synchronized (this.beanDefinitionMap) {
					this.beanDefinitionMap.put(beanName, beanDefinition);
					List<String> updatedDefinitions = new ArrayList<>(this.beanDefinitionNames.size() + 1);
					updatedDefinitions.addAll(this.beanDefinitionNames);
					updatedDefinitions.add(beanName);
					this.beanDefinitionNames = updatedDefinitions;
					removeManualSingletonName(beanName);
				}
			}
			else {
				// Still in startup registration phase
				this.beanDefinitionMap.put(beanName, beanDefinition);
				this.beanDefinitionNames.add(beanName);
				removeManualSingletonName(beanName);
			}
			this.frozenBeanDefinitionNames = null;
		}

		if (existingDefinition != null || containsSingleton(beanName)) {
			resetBeanDefinition(beanName);
		}
		else if (isConfigurationFrozen()) {
			clearByTypeCache();
		}
	}
```

最终会将beanDefinition名称放入到beanDefinitionMap中，将beanName放入到beanDefinitionNames.

至此beanDefinition加载的源码已经初步分析完毕。

将整个的一个调用过程画一个时序图。来表示。就可以得到一个

![调和序列图](D:\doc\博客\新技术学习\spring码源\spring源码-beanDefinition调用序列图.jpg)



类的调用

```
AbstractApplicationContext#refresh()
  AbstractApplicationContext#obtainFreshBeanFactory()
    AbstractRefreshableApplicationContext#refreshBeanFactory()
      AbstractXmlApplicationContext#loadBeanDefinitions(DefaultListableBeanFactory)
	    AbstractXmlApplicationContext#loadBeanDefinitions(XmlBeanDefinitionReader)
	      AbstractBeanDefinitionReader#loadBeanDefinitions(String...)
	  	    AbstractBeanDefinitionReader#loadBeanDefinitions(String)
	  	     AbstractBeanDefinitionReader#loadBeanDefinitions(String, Set<Resource>)
	  		    AbstractBeanDefinitionReader#loadBeanDefinitions(Resource...)
	  		      XmlBeanDefinitionReader#loadBeanDefinitions(Resource)
	  		  	    XmlBeanDefinitionReader#loadBeanDefinitions(support.EncodedResource)
	  		  	      XmlBeanDefinitionReader#doLoadBeanDefinitions(InputSource, Resource)
	  		  		    XmlBeanDefinitionReader#registerBeanDefinitions(Document, XmlReaderContext)
	  		  		      DefaultBeanDefinitionDocumentReader#registerBeanDefinitions(Document, XmlReaderContext)
	  		  			    DefaultBeanDefinitionDocumentReader#doRegisterBeanDefinitions(Element)
	  		  			      DefaultBeanDefinitionDocumentReader#parseBeanDefinitions(Element, BeanDefinitionParserDelegate)
	  		  				    DefaultBeanDefinitionDocumentReader#parseDefaultElement(Element, BeanDefinitionParserDelegate)
	  		  				      DefaultBeanDefinitionDocumentReader#processBeanDefinition(BeanDefinitionHolder, BeanDefinitionRegistry)
	  		  					    BeanDefinitionReaderUtils#registerBeanDefinition(BeanDefinitionHolder, BeanDefinitionRegistry)
	  		  					      DefaultListableBeanFactory#registerBeanDefinition(String, BeanDefinition)
```











