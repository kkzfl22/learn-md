package org.liujun.learn.spring.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * 执行jdbc数据库操作
 *
 * @author liujun
 * @version 0.0.1
 */
@Component
public class JdbcConnection {


    /**
     * 数据库连接池
     */
    @Autowired
    private DataSource dataSource;


    /**
     * 线程绑定对象
     */
    private ThreadLocal<Connection> threadLocal = new ThreadLocal<>();


    /**
     * 获取连接
     *
     * @return
     */
    public Connection getConn() {
        Connection connectInfo = threadLocal.get();
        if (connectInfo == null) {
            try {
                connectInfo = dataSource.getConnection();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            threadLocal.set(connectInfo);
        }

        return connectInfo;
    }

}
