/*
 * Copyright (C), 2008-2021, Paraview All Rights Reserved.
 */
package org.liujun.learn.spring.factory;

import org.liujun.learn.spring.utils.JdbcConnection;

/**
 * 使用静态方式进行创建对象
 *
 * @author liujun
 * @since 2021/7/15
 */
public class ConnectionStaticCreate {


    /**
     * 使用静态方式创建对象
     *
     * @return 静态方法
     */
    public static JdbcConnection staticGetConn() {
        return new JdbcConnection();
    }


    /**
     * 使用普通方式创建对象
     *
     * @return 静态方法
     */
    public JdbcConnection normalGetConn() {
        return new JdbcConnection();
    }

}
