使用原生的spring来操作，配制使用纯xml文件的形式。

## BeanFactory与FactoryBean

BeanFactory,用于初始化bean工厂的创建，
BeanFactory初始化之后，就可以使用BeanFactoryPostProcessor进行工厂对象的创建。


FactoryBean用于Bean的创建操作.
在Bean创建完成后，可使用BeanPostProcessor创建对象。





