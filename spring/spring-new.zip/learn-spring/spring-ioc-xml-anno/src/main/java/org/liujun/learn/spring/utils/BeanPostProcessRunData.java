/*
 * Copyright (C), 2008-2021, Paraview All Rights Reserved.
 */
package org.liujun.learn.spring.utils;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

/**
 * 执行bean的调用操作
 *
 * @author liujun
 * @since 2021/7/20
 */
public class BeanPostProcessRunData implements BeanPostProcessor {

    /**
     * 执行init方法之前所执行的方法
     *
     * @param bean     当前的实体bean
     * @param beanName 实体的名称
     * @return
     * @throws BeansException
     */
    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {

        if ("lazyData".equalsIgnoreCase(beanName)) {
            System.out.println("当前延迟加载before的bean被执行");
        } else {
            System.out.println("其他的before的bean被执行:" + bean);
        }


        return bean;
    }

    /**
     * 执行init-method之后的方法
     *
     * @param bean     当前实体对象
     * @param beanName 当前的实体名称
     * @return
     * @throws BeansException
     */
    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        if ("lazyData".equalsIgnoreCase(beanName)) {
            System.out.println("当前延迟加载after的bean被执行");
        } else {
            System.out.println("其他的after的bean被执行");
        }

        return bean;
    }
}
