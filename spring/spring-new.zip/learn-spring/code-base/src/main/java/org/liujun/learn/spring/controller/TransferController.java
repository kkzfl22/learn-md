/*
 * Copyright (C), 2008-2021, Paraview All Rights Reserved.
 */
package org.liujun.learn.spring.controller;

import org.liujun.learn.spring.pojo.Account;
import org.liujun.learn.spring.pojo.DataResult;
import org.liujun.learn.spring.service.TransferMoneyService;
import org.liujun.learn.spring.utils.JsonUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * 转账服务的控制层
 *
 * @author liujun
 * @since 2021/7/5
 */
public class TransferController extends HttpServlet {

    private TransferMoneyService transferMoneyInstance = new TransferMoneyService();


    @Override
    public void service(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
        req.setCharacterEncoding(StandardCharsets.UTF_8.displayName());

        Account src = new Account();
        src.setCardId(Long.parseLong(req.getParameter("srcCardId")));
        src.setName(req.getParameter("srcName"));

        Account target = new Account();
        target.setCardId(Long.parseLong(req.getParameter("targetCardId")));
        target.setName(req.getParameter("targetName"));

        int transferMoney = Integer.parseInt(req.getParameter("money"));
        boolean transferRsp = false;
        try {
            transferRsp = transferMoneyInstance.transfer(src, target, transferMoney);
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (transferRsp) {
            req.getRequestDispatcher("/success.html").forward(req, res);
        } else {
            req.getRequestDispatcher("/error.html").forward(req, res);
        }
    }
}
