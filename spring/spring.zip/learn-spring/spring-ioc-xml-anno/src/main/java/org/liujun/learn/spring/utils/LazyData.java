/*
 * Copyright (C), 2008-2021, Paraview All Rights Reserved.
 */
package org.liujun.learn.spring.utils;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

/**
 * 测试初始化对象
 *
 * @author liujun
 * @since 2021/7/18
 */
public class LazyData implements BeanNameAware, BeanFactoryAware, ApplicationContextAware, InitializingBean, DisposableBean {

    /**
     * 初始化
     */
    private String name;

    public void data() {
        this.name = "this name";
    }


    /**
     * 注册到容器中的值
     *
     * @param s
     */
    @Override
    public void setBeanName(String s) {
        //注册结果值为:lazyData
        System.out.println("注册成为bean时定义的id:" + s);
    }

    @Override
    public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
        System.out.println("调用BeanFactoryAware的方法" + beanFactory);
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        System.out.println("调用ApplicationContextAware的方法" + applicationContext);
    }


    @Override
    public void afterPropertiesSet() throws Exception {
        System.out.println("top1执行的初始化,在init-method方法之前被执行");
    }


    @PostConstruct
    public void postConstruct() {
        System.out.println("当存在PostConstruct时，@PostConstruct最先被执行,在afterPropertiesSet方法之前执行");
    }

    @Override
    public void destroy() throws Exception {
        System.out.println("DisposableBean接口第二执行");
    }

    @PreDestroy
    public void destory2() {
        System.out.println("注解@PreDestroy最优先执行");
    }

    public void destoryMethod() {
        System.out.println("destroy-method,最后执行");
    }
}
