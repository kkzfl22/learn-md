使用原生的spring来操作，配制使用纯xml+annotation注解的形式。



```flow
st=>start: spring初始化
init1=>operation: 1，初始化bean(根据配制情况调用构建或者工厂方法实体化bean)
init2=>operation: 2,设置属性值(使用依赖注入，完成所有配制值的注入)
init3=>operation: 3，调用BeanNameAware的setBeanName方法（可以获取到给这个实例在spring容器中定义的id）
init4=>operation: 4,调用BeanFactoryAware的setBeanFactoy方法(可以获取到创建的工厂信息)
init5=>operation: 5,调用ApplicationContextAware的setApplication方法(可以获取到高级容器对象Application对象)
init6=>operation: 6,调用BeanPostProcessor的Before方法(在调用bean的init-method方法方前执行的方法)
init7=>operation: 7,调用initializingBean的afterPropertiesSet方法(用来做对象实体化之后的初始化动作，top1执行,如果加入了@PostConstruct方法，则@PostConstruct在afterPropertiesSet方法之前)
init8=>operation: 8,调用定制的初始化方法init-method
init9=>operation: 9，调用BeanPostProcessor的后初始化方法
cond=>condition: 9,是否单例对象
init91=>operation: 9-0,protoType对象
init92=>operation: 9-1,singleton对象
procinit91=>operation: 9-1,将准备就绪的Bean交给调用者
procinit92=>operation: 9-2,SpringBean缓存池中准备就绪的Bean
procDestory=>operation: @PreDestroy销毁对象的调用
destory-interface=>operation:  DisposableBean接口调用
destory-method=>operation:  xml的bean的destroy-method方法指定

init1->init2->init3->init4->init5->init6->init7->init8->init9->cond
cond(no)->init91->procinit91
cond(yes)->init92->procinit92->procDestory->destory-interface->destory-method

```