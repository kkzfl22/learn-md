/*
 * Copyright (C), 2008-2021, Paraview All Rights Reserved.
 */
package org.liujun.learn.spring.loader;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.liujun.learn.spring.SpringContextLoader;
import org.liujun.learn.spring.dao.AccountDao;
import org.liujun.learn.spring.pojo.Account;
import org.liujun.learn.spring.utils.JdbcConnection;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * 数据加载
 *
 * @author liujun
 * @since 2021/7/15
 */
public class DataLoader {

    @Test
    public void loader() {
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringContextLoader.class);
        AccountDao daoInstance = (AccountDao) context.getBean(AccountDao.class);
        Account rsp = daoInstance.getAccount(66666666L);
        System.out.println(rsp);
        Assertions.assertNotNull(rsp);


    }

}
