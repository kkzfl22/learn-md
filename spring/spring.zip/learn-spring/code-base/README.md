## 工程说明

spring学习的基本工程，可完成转帐的基础功能。

```shell script
D:.
├─main
│  ├─java
│  │  └─org
│  │      └─liujun
│  │          └─learn
│  │              └─spring
│  │                  ├─constant
│  │                  │      ErrorCodeEnum.java -- 错误码
│  │                  │
│  │                  ├─controller
│  │                  │      TransferController.java -- controller
│  │                  │
│  │                  ├─dao
│  │                  │  │  AccountDao.java -- 数据库操作
│  │                  │  │
│  │                  │  └─Impl
│  │                  │          JdbcConnection.java -- 数据库连接工具
│  │                  │          SqlLiteJdbcOperatorImpl.java -- 数据库操作
│  │                  │
│  │                  ├─pojo
│  │                  │      Account.java -- 实体
│  │                  │      DataResult.java -- 返回对象
│  │                  │
│  │                  ├─service
│  │                  │      TransferMoneyService.java -- 服务实现
│  │                  │
│  │                  └─utils
│  │                          JsonUtils.java
│  │
│  ├─resources
│  │      base.txt
│  │
│  └─webapp
│      │  index.html
│      │
│      └─WEB-INF
│              web.xml

```