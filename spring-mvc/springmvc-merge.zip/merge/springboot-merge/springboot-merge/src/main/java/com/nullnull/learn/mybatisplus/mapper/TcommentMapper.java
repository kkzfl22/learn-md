package com.nullnull.learn.mybatisplus.mapper;
/**
 *
 * @author liujun
 * @since 2023/3/25
 */
public class TcommentMapper {
}
