package com.nullnull.learn.redis.repository;
/**
 *
 * @author liujun
 * @since 2023/3/24
 */
public class PersonRepository {
}
