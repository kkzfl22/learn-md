package com.nullnull.learn.mybatisplus.po;
/**
 *
 * @author liujun
 * @since 2023/3/25
 */
public class Tcommon {
}
