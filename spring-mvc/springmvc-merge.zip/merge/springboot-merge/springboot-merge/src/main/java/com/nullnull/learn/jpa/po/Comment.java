package com.nullnull.learn.jpa.po;
/**
 *
 * @author liujun
 * @since 2023/3/24
 */
public class Comment {
}
