package com.nullnull.learn.jpa.repository;
/**
 *
 * @author liujun
 * @since 2023/3/24
 */
public class TestCommentRepository {
}
