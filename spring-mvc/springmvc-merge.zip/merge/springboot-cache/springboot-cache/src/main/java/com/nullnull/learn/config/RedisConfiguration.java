package com.nullnull.learn.config;
/**
 *
 * @author liujun
 * @since 2023/3/27
 */
public class RedisConfiguration {
}
