package com.nullnull.learn.repository;
/**
 *
 * @author liujun
 * @since 2023/3/26
 */
public class CommentRepository {
}
