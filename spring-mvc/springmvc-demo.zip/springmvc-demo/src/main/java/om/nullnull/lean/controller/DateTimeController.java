package om.nullnull.lean.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.time.LocalDateTime;

/**
 * 时间处理器
 *
 * @author liujun
 * @since 2023/1/19
 */
@Controller
@RequestMapping("/demo")
public class DateTimeController {


    @RequestMapping("/handlerTime")
    public ModelAndView dateShow() {

        //封装数据和页面信息的ModelAndView
        ModelAndView dataShow = new ModelAndView();
        // 向请求域中添加time属性的数据，等于request.setAttribute("time,xxx);
        dataShow.addObject("time", LocalDateTime.now());
        //视图跳转信息
        dataShow.setViewName("success");

        return dataShow;
    }

}
