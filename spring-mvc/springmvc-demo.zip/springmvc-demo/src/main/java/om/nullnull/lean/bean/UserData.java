package om.nullnull.lean.bean;

/**
 * @author liujun
 * @since 2023/2/5
 */
public class UserData {
  private Integer id;
  private String name;

  private UserAddress address;

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public UserAddress getAddress() {
    return address;
  }

  public void setAddress(UserAddress address) {
    this.address = address;
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("UserData{");
    sb.append("id=").append(id);
    sb.append(", name='").append(name).append('\'');
    sb.append(", address=").append(address);
    sb.append('}');
    return sb.toString();
  }
}
