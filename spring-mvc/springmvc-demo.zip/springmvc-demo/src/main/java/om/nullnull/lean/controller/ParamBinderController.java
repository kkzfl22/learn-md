package om.nullnull.lean.controller;

import om.nullnull.lean.bean.UserData;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.time.LocalDateTime;
import java.util.Date;

/**
 * 参数处理
 *
 * @author liujun
 * @since 2023/2/3
 */
@Controller
public class ParamBinderController {

  /**
   * 最基础的使用原生的Servlet的形式
   *
   * @param request
   * @param response
   * @return
   */
  @RequestMapping("/handle01")
  public ModelAndView handler1(HttpServletRequest request, HttpServletResponse response) {

    String id = request.getParameter("id");
    System.out.println("id:" + id);

    ModelAndView result = new ModelAndView();

    result.addObject("time", LocalDateTime.now());
    result.setViewName("success");

    return result;
  }

  @RequestMapping("/handle02")
  public ModelAndView handler2(Integer id) {
    System.out.println("id:" + id);
    ModelAndView result = new ModelAndView();

    result.addObject("time", LocalDateTime.now());
    result.setViewName("success");

    return result;
  }

  @RequestMapping("/handle021")
  public ModelAndView handler21(@RequestParam("idData") Integer id) {
    System.out.println("id:" + id);
    ModelAndView result = new ModelAndView();

    result.addObject("time", LocalDateTime.now());
    result.setViewName("success");

    return result;
  }

  @RequestMapping("/handle03")
  public ModelAndView handle03(UserData userInfo) {
    System.out.println("userInfo:" + userInfo);
    ModelAndView result = new ModelAndView();

    result.addObject("time", LocalDateTime.now());
    result.setViewName("success");

    return result;
  }


  @RequestMapping("/handle031")
  public ModelAndView handle031(UserData userInfo) {
    System.out.println("userInfo31:" + userInfo);
    ModelAndView result = new ModelAndView();

    result.addObject("time", LocalDateTime.now());
    result.setViewName("success");

    return result;
  }

  @RequestMapping("/handle04")
  public ModelAndView handle04(LocalDateTime dataTime) {
    System.out.println("dataTime:" + dataTime);
    ModelAndView result = new ModelAndView();

    result.addObject("time", LocalDateTime.now());
    result.setViewName("success");

    return result;
  }

  @RequestMapping("/handle05")
  public ModelAndView handle05(Date date) {
    System.out.println("date:" + date);
    ModelAndView result = new ModelAndView();

    result.addObject("time", LocalDateTime.now());
    result.setViewName("success");

    return result;
  }
}
