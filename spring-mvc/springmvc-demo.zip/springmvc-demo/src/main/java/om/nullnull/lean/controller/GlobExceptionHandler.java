package om.nullnull.lean.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import java.time.LocalDateTime;

/**
 * 全局异常处理器
 *
 * @author liujun
 * @since 2023/2/12
 */
@ControllerAdvice
public class GlobExceptionHandler {

  /**
   * 专门用来处理用0做除数的异常
   *
   * @param e
   * @return
   */
  @ExceptionHandler(ArithmeticException.class)
  public ModelAndView handleException(ArithmeticException e) {

    ModelAndView result = new ModelAndView();

    result.addObject("errorMsg", "glob " + e.getMessage());
    result.addObject("time", LocalDateTime.now());

    result.setViewName("error");

    return result;
  }
}
