package om.nullnull.lean.interceptor;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 自定义SringMVC的拦截器
 *
 * @author liujun
 * @since 2023/2/8
 */
public class MyIntercepter01 implements HandlerInterceptor {

  /**
   * 该方法会在Handler方法业务执行逻辑执行之前执行
   *
   * @param request
   * @param response
   * @param handler
   * @return 是否放行。 true 放行，false 拦截
   * @throws Exception
   */
  @Override
  public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
      throws Exception {
    System.out.println("MyIntercepter01 preHandle...");
    return true;
  }

  /**
   * 会在handler方法业务逻辑执行之后尚未跳转页面时执行
   *
   * @param request
   * @param response
   * @param handler
   * @param modelAndView
   * @throws Exception
   */
  @Override
  public void postHandle(
      HttpServletRequest request,
      HttpServletResponse response,
      Object handler,
      ModelAndView modelAndView)
      throws Exception {

    System.out.println("MyIntercepter01 postHandle...");
  }

  /**
   * 页面已经跳转渲染完成后执行
   *
   * @param request
   * @param response
   * @param handler
   * @param ex
   * @throws Exception
   */
  @Override
  public void afterCompletion(
      HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
      throws Exception {

    System.out.println("MyIntercepter01 afterCompletion...");
  }
}
