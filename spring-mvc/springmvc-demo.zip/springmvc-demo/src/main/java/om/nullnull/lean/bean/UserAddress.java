package om.nullnull.lean.bean;

/**
 * @author liujun
 * @since 2023/2/5
 */
public class UserAddress {
  private Integer addressId;
  private String address;

  public Integer getAddressId() {
    return addressId;
  }

  public void setAddressId(Integer addressId) {
    this.addressId = addressId;
  }

  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("UserAddress{");
    sb.append("addressId=").append(addressId);
    sb.append(", address='").append(address).append('\'');
    sb.append('}');
    return sb.toString();
  }
}
