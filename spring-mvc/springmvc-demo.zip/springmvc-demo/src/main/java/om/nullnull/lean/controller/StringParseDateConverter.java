package om.nullnull.lean.controller;

import org.springframework.core.convert.converter.Converter;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author liujun
 * @since 2023/2/5
 */
public class StringParseDateConverter implements Converter<String, Date> {

  private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");

  @Override
  public Date convert(String s) {

    try {
      Date time = DATE_FORMAT.parse(s);
      return time;
    } catch (ParseException e) {
      e.printStackTrace();
    }

    return null;
  }
}
