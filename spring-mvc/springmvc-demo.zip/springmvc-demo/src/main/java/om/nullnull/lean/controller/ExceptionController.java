package om.nullnull.lean.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletResponse;
import java.time.LocalDateTime;

/**
 * @author liujun
 * @since 2023/2/12
 */
@Controller
public class ExceptionController {

  @ExceptionHandler(ArithmeticException.class)
  public ModelAndView exceptionHandler(
      ArithmeticException exception, HttpServletResponse response) {
    ModelAndView result = new ModelAndView();

    result.addObject("errorMsg", exception.getMessage());
    result.addObject("time", LocalDateTime.now());
    result.setViewName("error");

    return result;
  }

  @RequestMapping(
      value = "/exception01",
      method = {RequestMethod.GET})
  public ModelAndView exceptionProcess() {
    ModelAndView result = new ModelAndView();

    int value = 100 / 0;

    result.setViewName("success" + value);

    return result;
  }
}
