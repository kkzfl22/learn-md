package om.nullnull.lean.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * 传统的参数传递
 *
 * @author liujun
 * @since 2023/2/12
 */
@Controller
public class RedirectController {

  @RequestMapping(
      value = "/redirect01",
      method = {RequestMethod.GET})
  public ModelAndView redirect01(String dataName, RedirectAttributes redirectAttributes) {

    ModelAndView view = new ModelAndView();

    redirectAttributes.addFlashAttribute("dataName", "RedirectAttributes--" + dataName);
    view.setViewName("redirect:redirect02");

    return view;
  }

  @RequestMapping(
      value = "/redirect02",
      method = {RequestMethod.GET})
  public ModelAndView redirect02(@ModelAttribute("dataName") String dataName) {

    ModelAndView view = new ModelAndView();

    view.addObject("time", "value:" + dataName);

    view.setViewName("success");

    return view;
  }
}
