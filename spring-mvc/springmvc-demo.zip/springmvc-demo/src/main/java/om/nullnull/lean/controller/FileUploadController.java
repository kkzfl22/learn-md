package om.nullnull.lean.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * SpringMvc对于Rest的支持
 *
 * @author liujun
 * @since 2023/2/3
 */
@Controller
public class FileUploadController {

  @RequestMapping(value = "/fileUpload")
  public ModelAndView handler1(MultipartFile uploadFile, HttpServletRequest request)
      throws IOException {
    // 1，获取文件源名称
    String originalName = uploadFile.getOriginalFilename();
    // 获取文件扩展名
    String suffixName = originalName.substring(originalName.lastIndexOf("."));

    String newName = UUID.randomUUID().toString();
    String newFullName = newName + suffixName;

    String realPath = request.getSession().getServletContext().getRealPath("/uploads/");

    File dataFile = new File(realPath, newFullName);
    if (!dataFile.exists()) {
      dataFile.mkdirs();
    }

    uploadFile.transferTo(dataFile);

    ModelAndView result = new ModelAndView();

    result.addObject("time", LocalDateTime.now());
    result.setViewName("success");

    return result;
  }
}
