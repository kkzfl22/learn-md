package om.nullnull.lean.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import java.time.LocalDateTime;

/**
 * SpringMvc对于Rest的支持
 *
 * @author liujun
 * @since 2023/2/3
 */
@Controller
public class RestController {

  @RequestMapping(
      value = "/restHandle01/{id}",
      method = {RequestMethod.GET})
  public ModelAndView handler1(@PathVariable String id) {

    System.out.println("get param id:" + id);

    ModelAndView result = new ModelAndView();

    result.addObject("time", LocalDateTime.now());
    result.setViewName("success");

    return result;
  }

  @RequestMapping(
      value = "/restHandle02",
      method = {RequestMethod.POST})
  public ModelAndView handle2(String name) {
    System.out.println("post param name:" + name);

    ModelAndView result = new ModelAndView();

    result.addObject("time", LocalDateTime.now());
    result.setViewName("success");

    return result;
  }

  @RequestMapping(
      value = "/restHandle03/{id}",
      method = {RequestMethod.PUT})
  public ModelAndView handle3(@PathVariable String id) {
    System.out.println("put param name:" + id);

    ModelAndView result = new ModelAndView();

    result.addObject("time", LocalDateTime.now());
    result.setViewName("success");

    return result;
  }

  @RequestMapping(
      value = "/restHandle04/{id}",
      method = {RequestMethod.DELETE})
  public ModelAndView handle4(@PathVariable String id) {
    System.out.println("delete param name:" + id);

    ModelAndView result = new ModelAndView();

    result.addObject("time", LocalDateTime.now());
    result.setViewName("success");

    return result;
  }
}
