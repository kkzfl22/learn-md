package om.nullnull.lean.controller;

import om.nullnull.lean.bean.UserAddress;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * SpringMvc对于Rest的支持
 *
 * @author liujun
 * @since 2023/2/3
 */
@Controller
public class RestAjaxController {

  @RequestMapping(value = "/restAjaxTestHandle01")
  public @ResponseBody UserAddress restAjaxHandle01(@RequestBody UserAddress address) {
    System.out.println("request address" + address);
    address.setAddress("新的地址");
    return address;
  }
}
