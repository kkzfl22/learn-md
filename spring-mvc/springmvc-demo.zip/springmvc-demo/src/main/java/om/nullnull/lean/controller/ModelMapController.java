package om.nullnull.lean.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import java.time.LocalDateTime;
import java.util.Map;

/**
 * @author liujun
 * @since 2023/2/3
 */
@Controller
public class ModelMapController {

    @RequestMapping("/requestModelMap")
    public String dataProcess(ModelMap modelMap) {
        modelMap.put("time", LocalDateTime.now());
        System.out.println("1---------: " + modelMap.getClass());
        return "success";
    }


    @RequestMapping("/requestModel")
    public String dataProcessModel(Model model) {
        model.addAttribute("time", LocalDateTime.now());
        System.out.println("2---------: " + model.getClass());
        return "success";
    }


    @RequestMapping("/requestMapping")
    public String dataProcessMap(Map<String, Object> map) {
        map.put("time", LocalDateTime.now());
        System.out.println("3---------: " + map.getClass());
        return "success";
    }
}
