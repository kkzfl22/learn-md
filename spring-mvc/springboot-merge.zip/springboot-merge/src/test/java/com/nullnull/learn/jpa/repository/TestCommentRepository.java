package com.nullnull.learn.jpa.repository;

import com.nullnull.learn.jpa.po.Comment;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import java.util.Optional;
/**
 * 测试JPA的存储
 *
 * @author liujun
 * @since 2023/3/24
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class TestCommentRepository {

  @Autowired private CommentRepository commentRepository;

  @Test
  public void selectComment() {
    Optional<Comment> dataComment = commentRepository.findById(1);
    if (dataComment.isPresent()) {
      System.out.println(dataComment.get());
    }
    Assert.assertEquals(true, dataComment.isPresent());
  }
}
