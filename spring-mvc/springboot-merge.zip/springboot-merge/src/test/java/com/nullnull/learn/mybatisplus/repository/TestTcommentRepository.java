package com.nullnull.learn.mybatisplus.repository;

import com.nullnull.learn.mybatisplus.po.Tcomment;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import java.util.ArrayList;
import java.util.List;
/**
 * 测试一个高级的接口
 *
 * @author liujun
 * @since 2023/3/25
 */
@SpringBootTest
@RunWith(SpringRunner.class)
@MapperScan(value = "com.nullnull.learn.mybatisplus.mapper")
public class TestTcommentRepository {

  @Autowired private TcommentRepository tcommentRepository;

  @Test
  public void batch() {
    List<Tcomment> dataCommentList = new ArrayList<>();

    dataCommentList.add(newComment(11, "高兴啊", "nullnull", 1));
    dataCommentList.add(newComment(12, "蹦极", "nullnull", 1));
    dataCommentList.add(newComment(13, "爬山", "nullnull", 1));

    boolean batchRsp = tcommentRepository.saveBatch(dataCommentList);
    Assert.assertEquals(true, batchRsp);

    List<Tcomment> queryList = tcommentRepository.lambdaQuery().eq(Tcomment::getAId, 1).list();
    System.out.println(queryList);
    Assert.assertNotNull(queryList);
  }

  private Tcomment newComment(Integer id, String content, String auth, Integer aid) {
    Tcomment commentData = new Tcomment();

    commentData.setId(id);
    commentData.setContent(content);
    commentData.setAuthor(auth);
    commentData.setAId(aid);
    return commentData;
  }
}
