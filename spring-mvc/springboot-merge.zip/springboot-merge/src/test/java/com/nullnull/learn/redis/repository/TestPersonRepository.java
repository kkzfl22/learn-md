package com.nullnull.learn.redis.repository;

import com.nullnull.learn.redis.po.Address;
import com.nullnull.learn.redis.po.Person;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import java.util.List;
/**
 * 测试存储
 *
 * @author liujun
 * @since 2023/3/24
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class TestPersonRepository {

  @Autowired private PersonRepository personRepository;

  @Test
  public void testPerson() {
    Person person = new Person();
    person.setId("11");
    person.setFirstName("liu");
    person.setLastName("jun");
    Address dataAddress = new Address();
    dataAddress.setCity("上海");
    dataAddress.setCountry("中国");
    person.setAddress(dataAddress);

    personRepository.save(person);

    // 数据查找
    List<Person> dataPerson = personRepository.findByAddressCity("上海");
    System.out.println(dataPerson);
    Assert.assertNotNull(dataPerson);
  }
}
