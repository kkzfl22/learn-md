package com.nullnull.learn.mybatisplus.mapper;

import com.nullnull.learn.mybatisplus.po.Tcomment;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
/**
 * 测试评论的mappper
 *
 * @author liujun
 * @since 2023/3/25
 */
@SpringBootTest
@MapperScan("com.nullnull.learn.mybatisplus.mapper")
@RunWith(SpringRunner.class)
public class TestTcommentMapper {

  @Autowired private TcommentMapper mapper;

  @Test
  public void testBase() {
    Tcomment data = mapper.selectById(2);
    System.out.println(data);
    Assert.assertNotNull(data);
  }
}
