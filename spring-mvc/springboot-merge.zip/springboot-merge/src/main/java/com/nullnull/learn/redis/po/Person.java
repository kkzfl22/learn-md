package com.nullnull.learn.redis.po;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.redis.core.RedisHash;
import org.springframework.data.redis.core.index.Indexed;
import javax.persistence.Id;
/**
 * 存储的实体信息
 *
 * <p>@RedisHash("persons")
 * 用于指定操作实体对象在Redis数据库中的存储空间，此处表示针对Person实体类的数据操作都存储在Redis数据库中名为persons的存储空间下
 *
 * <p>@Id 用于指定实体主键，在Redis数据库中会默认生成字符串形式的HashKey表示唯一的实体对象，当然也可以在存储时，手动指定Id
 *
 * <p>@Index 用于标识对应属性在Redis数据库中生成二级索引，使用该注解后，会在Redis数据库中生成对应的二级索引，索引名称就是属性名，可以方便的过时行数据条件查找
 *
 * @author liujun
 * @since 2023/3/24
 */
@RedisHash("persons")
@Getter
@Setter
@ToString
public class Person {

  /** 主键的Id */
  @Id private String id;

  /** 姓 */
  @Indexed private String firstName;

  /** 名 */
  @Indexed private String lastName;

  /** 地址信息 */
  private Address address;
}
