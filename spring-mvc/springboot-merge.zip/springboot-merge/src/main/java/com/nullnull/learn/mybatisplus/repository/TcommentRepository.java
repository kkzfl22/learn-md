package com.nullnull.learn.mybatisplus.repository;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.nullnull.learn.mybatisplus.mapper.TcommentMapper;
import com.nullnull.learn.mybatisplus.po.Tcomment;
import org.springframework.stereotype.Repository;

/**
 * @author liujun
 * @since 2023/3/25
 */
@Repository
public class TcommentRepository extends ServiceImpl<TcommentMapper, Tcomment> {}
