package com.nullnull.learn.redis.po;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.redis.core.index.Indexed;

/**
 * 地址信息
 *
 * @author liujun
 * @since 2023/3/24
 */
@Getter
@Setter
@ToString
public class Address {

  /** 城市信息 */
  @Indexed private String city;

  /** 国家 */
  @Indexed private String country;
}
