package com.nullnull.learn.jpa.po;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
/**
 * 评论的存储对象
 *
 * @author liujun
 * @since 2023/3/24
 */
@Entity(name = "t_comment")
@Getter
@Setter
@ToString
public class Comment {

  /** 主键 @GeneratedValue(strategy = GenerationType.IDENTITY) 设置主键策略 */
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  /** 内容 */
  private String content;

  /** 作者 */
  private String author;

  /** 关联的文章的id */
  @Column(name = "a_id")
  private Integer aId;
}
