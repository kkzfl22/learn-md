package com.nullnull.learn.jpa.repository;

import com.nullnull.learn.jpa.po.Comment;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * 存储层的接口
 *
 * @author liujun
 * @since 2023/3/24
 */
public interface CommentRepository extends JpaRepository<Comment, Integer> {}
