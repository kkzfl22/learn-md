package com.nullnull.learn.mybatisplus.po;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
/**
 * 评论信息
 *
 * @author liujun
 * @since 2023/3/25
 */
@Getter
@Setter
@ToString
@TableName("t_comment")
public class Tcomment {

  /** 主键的id */
  private Integer id;

  /** 评论的内容 */
  private String content;

  /** 作者 */
  private String author;

  /** 关联T_article表的信息 */
  @TableField(value = "a_id")
  private Integer aId;
}
