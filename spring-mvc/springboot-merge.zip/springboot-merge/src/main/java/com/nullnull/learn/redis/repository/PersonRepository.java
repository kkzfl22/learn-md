package com.nullnull.learn.redis.repository;

import com.nullnull.learn.redis.po.Person;
import org.springframework.data.repository.CrudRepository;
import java.util.List;

/**
 * 针对Redis的操作
 *
 * @author liujun
 * @since 2023/3/24
 */
public interface PersonRepository extends CrudRepository<Person, String> {

  /**
   * 按地址的城市查找数据
   *
   * @param city
   * @return
   */
  List<Person> findByAddressCity(String city);
}
