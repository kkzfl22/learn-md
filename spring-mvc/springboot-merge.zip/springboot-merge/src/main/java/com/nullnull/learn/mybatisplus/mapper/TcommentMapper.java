package com.nullnull.learn.mybatisplus.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.nullnull.learn.mybatisplus.po.Tcomment;

/**
 * 标识当前为MybatisPlus的类
 *
 * @author liujun
 * @since 2023/3/25
 */
public interface TcommentMapper extends BaseMapper<Tcomment> {}
