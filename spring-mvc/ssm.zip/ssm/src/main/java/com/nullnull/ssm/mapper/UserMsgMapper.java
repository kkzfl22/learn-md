package com.nullnull.ssm.mapper;

import com.nullnull.ssm.entity.UserMsg;

import java.util.List;

/**
 * 基于mybatis的SQL操作
 *
 * @author liujun
 * @since 2023/2/20
 */
public interface UserMsgMapper {


    /**
     * 数据保存
     *
     * @param user
     * @return
     */
    int insert(UserMsg user);


    /**
     * 查询所有的用户信息
     *
     * @return
     */
    List<UserMsg> queryAll();

}
