package com.nullnull.ssm.service;

import com.nullnull.ssm.entity.UserMsg;
import com.nullnull.ssm.mapper.UserMsgMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 用户操作的服务
 *
 * @author liujun
 * @since 2023/2/20
 */
@Service
public class UserMsgService {


    /**
     * 用户服务
     */
    @Autowired
    private UserMsgMapper userMsgMapper;


    public boolean insert(UserMsg user) {
        int insert = userMsgMapper.insert(user);

        return insert > 0;
    }

    public List<UserMsg> queryAll() {
        return userMsgMapper.queryAll();
    }

}
