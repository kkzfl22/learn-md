package com.nullnull.ssm.entity;

/**
 * 用户对象
 *
 * @author liujun
 * @since 2022/6/29
 */
public class UserMsg {

    /**
     * 用户的id
     */
    private Integer id;

    /**
     * 名称的信息
     */
    private String name;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("UserMsgPO{");
        sb.append("id=").append(id);
        sb.append(", name='").append(name).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
