package com.nullnull.ssm.controller;

import com.nullnull.ssm.entity.UserMsg;
import com.nullnull.ssm.service.UserMsgService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * @author liujun
 * @since 2023/2/21
 */
@Controller
@RequestMapping("/user")
public class UserMsgController {


    /**
     * 用户操作的服务
     */
    @Autowired
    private UserMsgService userMsgService;


    @RequestMapping(value = "/queryAll", method = RequestMethod.GET)
    @ResponseBody
    public List<UserMsg> queryAll() {
        return userMsgService.queryAll();
    }

}
