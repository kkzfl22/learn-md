package com.nullnull.ssm.service;

import com.nullnull.ssm.entity.UserMsg;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

/**
 * @author liujun
 * @since 2023/2/20
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath*:applicationcontext-*.xml"})
public class TestUserMsgService {


    /**
     * 用户服务
     */
    @Autowired
    private UserMsgService userMsgService;


    @Test
    public void runData() {
        UserMsg userMsg = new UserMsg();
        userMsg.setId(23);
        userMsg.setName("dataName321");

        boolean addRsp = userMsgService.insert(userMsg);
        Assert.assertEquals(true, addRsp);

        List<UserMsg> dataList = userMsgService.queryAll();
        for (UserMsg msg : dataList) {
            System.out.println(msg);
        }
        Assert.assertNotEquals(0, dataList.size());
    }

}
