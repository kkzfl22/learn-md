package com.nullnull.demo.controller;

import com.nullnull.demo.service.UserInfoService;
import com.nullnull.mvc.annotation.NullNullAutowire;
import com.nullnull.mvc.annotation.NullNullController;
import com.nullnull.mvc.annotation.NullNullRequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 用户处理请求的控制器
 *
 * @author liujun
 * @since 2023/2/14
 */
@NullNullController
@NullNullRequestMapping("/userInfo")
public class UserInfoController {

  @NullNullAutowire private UserInfoService userInfoService;

  @NullNullRequestMapping("/getUserName")
  public void getUserName(HttpServletRequest request, HttpServletResponse response, String name)
      throws IOException {
    String dataInfo = userInfoService.getUserName(name);
    response.getWriter().write(dataInfo);
  }
}
