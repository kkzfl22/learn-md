package com.nullnull.mvc.servlet;

import com.nullnull.mvc.annotation.NullNullAutowire;
import com.nullnull.mvc.annotation.NullNullController;
import com.nullnull.mvc.annotation.NullNullRequestMapping;
import com.nullnull.mvc.annotation.NullNullService;
import com.nullnull.mvc.bean.MethodMapping;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 * 执行MVC的核心派发器的操作
 *
 * @author liujun
 * @since 2023/2/13
 */
public class NullNullDispatcherServlet extends HttpServlet {

  /** 扫描的包结构集合 */
  private List<String> scanPkgList = new ArrayList<>();

  /** 实例容器对象 */
  private Map<String, Object> iocMap = new HashMap<>();

  /** 方法映射区 */
  private Map<String, MethodMapping> urlMethodMapping = new HashMap<>();

  @Override
  public void init(ServletConfig config) {
    // 1.读取配制文件
    String scanPath = getScanPath(config);

    // 2. 进行包扫描，加载相关的注解。
    doScan(scanPath);

    // 3. IOC容器相关的初始化工作。
    doInstance();

    // 4. 进行属性的注入操作
    doAutowire();

    // 5. 建立URL与Method之间的映射关系。
    doHandlerMapping();

    // 5. 初始完成，待待处理请求.
    System.out.println("mvc framework success....");
  }

  /** 建立URL与方法映射 */
  private void doHandlerMapping() {
    if (iocMap.isEmpty()) {
      return;
    }

    // 进行对象的扫描
    for (Map.Entry<String, Object> objInstance : iocMap.entrySet()) {
      Class objClass = objInstance.getValue().getClass();
      // 跳过非Controller对象
      if (!objClass.isAnnotationPresent(NullNullController.class)) {
        continue;
      }
      // 1,获取类上的RequestMapping映射路径
      NullNullRequestMapping requestMappingClassUrl =
          (NullNullRequestMapping) objClass.getAnnotation(NullNullRequestMapping.class);
      String classRequestUrl = requestMappingClassUrl.value();

      // 2.进行方法的遍历的操作
      Method[] declaredMethods = objClass.getDeclaredMethods();
      for (Method declaredMethod : declaredMethods) {
        // 提取方法上的映射
        NullNullRequestMapping methodAnnotationUrl =
            declaredMethod.getDeclaredAnnotation(NullNullRequestMapping.class);

        // 方法的URL
        String url = classRequestUrl + methodAnnotationUrl.value();

        MethodMapping methodMapping =
            new MethodMapping(objInstance.getValue(), url, declaredMethod);

        // 2.提取方法的对象
        Parameter[] methodParams = declaredMethod.getParameters();

        // 读取参数
        for (int i = 0; i < methodParams.length; i++) {
          Parameter parameterItem = methodParams[i];
          if (parameterItem.getType() == HttpServletRequest.class
              || parameterItem.getType() == HttpServletResponse.class) {
            methodMapping.getParam().put(parameterItem.getType().getSimpleName(), i);
          } else {
            // 使用参数名称，此注意需要修改编译器，让其携带参数名，不然获取不到参数名
            methodMapping.getParam().put(parameterItem.getName(), i);
          }
        }

        urlMethodMapping.put(url, methodMapping);
      }
    }
  }

  /** 进行属性的注入操作 */
  private void doAutowire() {
    if (iocMap.isEmpty()) {
      return;
    }

    try {
      for (Map.Entry<String, Object> objInstance : iocMap.entrySet()) {
        Class objClass = objInstance.getValue().getClass();
        // 获取定义的属性
        Field[] fileItem = objClass.getDeclaredFields();
        // 检查属性的注解中，是否存在@AutoWire
        for (Field autowireField : fileItem) {
          // 如果不存在，则跳过
          if (!autowireField.isAnnotationPresent(NullNullAutowire.class)) {
            continue;
          }
          // 存在，则进行注入操作
          NullNullAutowire autowireAnnotation = autowireField.getAnnotation(NullNullAutowire.class);
          String instanceName = autowireAnnotation.value();

          Object iocGetInstance = null;

          if (!"".equals(instanceName)) {
            iocGetInstance = iocMap.get(instanceName);
          }
          // 如果为空，则使用接口注入
          else {
            String interfaceName = autowireField.getType().getSimpleName();
            iocGetInstance = iocMap.get(interfaceName);
          }

          // 执行注入操作
          autowireField.setAccessible(Boolean.TRUE);
          autowireField.set(objInstance.getValue(), iocGetInstance);
        }
      }
    } catch (IllegalAccessException e) {
      e.printStackTrace();
    }
  }

  /** 执行对象的初始化操作 */
  private void doInstance() {
    if (scanPkgList.isEmpty()) {
      return;
    }

    try {
      for (String pkgItem : scanPkgList) {
        // 进行反射加检查操作
        Class pkgClassItem = Class.forName(pkgItem);

        // 检查当前是否存在Service注解。
        if (pkgClassItem.isAnnotationPresent(NullNullService.class)) {

          NullNullService serviceClass =
              (NullNullService) pkgClassItem.getAnnotation(NullNullService.class);
          String value = serviceClass.value();
          // 实例对象
          Object newInstance = pkgClassItem.newInstance();
          // 如果当前设置了实例名，优先使用实例名称，未设置使用默认的首字母小字的名称
          if (!"".equals(value)) {
            iocMap.put(value, newInstance);
          } else {
            String className = pkgClassItem.getSimpleName();
            iocMap.put(toJavaLowFileName(className), newInstance);
          }

          // 在其于面向接口的编程中,可以使用接口注入
          Class<?>[] interfaceClass = pkgClassItem.getInterfaces();
          if (interfaceClass != null && interfaceClass.length > 0) {
            for (Class item : interfaceClass) {
              iocMap.put(item.getSimpleName(), newInstance);
            }
          }
        }
        // 检查当前是否存在@Controller注解
        else if (pkgClassItem.isAnnotationPresent(NullNullController.class)) {
          NullNullController serviceClass =
              (NullNullController) pkgClassItem.getAnnotation(NullNullController.class);
          String value = serviceClass.value();
          // 实例对象
          Object newInstance = pkgClassItem.newInstance();
          // 如果当前设置了实例名，优先使用实例名称，未设置使用默认的首字母小字的名称
          if (!"".equals(value)) {
            iocMap.put(value, newInstance);
          } else {
            String className = pkgClassItem.getSimpleName();
            iocMap.put(toJavaLowFileName(className), newInstance);
          }
        }
      }
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    } catch (IllegalAccessException e) {
      e.printStackTrace();
    } catch (InstantiationException e) {
      e.printStackTrace();
    }
  }

  /**
   * 加载配制文件
   *
   * @param config 配制路径
   * @return 扫描的路径
   */
  private String getScanPath(ServletConfig config) {
    String path = config.getInitParameter("mvcContextPath");

    Properties properties = new Properties();
    try (InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(path); ) {
      properties.load(inputStream);
    } catch (IOException e) {
      e.printStackTrace();
    }
    return String.valueOf(properties.get("scanBasePackage"));
  }

  /**
   * 目录文件的扫描操作
   *
   * @param path
   */
  private void doScan(String path) {
    // 基础目录
    String pathData =
        Thread.currentThread().getContextClassLoader().getResource("").getPath()
            + path.replaceAll("\\.", "/");

    // 扫描操作
    File data = new File(pathData);

    // 如果当前文件夹继续扫描

    File[] fileList = data.listFiles();
    for (File item : fileList) {
      // 如果为目录，则继续递归
      if (item.isDirectory()) {
        doScan(path + "." + item.getName());
      }
      // 如果当前为文件，则加入至容器中
      else if (item.isFile()) {
        String fileName = item.getName();
        // 非class文件则跳过
        if (!fileName.endsWith(".class")) {
          return;
        }

        // 获取上下文路径
        String className = path + "." + fileName.replaceAll(".class", "");
        // 保存路径
        scanPkgList.add(className);
      }
    }
  }

  /**
   * 将类首字线改为小写的开头
   *
   * @param name
   * @return
   */
  private String toJavaLowFileName(String name) {
    char[] fileNameArray = name.toCharArray();
    if (fileNameArray[0] >= 'A' && fileNameArray[0] <= 'Z') {
      fileNameArray[0] += 32;
    }
    return String.valueOf(fileNameArray);
  }

  @Override
  protected void service(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException {

    // 1,获取当前请求的地址
    String requestUri = req.getRequestURI();

    MethodMapping runMethod = urlMethodMapping.get(requestUri);

    if (null == runMethod) {
      resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
      resp.getWriter().write("method not found");
    }

    Object[] methodParam = new Object[runMethod.getParam().size()];

    // 进行参数的封装操作
    Map<String, String[]> requestParam = req.getParameterMap();
    for (Map.Entry<String, Integer> entryItem : runMethod.getParam().entrySet()) {

      // 如果当前为request对象
      if (entryItem.getKey().equals(HttpServletRequest.class.getSimpleName())) {
        methodParam[entryItem.getValue()] = req;
      }
      // 如果当前响应对象
      else if (entryItem.getKey().equals(HttpServletResponse.class.getSimpleName())) {
        methodParam[entryItem.getValue()] = resp;
      } else {
        methodParam[entryItem.getValue()] = requestString(requestParam.get(entryItem.getKey()));
      }
    }

    try {
      // 进行请求方法的执行
      runMethod.getMethod().invoke(runMethod.getObjInstance(), methodParam);
    } catch (IllegalAccessException e) {
      e.printStackTrace();
    } catch (InvocationTargetException e) {
      e.printStackTrace();
    }
  }

  public String requestString(String[] dataValues) {
    StringBuilder dataOut = new StringBuilder();

    for (String item : dataValues) {
      dataOut.append(item);
      dataOut.append(",");
    }
    dataOut.deleteCharAt(dataOut.length() - 1);

    return dataOut.toString();
  }
}
