package com.nullnull.demo.service;

/**
 * @author liujun
 * @since 2023/2/15
 */
public interface UserInfoService {
  /**
   * 获取用户名的服务方法
   *
   * @return 随机的用户
   */
  String getUserName(String name);
}
