package com.nullnull.mvc.bean;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 * 方法映射的对象信息
 *
 * @author liujun
 * @since 2023/2/15
 */
public class MethodMapping {

  /** 实例对象 */
  private Object objInstance;

  /** URL对象信息 */
  private String url;

  /** 方法信息 */
  private Method method;

  /** 参数顺序信息,为参数做绑定做准备 */
  private Map<String, Integer> param;

  public MethodMapping(Object objInstance, String url, Method method) {
    this.objInstance = objInstance;
    this.url = url;
    this.method = method;
    this.param = new HashMap<>();
  }

  public Object getObjInstance() {
    return objInstance;
  }

  public String getUrl() {
    return url;
  }

  public Method getMethod() {
    return method;
  }

  public Map<String, Integer> getParam() {
    return param;
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("MethodMapping{");
    sb.append("objInstance=").append(objInstance);
    sb.append(", url='").append(url).append('\'');
    sb.append(", method=").append(method);
    sb.append(", param=").append(param);
    sb.append('}');
    return sb.toString();
  }
}
