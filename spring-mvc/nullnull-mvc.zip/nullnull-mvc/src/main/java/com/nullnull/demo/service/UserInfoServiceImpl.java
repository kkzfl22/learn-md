package com.nullnull.demo.service;

import com.nullnull.mvc.annotation.NullNullService;

import java.util.concurrent.ThreadLocalRandom;

/**
 * 用户处理的服务
 *
 * @author liujun
 * @since 2023/2/14
 */
@NullNullService
public class UserInfoServiceImpl implements UserInfoService {

  /**
   * 获取用户名的服务方法
   *
   * @return 随机的用户
   */
  @Override
  public String getUserName(String name) {
    return name + "-->" + String.valueOf(ThreadLocalRandom.current().nextInt());
  }
}
